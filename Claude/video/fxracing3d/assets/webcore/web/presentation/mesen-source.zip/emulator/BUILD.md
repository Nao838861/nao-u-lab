# Mesen ブラウザコア

FxRacing Web 0.2.0の開発版は `Core/FxRacing/` の専用マッパー・GSUを追加し、実ROMを実行する。以下の旧MMC5向け説明・smoke手順とは区別する。再ビルドは `python emulator/build.py --compile-only`、実ROM試験は `tests/browser-native-recording.cjs`。通常最適化の別ホスト検証を実施済み。[実行環境の制約と検証](../docs/native-emulator-status.md)。診断用に `--output`、`--debug-names`、`--opt`、`--sanitize address/undefined` を指定できる。

NES 専用の `libretro/Mesen` を固定して使用する。元 ROM の MMC5 拡張属性・IRQ・音源を保つため、旧式 PPU の FCEUmm ではなく Mesen を採用した。

- upstream: https://github.com/libretro/Mesen
- revision: `0102910c39ad1a62bc3f784466f3f67ca9eae335`
- ライセンス: `vendor/mesen/LICENSE`（GPLv3）
- vendor の `Core/MMC5.h` に Mesen2 の NES2.0 64/128KB RAM 対応と vertical split 処理を backport した。旧コアは licensed board 用の制限で bank4..7 を読み書き不可にし、本 ROM が生成する転送 code を壊すためである。専用ホストは `emulator/host.cpp`。
- 外部 CDN・BIOS・SharedArrayBuffer・COOP/COEP は不要。

## 再ビルド

Python 3 と Emscripten 6.0.9 を使用する。

```powershell
python emulator/build.py --emsdk D:\Tools\emsdk
node emulator/smoke.mjs
node emulator/drive-smoke.mjs
node emulator/drive-smoke.mjs --grip
```

全ファイルを再コンパイルするときは `--rebuild` を付ける。既存 JS/WASM の配布用ソース ZIP・NOTICE・smoke 記録だけを更新するときは `--package-only` を使う。

別環境では `--emsdk` にインストール先を指定する。ビルドは `web/emulator/core.js` と `core.wasm` を生成する。固定 source・ホスト・ビルド手順は `web/emulator/mesen-source.zip` に同梱し、GPL 本文は `COPYING-Mesen.txt`、表示と出典は `NOTICE.txt` に置く。`build.json` にコア revision・コンパイラ版・出力 hash・両モードの smoke 結果と検証範囲を記録する。

## MMC5 RAM の修正

本 ROM は NES2.0 ヘッダで 128KB のバッテリー RAM を宣言し、bank1..7 に直接転送用の 6502 命令列を生成する。旧 Mesen は licensed board 向けの制限で bank4..7 を読み書き不可にするため、静止時の画面は描けても、加速に伴う full transfer で未生成命令列を実行し、画面が黒くなった。

Mesen2 の `b9fa69ddc6d0a331fb103fdb5eef6904305703c2` にある [`MMC5.h`](https://github.com/SourMesen/Mesen2/blob/b9fa69ddc6d0a331fb103fdb5eef6904305703c2/Core/NES/Mappers/Nintendo/MMC5.h) の単一 64/128KB RAM 分岐を移植した。元コアとの差分は `mmc5-ram-backport.patch`。修正後は DRIFT/GRIP とも 120frames 連続加速で毎 frame の転送が完了し、黒 frame が消えた。

同じ固定 Mesen2 source から scanline 末尾のタイルカウンタ reset、split 領域の状態保持、先読みタイルの縦 scroll、属性の2bit抽出も移植した。こちらの差分は `mmc5-split-backport.patch`。配布 vendor は両差分を適用済み。

## 入力のみ5周検証

固定 ROM は `9c96223` の `MMC5Racing_TitlePolish_136x184.nes`、SHA256 `11ca143fdf49e9666489ac56b5ffd1aaced25f79ba2f7b1b66ed9126b0ad0353`。

`drive-smoke.mjs` は元プロジェクトの成功済み route/tune を `drive-fixture.json` に保存し、実際の姿勢を読んで A/B/左右だけを入力する。CPU/WRAM/姿勢/時計への書込み、save state、frame skip は使わない。

| モード | 5周合計 ticks | ROM 表示 | goal | 黒 frame | 転送拒否 |
| --- | ---: | --- | --- | ---: | ---: |
| DRIFT | 5734 | 1:35.56 | 到達 | 0 | 0 |
| GRIP | 5469 | 1:31.15 | 到達 | 0 | 0 |

両モードで CPU3台同時表示と HUD を確認した。結果画面は左128pxを表示20→270ticksで比較し、画素差0。5lap、合計、最速、NEW RECORD の表示を目視確認した。固定した結果 ROM は fine-X を最大7px整列し、結果時の右パネルを128pxへ広げるため、goal 前の画像との同位置画素一致は要求しない。

途中で使用した旧 ROM `01bb6bbf…` の結果破損は、元プロジェクトで coarse-X/ExRAM の競合として修正された。これをコアの不具合とは断定しない。128KB WRAM 非対応による加速時の黒画面は、コア側の確定した修正である。

生 framebuffer、PNG、時系列ログ、検証 JSON は `emulator/build/drive-drift/` と `drive-grip/` に保存し、git 対象から除外する。`build.json` は実 ROM/WASM hash が一致する検証結果だけを `input_drive` へ収録する。全状態の60fps・全描画境界・全入力の完全互換は保証しない。

## JavaScript API

`core.js` の default export は非同期 factory `createCore`。呼び出すと WASM を読み込み、`HEAPU8` と `HEAP16` を公開する。メモリ成長時は view が更新されるため、長期間同じ view を保持しない。

| API | 返り値と役割 |
| --- | --- |
| `_malloc(bytes)` / `_free(ptr)` | ROM 受け渡し用メモリ |
| `_web_load_rom(ptr, length)` | ROM を内部コピーして起動。成功 `1`、失敗 `0` |
| `_web_run(mask)` | 入力 mask を適用し、正確に NES の 1 フレームを進める |
| `_web_pixels()` | 256×240×4 bytes の RGBA 先頭 pointer |
| `_web_audio()` | 今フレーム分の interleaved signed int16 stereo 先頭 pointer |
| `_web_audio_frames()` | 今フレームの stereo frame 数（int16 要素数は2倍） |
| `_web_sample_rate()` | 音声 sample rate。48,000 Hz |
| `_web_fps()` | コアが返す NTSC の実フレーム速度 |
| `_web_peek(cpuaddr)` | 副作用を抑えた CPU address space の読出し。MMC5 WRAM に対応 |
| `_web_poke(cpuaddr, byte)` | QA 用の副作用を抑えた書込み |
| `_web_save_ptr()` / `_web_save_size()` | バッテリー RAM の pointer と bytes |
| `_web_reset()` | NES のリセット |

入力 mask は `A=1, B=2, SELECT=4, START=8, UP=16, DOWN=32, LEFT=64, RIGHT=128`。
Web UI の時計表示とランキングは ROM の ticks/60 に合わせる。実 NTSC fps で ticks を秒へ変換し直さない。

`smoke.mjs` は固定 `web/assets/game.nes` を読み、両モードでタイトル→カウントダウン→レース、入力・時計・音声・MMC5 WRAM を検査する。生成された raw RGBA と結果 JSON は git 管理対象外の `emulator/build/smoke/` に保存する。


## リプレイ状態API

2026-10-19のWeb 0.3.0はROM `e417eb1b…`（元ゲームmain `788b629`）と互換世代3を使う。コアのバイナリーは変更しない。ゴースト対戦では独立Workerでリプレイを最後まで検証した後、ROMが収録した候補データを取り出す。Web側で外部ゴーストの再生スロットと自分の保存用データを分け、自己ベストのジャーナルを維持する。

`_web_state_size()` は現在のMesen状態を生成して必要バイト数を返す。直後にそのサイズの領域を確保し、`_web_state_save(ptr,size)` でコピーする。`_web_state_load(ptr,size)` は固定ROMのMSTヘッダー一致を検査して復元する。いずれも最大2MiB。libretro既定の固定サイズ切詰めを避け、実際の状態長を使う。ホストの表示・音声バッファは次の `_web_run()` で更新される。

再生用インスタンスはWeb Worker内に生成し、最大メモリー256MiB・応答監視付きで実行する。開始時にROMとWASMのSHA256を確認する。視聴用コアからセーブやランキング送信は行わない。

`node emulator/replay-smoke.mjs` と `--grip` は入力のみ5周→開始状態を別コアへ復元→全入力を再生し、途中と最終画面・時計を比較する。結果は `verification/replay-*.json`。Webアプリそのものの収録経路は `tests/browser-recording.cjs` と `tests/verify-recorded-replays.mjs` で別途検証する。
