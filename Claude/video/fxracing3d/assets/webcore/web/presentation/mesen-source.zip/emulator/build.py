"""固定した Mesen source から自己完結 JS/WASM を再ビルドする。"""
from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import shutil
import zipfile

ROOT = Path(__file__).resolve().parent.parent
SOURCE = ROOT / "vendor" / "mesen"
REVISION = "0102910c39ad1a62bc3f784466f3f67ca9eae335"


def package_outputs(sdk, out):
    if (SOURCE/'Core/FxRacing/NesFxRacingPc.h').exists():
        package_native_outputs(sdk,out)
        return
    manifest = {"core": "Mesen NES-only libretro", "upstream": "https://github.com/libretro/Mesen", "revision": REVISION, "emscripten": (sdk / "emscripten-version.txt").read_text().strip().strip('"'), "threaded": False, "backport_source_revision": "b9fa69ddc6d0a331fb103fdb5eef6904305703c2", "patches": ["NES2.0 single 64/128KB PRG-RAM mapping (MMC5 banks 4..15)", "MMC5 vertical split scanline, column and attribute fetch handling"], "files": {p.name: {"bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in (out / "core.js", out / "core.wasm")}}
    if (ROOT / "web" / "assets" / "game.nes").exists():
        subprocess.run(["node", str(ROOT / "emulator" / "smoke.mjs")], cwd=ROOT, check=True)
        smoke = json.loads((ROOT / "emulator" / "build" / "smoke" / "results.json").read_text())
        manifest["smoke"] = {"status": "passed", "rom_sha256": smoke["romSha256"], "scope": ["title and countdown to race in DRIFT and GRIP", "60 core frames advance the ROM clock by 60 ticks", "120 accelerating frames remain rendered and publish every frame", "48kHz nonzero stereo audio", "MMC5 WRAM debug peek/poke"], "limitations": "短い smoke は全描画境界・全入力の検証を含まない。入力のみ5周の結果は input_drive に記録する。", "tests": smoke["tests"]}
        drives = []
        for mode in ("drift", "grip"):
            evidence = ROOT / "emulator" / "build" / ("drive-" + mode) / "results.json"
            if not evidence.exists():
                continue
            drive = json.loads(evidence.read_text())
            if drive["romSha256"] != smoke["romSha256"] or drive["wasmSha256"] != manifest["files"]["core.wasm"]["sha256"]:
                continue
            if not (drive["goal"] and drive["completedLaps"] == 5 and drive["blackFrames"] == 0 and drive.get("leftCourseStableDifference") == 0):
                continue
            drives.append({"mode": mode, "input_only": True, "frames": drive["frames"], "completed_laps": drive["completedLaps"], "goal": drive["goal"], "total_ticks": drive["last"]["total"], "lap_ticks": drive["lapTimes"], "black_frames": drive["blackFrames"], "transfer_rejects": drive["last"]["rejects"], "maximum_visible_cpu_cars": drive["maxCpuCars"], "left_course_pixel_differences_between_result_ticks_20_and_270": drive["leftCourseStableDifference"]})
        manifest["input_drive"] = {"status": "passed" if len(drives) == 2 else "incomplete", "tests": drives, "scope": "通常入力の追従器で5周完走。CPU/WRAM/姿勢/時計の注入なし。全状態の60fpsや全経路の完全互換を保証するものではない。"}
    else:
        manifest["smoke"] = {"status": "not_run", "reason": "web/assets/game.nes is absent"}
    replay_tests = []
    for mode in ("grip", "drift"):
        evidence = ROOT / "verification" / ("replay-" + mode + ".json")
        if evidence.exists():
            result = json.loads(evidence.read_text(encoding="utf-8"))
            if result.get("passed") and result.get("core") == manifest["files"]["core.wasm"]["sha256"] and result.get("rom") == manifest.get("smoke", {}).get("rom_sha256"):
                replay_tests.append(result)
    manifest["replay"] = {"state_api": True, "maximum_state_bytes": 2097152, "status": "passed" if len(replay_tests) == 2 else "not_verified", "tests": replay_tests}
    (out / "build.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.copyfile(SOURCE / "LICENSE", out / "COPYING-Mesen.txt")
    shutil.copyfile(ROOT / "emulator" / "NOTICE.txt", out / "NOTICE.txt")
    with zipfile.ZipFile(out / "mesen-source.zip", "w", compression=zipfile.ZIP_DEFLATED) as archive:
        files = list((ROOT / "vendor").rglob("*")) + list((ROOT / "emulator").glob("*"))
        for source_file in sorted(files):
            if source_file.is_file():
                info = zipfile.ZipInfo(source_file.relative_to(ROOT).as_posix(), (2026, 10, 16, 0, 0, 0))
                info.compress_type = zipfile.ZIP_DEFLATED
                archive.writestr(info, source_file.read_bytes())
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


def package_native_outputs(sdk,out):
    version=json.loads((ROOT/'release-version.json').read_text(encoding='utf-8'))
    files={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in (out/'core.js',out/'core.wasm')}
    assert files['core.wasm']['sha256']==version['core']
    tests=[]
    for mode in ['drift','grip']:
        result=json.loads((ROOT/f'verification/replay-{mode}.json').read_text(encoding='utf-8'))
        if result.get('passed') and all(result.get(k)==version[k] for k in ['epoch','rom','core']):tests.append(result)
    replay_status=('passed' if all(t.get('wasmCompiler')=='default' for t in tests) else 'baseline-only') if len(tests)==2 else 'not_verified'
    manifest={'core':'Mesen NES + FxRacing custom mapper + GSU','revision':REVISION,
        'emscripten':(sdk/'emscripten-version.txt').read_text().strip().strip('"'),
        'threaded':False,'cpp_optimization':3,'link_optimization':0,'files':files,
        'mapper_source':json.loads((SOURCE/'Core/FxRacing/source.json').read_text(encoding='utf-8')),
        'replay':{'status':replay_status,'tests':tests},
        'limitations':'Mesen PC functional mapper model; not FPGA cycle-accurate timing evidence. Native and Web PPU/palette versions can differ.'}
    (out/'build.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    shutil.copyfile(SOURCE/'LICENSE',out/'COPYING-Mesen.txt');shutil.copyfile(ROOT/'emulator/NOTICE.txt',out/'NOTICE.txt')
    with zipfile.ZipFile(out/'mesen-source.zip','w',compression=zipfile.ZIP_DEFLATED) as archive:
        files=list((ROOT/'vendor').rglob('*'))+list((ROOT/'emulator').glob('*'))
        for f in sorted(files):
            if f.is_file():archive.write(f,f.relative_to(ROOT).as_posix())
    print(json.dumps({'core':manifest['core'],'files':manifest['files'],'replay':manifest['replay']['status']}))


def package_presentation(out):
    pinned_rom='aafcc92412f4f1bef1658fcd4f1b7340cb296ebbae1decf330cc02ca6b52b2ce'
    if not (out/'game.nes').exists():shutil.copy2(ROOT/'web/assets/game.nes',out/'game.nes')
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    assert digest(out/'game.nes')==pinned_rom,'Presentation requires the pinned ROM service ABI'
    manifest=dict(contract=1,packetBytes=433,rom=pinned_rom,core=digest(out/'core.wasm'),renderer='FxRacing ROM CPU/GSU/DSP/PPU',sourceSimulationModified=False,physicsSkippedInPresentationOnly=True)
    (out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    shutil.copy2(SOURCE/'LICENSE',out/'COPYING-Mesen.txt')
    (out/'NOTICE.txt').write_text('GPL-3.0-or-later. Pinned Mesen and FxRacing ROM presentation host. Corresponding source: mesen-source.zip. Rebuild: python emulator/build.py --presentation --output web/presentation\n',encoding='utf-8')
    with zipfile.ZipFile(out/'mesen-source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted([*SOURCE.parent.rglob('*'),*(ROOT/'emulator').glob('*')]):
            if f.is_file():z.write(f,f.relative_to(ROOT).as_posix())
    print(json.dumps(manifest))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--emsdk", default=os.environ.get("EMSDK", r"D:\Tools\emsdk"))
    parser.add_argument("--jobs", type=int, default=min(8, os.cpu_count() or 2))
    parser.add_argument("--package-only", action="store_true", help="既存 core.js/WASM の smoke・manifest・ライセンス・source ZIP を更新")
    parser.add_argument("--rebuild", action="store_true", help="全翻訳単位を再コンパイル")
    parser.add_argument("--compile-only", action="store_true", help="WASMを生成し、別途実ROMの試験を行う")
    parser.add_argument('--output',type=Path,help='診断用出力先（通常はweb/emulator）')
    parser.add_argument('--debug-names',action='store_true')
    parser.add_argument('--opt',choices=['0','1','2','3'],default='3')
    parser.add_argument('--sanitize',choices=['address','undefined'])
    parser.add_argument('--fixed-memory',action='store_true')
    parser.add_argument("--presentation",action="store_true",help="Build a separate read-only native-ROM replay presentation core")
    args = parser.parse_args()
    sdk = Path(args.emsdk) / "upstream" / "emscripten"
    build = ROOT / "emulator" / "build" / ('o'+args.opt+(args.sanitize or '')+('-presentation' if args.presentation else ''))
    out = args.output or ROOT / "web" / ("presentation" if args.presentation else "emulator")
    if args.presentation and out.resolve()==(ROOT/"web/emulator").resolve():raise SystemExit("Presentation must not overwrite the recording core")
    build.mkdir(parents=True, exist_ok=True)
    out.mkdir(parents=True, exist_ok=True)
    if args.package_only:
        if args.presentation:package_presentation(out)
        else:package_outputs(sdk, out)
        return
    common = (SOURCE / "Libretro" / "Makefile.common").read_text()
    dirs = {"SEVENZIP_DIR": "SevenZip", "CORE_DIR": "Core", "UTIL_DIR": "Utilities", "LIBRETRO_DIR": "Libretro"}
    sources = []
    for variable, relative in re.findall(r"\$\((\w+)\)/([^\s\\]+\.(?:cpp|c))", common):
        if relative == "libretro.cpp":
            continue  # host.cpp が include する。
        sources.append(SOURCE / dirs[variable] / relative)
    sources.append(ROOT / "emulator" / "host.cpp")
    flags = ["-O"+args.opt, "-DNDEBUG", "-DLIBRETRO", "-fexceptions", "-Wno-deprecated-declarations", "-Wno-c++11-narrowing"]
    if args.presentation:flags+=["-DFX_PRESENTATION"]
    if args.sanitize:flags+=['-fsanitize='+args.sanitize]
    flags.extend("-I" + str(SOURCE / d) for d in dirs.values())
    mapper_header_time = max(p.stat().st_mtime for p in [SOURCE/'Core/MMC5.h',*(SOURCE/'Core/FxRacing').glob('*')])

    def compile_one(src):
        rel = src.relative_to(ROOT)
        obj = build / (str(rel).replace("\\", "_").replace("/", "_") + ".o")
        dependency_time = max(src.stat().st_mtime, mapper_header_time if src.name in ("MapperFactory.cpp","host.cpp") else 0, (ROOT/"emulator/presentation-host.inc").stat().st_mtime if src.name=="host.cpp" else 0)
        if not args.rebuild and obj.exists() and obj.stat().st_mtime > dependency_time:
            return obj
        cpp = src.suffix == ".cpp"
        compiler = sdk / ("em++.py" if cpp else "emcc.py")
        cmd = [sys.executable, str(compiler), *flags]
        if cpp:
            cmd += ["-std=c++17" if src.name in ("MapperFactory.cpp","host.cpp") else "-std=c++11"]
        cmd += ["-c", str(src), "-o", str(obj)]
        result = subprocess.run(cmd, cwd=ROOT, text=True, capture_output=True)
        if result.returncode:
            raise RuntimeError(str(rel) + "\n" + result.stdout + result.stderr)
        print("compiled", rel, flush=True)
        return obj

    with concurrent.futures.ThreadPoolExecutor(max_workers=args.jobs) as pool:
        objects = list(pool.map(compile_one, sources))
    exports = ["web_load_rom", "web_run", "web_pixels", "web_audio", "web_audio_frames", "web_sample_rate", "web_fps", "web_peek", "web_poke", "web_save_ptr", "web_save_size", "web_reset", "web_state_size", "web_state_save", "web_state_load", "malloc", "free"]
    if args.presentation:exports += ["web_present_frame","web_present_injections"]
    response = build / "link.rsp"
    response.write_text("\n".join('"' + str(obj).replace("\\", "/") + '"' for obj in objects))
    command = [sys.executable, str(sdk / "em++.py"), "@" + str(response), "-O3", "-fexceptions", "--no-entry", "-sMODULARIZE=1", "-sEXPORT_ES6=1", "-sEXPORT_NAME=createCore", "-sALLOW_MEMORY_GROWTH=1", "-sINITIAL_MEMORY=134217728", "-sMAXIMUM_MEMORY=268435456", "-sSTACK_SIZE=5242880", "-sENVIRONMENT=web,worker,node", '-sEXPORTED_RUNTIME_METHODS=["HEAPU8","HEAP16"]', "-sEXPORTED_FUNCTIONS=" + json.dumps(["_" + e for e in exports]), "-o", str(out / "core.js")]
    if args.presentation:command[command.index('-sINITIAL_MEMORY=134217728')]='-sINITIAL_MEMORY=100663296'
    link_env=os.environ.copy();link_env['BINARYEN_CORES']='1'
    # この開発PCでBinaryen自体の異常終了を観測。特定マッパーの欠陥とは断定しない。
    # C++は--optで最適化し、リンク後のWASM最適化を無効化する。
    command[command.index('-O3')] = '-O0'
    if args.debug_names:command.insert(-2,'-g2')
    if args.sanitize:command.insert(-2,'-fsanitize='+args.sanitize)
    if args.fixed_memory:command[command.index('-sALLOW_MEMORY_GROWTH=1')]='-sALLOW_MEMORY_GROWTH=0'
    subprocess.run(command, cwd=ROOT, check=True,env=link_env)
    if not args.compile_only:
        if args.presentation:package_presentation(out)
        else:package_outputs(sdk, out)


if __name__ == "__main__":
    main()
