// 実姿勢を読む入力追従器。ロード後は web_run と web_peek だけで走らせる。
// CPU/WRAM/姿勢/時計への書込み、save state、加速、skip は使用しない。
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import createCore from '../web/emulator/core.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const mode=process.argv.includes('--grip')?'grip':'drift';
const limit=Number(process.argv.find(x=>x.startsWith('--frames='))?.split('=')[1]||10000);
const stopLaps=Number(process.argv.find(x=>x.startsWith('--laps='))?.split('=')[1]||5);
const out=path.join(root,'emulator','build','drive-'+mode);
fs.mkdirSync(out,{recursive:true});
const {route,tune}=JSON.parse(fs.readFileSync(path.join(root,'emulator','drive-fixture.json')));
const rom=fs.readFileSync(path.join(root,'web','assets','game.nes'));
const wasmBinary=fs.readFileSync(path.join(root,'web','emulator','core.wasm'));
const core=await createCore({wasmBinary});
const ptr=core._malloc(rom.length);core.HEAPU8.set(rom,ptr);
assert.equal(core._web_load_rom(ptr,rom.length),1);core._free(ptr);
const rd=(addr,n=1)=>{let value=0;for(let i=0;i<n;i++)value+=core._web_peek(addr+i)*2**(8*i);return value;};
const signed=(addr,n)=>{const v=rd(addr,n);return v>=2**(n*8-1)?v-2**(n*8):v;};
const wrap=a=>((a+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;

function target(x,y,look) {
  let best=Infinity,bi=0,bt=0;
  for(let i=0;i<route.length;i++) {
    const p=route[i],q=route[(i+1)%route.length],dx=q[0]-p[0],dy=q[1]-p[1];
    const t=Math.max(0,Math.min(1,((x-p[0])*dx+(y-p[1])*dy)/(dx*dx+dy*dy)));
    const d=(x-p[0]-t*dx)**2+(y-p[1]-t*dy)**2;
    if(d<best){best=d;bi=i;bt=t;}
  }
  const segment=bi,distance=Math.sqrt(best);
  for(let z=0;z<route.length;z++) {
    const p=route[bi],q=route[(bi+1)%route.length],len=Math.hypot(q[0]-p[0],q[1]-p[1]),remaining=(1-bt)*len;
    if(look<=remaining){const t=bt+look/len;return{x:p[0]+t*(q[0]-p[0]),y:p[1]+t*(q[1]-p[1]),segment,distance};}
    look-=remaining;bi=(bi+1)%route.length;bt=0;
  }
  return{x:route[bi][0],y:route[bi][1],segment,distance};
}

function controls() {
  const x=signed(0x41,3)/256,y=signed(0x44,3)/256,vx=signed(0x4b,2)/256,vy=signed(0x4e,2)/256,speed=Math.hypot(vx,vy);
  const tx=target(x,y,tune.look_base+speed*tune.look_speed);
  const heading=rd(0x48,2)*Math.PI*2/65536;
  const desired=Math.atan2(tx.x-x,-(tx.y-y));
  const error=wrap(desired-heading-signed(0x51,2)*Math.PI*2/65536*tune.yaw_prediction);
  let mask=1;
  if(error>tune.deadband)mask|=128;
  if(error<-tune.deadband)mask|=64;
  if(speed>tune.drift_speed&&Math.abs(error)>tune.drift_angle)mask|=2;
  if(Math.abs(error)>tune.brake_angle&&speed>tune.brake_speed)mask=(mask&~1)|2;
  return {mask,x,y,speed,error,segment:tx.segment,distance:tx.distance};
}

// PNG への無損失 framebuffer 書出し（画素変更なし）。
const table=Uint32Array.from({length:256},(_,n)=>{let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;return c>>>0;});
const crc=data=>{let c=0xffffffff;for(const b of data)c=table[(c^b)&255]^(c>>>8);return(c^0xffffffff)>>>0;};
function chunk(type,data){const tag=Buffer.from(type),head=Buffer.alloc(4),tail=Buffer.alloc(4);head.writeUInt32BE(data.length);tail.writeUInt32BE(crc(Buffer.concat([tag,data])));return Buffer.concat([head,tag,data,tail]);}
function screenshot(name) {
  const pixels=Buffer.from(core.HEAPU8.slice(core._web_pixels(),core._web_pixels()+256*240*4));
  fs.writeFileSync(path.join(out,name+'.rgba'),pixels);
  const rows=Buffer.alloc((256*4+1)*240);
  for(let y=0;y<240;y++)pixels.copy(rows,y*(256*4+1)+1,y*256*4,(y+1)*256*4);
  const header=Buffer.alloc(13);header.writeUInt32BE(256,0);header.writeUInt32BE(240,4);header[8]=8;header[9]=6;
  fs.writeFileSync(path.join(out,name+'.png'),Buffer.concat([Buffer.from([137,80,78,71,13,10,26,10]),chunk('IHDR',header),chunk('IDAT',zlib.deflateSync(rows)),chunk('IEND',Buffer.alloc(0))]));
}
function visibleCars(){let n=0;for(let car=0;car<3;car++) {let seen=false;for(let part=0;part<2;part++){const a=0x200+(40+car*2+part)*4,y=rd(a),x=rd(a+3);seen||=y<216&&y+16>32&&x<136;}n+=seen;}return n;}
function litPixels(){let n=0;const p=core._web_pixels();for(let i=0;i<256*240*4;i+=4)n+=core.HEAPU8[p+i]+core.HEAPU8[p+i+1]+core.HEAPU8[p+i+2]>0;return n;}

const run=(n,mask=0)=>{for(let i=0;i<n;i++)core._web_run(mask);};
run(180);if(mode==='grip'){run(1,32);run(2);}run(1,8);run(190);
assert.equal(rd(0x6720),1);assert.equal(rd(0x674d),mode==='grip'?1:0);
screenshot('race-start');
const initialTicks=rd(0x6726,3),initialNmi=rd(0,2),initialPublished=rd(2,2);
let blackFrames=0,minLit=256*240,maxCpuCars=0,previousLaps=rd(0x6721),completedLaps=0,goal=false,frame=0,last={},bestCarsShot='',leftCourseDifference=null,leftCourseStableDifference=null;
const transitions=[],records=[];
const started=performance.now();
for(;frame<limit;frame++) {
  const control=controls();core._web_run(control.mask);
  const state=rd(0x6720),laps=rd(0x6721),total=rd(0x6726,3),lap=rd(0x6729,3),lit=litPixels(),cars=visibleCars();
  if(state===1||state===2){blackFrames+=lit===0;minLit=Math.min(minLit,lit);}
  if(cars>maxCpuCars){maxCpuCars=cars;bestCarsShot='cpu-cars-'+cars;screenshot(bestCarsShot);}
  if(laps!==previousLaps){completedLaps+=Math.max(0,laps-previousLaps);transitions.push({frame:frame+1,laps,total,lap,state});previousLaps=laps;screenshot('lap-'+laps);console.log('lap',JSON.stringify(transitions.at(-1)));}
  last={frame:frame+1,state,laps,total,lap,completed:rd(0x6757),flags:rd(0x6723),rank:rd(0x6135),rejects:rd(0x67fd),nmi:rd(0,2),published:rd(2,2),lit,cpuCars:cars,...control};
  if(frame%30===0)records.push(last);
  if(frame%300===0)screenshot('frame-'+String(frame+1).padStart(5,'0'));
  if(state===2){
    goal=true;screenshot('goal');const goalPixels=core.HEAPU8.slice(core._web_pixels(),core._web_pixels()+256*240*4);
    run(20);screenshot('results-early');const earlyPixels=core.HEAPU8.slice(core._web_pixels(),core._web_pixels()+256*240*4);
    run(250);screenshot('results');const p=core._web_pixels();leftCourseDifference=0;leftCourseStableDifference=0;
    for(let y=32;y<216;y++)for(let x=0;x<136;x++){
      const i=(y*256+x)*4;leftCourseDifference+=goalPixels[i]!==core.HEAPU8[p+i]||goalPixels[i+1]!==core.HEAPU8[p+i+1]||goalPixels[i+2]!==core.HEAPU8[p+i+2];
    }
    // ResultsStable ROM は fine-X を最大7px snapし、右パネルを x128 から出す。
    // goal画像との同位置差はその仕様を含むため、左の固定性は表示20→270ticksで測る。
    for(let y=32;y<216;y++)for(let x=0;x<128;x++){
      const i=(y*256+x)*4;leftCourseStableDifference+=earlyPixels[i]!==core.HEAPU8[p+i]||earlyPixels[i+1]!==core.HEAPU8[p+i+1]||earlyPixels[i+2]!==core.HEAPU8[p+i+2];
    }
    break;
  }
  if(completedLaps>=stopLaps){screenshot('target-laps');break;}
  if(state!==1){screenshot('unexpected-state-'+state);break;}
}
const result={mode,inputOnly:true,romSha256:crypto.createHash('sha256').update(rom).digest('hex'),wasmSha256:crypto.createHash('sha256').update(wasmBinary).digest('hex'),limit,targetLaps:stopLaps,initialTicks,initialNmi,initialPublished,frames:frame+1,completedLaps,goal,blackFrames,minimumLitPixels:minLit,maxCpuCars,bestCarsShot,leftCourseDifference,leftCourseStableDifference,last,lapTimes:Array.from({length:5},(_,i)=>rd(0x672c+i*3,3)),transitions,elapsedMs:performance.now()-started};
fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2)+'\n');
fs.writeFileSync(path.join(out,'telemetry.json'),JSON.stringify(records,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
assert(goal||completedLaps>=stopLaps,'requested laps completed');assert.equal(blackFrames,0,'no black racing frames');
if(goal)assert.equal(leftCourseStableDifference,0,'result screen keeps left-course framebuffer fixed');
