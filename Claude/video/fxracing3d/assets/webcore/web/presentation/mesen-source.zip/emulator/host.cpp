// SPDX-License-Identifier: GPL-3.0-or-later
// MMC5Racing のための単一スレッド libretro ホスト。
// libretro.cpp を同じ翻訳単位に置き、Mesen の副作用なし DebugRead を使う。
#include <cstdint>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#include <map>
#include <vector>
#include <string>
#include <exception>
#include <emscripten/emscripten.h>
#include "../vendor/mesen/Libretro/libretro.cpp"
#include "../vendor/mesen/Core/FxRacing/NesFxRacingPc.h"

static std::map<std::string, std::string> options;
static std::vector<uint8_t> rom;
static uint8_t rgba[256 * 240 * 4];
static int16_t samples[16384 * 2];
static unsigned sampleFrames = 0;
static unsigned buttons = 0;
static double framesPerSecond = 60.0988138974405;
static double sampleRate = 48000;
static bool initialized = false;
static bool loaded = false;
static std::string replayState;

static void readOptions(const retro_core_option_v2_definition *defs) {
    if (!defs) return;
    for (; defs->key; ++defs) {
        if (defs->default_value) options[defs->key] = defs->default_value;
    }
}

static bool environment(unsigned cmd, void *data) {
    switch (cmd) {
    case RETRO_ENVIRONMENT_GET_CORE_OPTIONS_VERSION:
        *static_cast<unsigned*>(data) = 2; return true;
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2:
        readOptions(static_cast<retro_core_options_v2*>(data)->definitions); return true;
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_V2_INTL:
        readOptions(static_cast<retro_core_options_v2_intl*>(data)->us->definitions); return true;
    case RETRO_ENVIRONMENT_GET_VARIABLE: {
        auto *var = static_cast<retro_variable*>(data);
        auto found = options.find(var->key);
        if (found == options.end()) { var->value = nullptr; return false; }
        var->value = found->second.c_str(); return true;
    }
    case RETRO_ENVIRONMENT_GET_VARIABLE_UPDATE:
        *static_cast<bool*>(data) = false; return true;
    case RETRO_ENVIRONMENT_GET_GAME_INFO_EXT: {
        static retro_game_info_ext game = {};
        game.full_path = "/MMC5Racing.nes";
        game.dir = "/";
        game.name = "MMC5Racing";
        game.ext = "nes";
        game.data = rom.data();
        game.size = rom.size();
        game.persistent_data = true;
        *static_cast<const retro_game_info_ext**>(data) = &game;
        return true;
    }
    case RETRO_ENVIRONMENT_GET_LANGUAGE:
        *static_cast<unsigned*>(data) = RETRO_LANGUAGE_ENGLISH; return true;
    case RETRO_ENVIRONMENT_GET_SYSTEM_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_SAVE_DIRECTORY:
    case RETRO_ENVIRONMENT_GET_CONTENT_DIRECTORY:
        *static_cast<const char**>(data) = "/"; return true;
    case RETRO_ENVIRONMENT_SET_PIXEL_FORMAT:
        return *static_cast<retro_pixel_format*>(data) == RETRO_PIXEL_FORMAT_XRGB8888;
    case RETRO_ENVIRONMENT_SET_SYSTEM_AV_INFO: {
        const auto *av = static_cast<retro_system_av_info*>(data);
        if (av->timing.fps > 0) framesPerSecond = av->timing.fps;
        if (av->timing.sample_rate > 0) sampleRate = av->timing.sample_rate;
        return true;
    }
    case RETRO_ENVIRONMENT_SET_SUPPORT_NO_GAME:
    case RETRO_ENVIRONMENT_SET_CONTROLLER_INFO:
    case RETRO_ENVIRONMENT_SET_INPUT_DESCRIPTORS:
    case RETRO_ENVIRONMENT_SET_MEMORY_MAPS:
    case RETRO_ENVIRONMENT_SET_GEOMETRY:
    case RETRO_ENVIRONMENT_SET_CONTENT_INFO_OVERRIDE:
    case RETRO_ENVIRONMENT_SET_CORE_OPTIONS_DISPLAY:
        return true;
    default: return false;
    }
}

static void video(const void *data, unsigned width, unsigned height, size_t pitch) {
    if (!data) return;
    for (unsigned y = 0; y < 240; ++y) {
        for (unsigned x = 0; x < 256; ++x) {
            uint32_t p = 0;
            if (x < width && y < height)
                std::memcpy(&p, static_cast<const uint8_t*>(data) + y * pitch + x * 4, 4);
            const unsigned dst = (y * 256 + x) * 4;
            rgba[dst] = (p >> 16) & 255;
            rgba[dst + 1] = (p >> 8) & 255;
            rgba[dst + 2] = p & 255;
            rgba[dst + 3] = 255;
        }
    }
}

static size_t audio(const int16_t *data, size_t frames) {
    const size_t count = std::min(frames, static_cast<size_t>(16384 - sampleFrames));
    std::memcpy(samples + sampleFrames * 2, data, count * 2 * sizeof(int16_t));
    sampleFrames += count;
    return frames;
}

static void inputPoll() {}
static int16_t inputState(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port || device != RETRO_DEVICE_JOYPAD || index) return 0;
    unsigned mask = 0;
    switch(id) {
    case RETRO_DEVICE_ID_JOYPAD_A: mask = 1; break;
    case RETRO_DEVICE_ID_JOYPAD_B: mask = 2; break;
    case RETRO_DEVICE_ID_JOYPAD_SELECT: mask = 4; break;
    case RETRO_DEVICE_ID_JOYPAD_START: mask = 8; break;
    case RETRO_DEVICE_ID_JOYPAD_UP: mask = 16; break;
    case RETRO_DEVICE_ID_JOYPAD_DOWN: mask = 32; break;
    case RETRO_DEVICE_ID_JOYPAD_LEFT: mask = 64; break;
    case RETRO_DEVICE_ID_JOYPAD_RIGHT: mask = 128; break;
    default: break;
    }
    return (buttons & mask) ? 1 : 0;
}

extern "C" {
EMSCRIPTEN_KEEPALIVE int web_load_rom(const uint8_t *data, unsigned length) {
    try {
        if (initialized) { retro_deinit(); initialized = loaded = false; }
        rom.assign(data, data + length);
        options.clear();
        retro_set_environment(environment);
        options["mesen_region"] = "NTSC";
        options["mesen_ntsc_filter"] = "Disabled";
        options["mesen_palette"] = "Default";
        options["mesen_overclock"] = "None";
        options["mesen_nospritelimit"] = "disabled";
        options["mesen_hdpacks"] = "disabled";
        options["mesen_ramstate"] = "All 0s (Default)";
        options["mesen_audio_sample_rate"] = "48000";
        for (auto side : {"left", "right", "up", "down"})
            options[std::string("mesen_overscan_") + side] = "None";
        retro_init(); initialized = true;
        retro_set_video_refresh(video);
        retro_set_audio_sample_batch(audio);
        retro_set_input_poll(inputPoll);
        retro_set_input_state(inputState);
        retro_game_info game = {"/MMC5Racing.nes", rom.data(), rom.size(), nullptr};
        loaded = retro_load_game(&game);
        if (!loaded) return 0;
        retro_system_av_info av = {};
        retro_get_system_av_info(&av);
        framesPerSecond = av.timing.fps;
        sampleRate = av.timing.sample_rate;
        buttons = sampleFrames = 0;
        std::memset(rgba, 0, sizeof(rgba));
        return 1;
    } catch (const std::exception &e) {
        std::fprintf(stderr, "Mesen: %s\n", e.what());
        loaded = false; return 0;
    }
}
EMSCRIPTEN_KEEPALIVE void web_run(unsigned mask) {
    buttons = mask & 255; sampleFrames = 0;
    if (loaded) retro_run();
}
EMSCRIPTEN_KEEPALIVE uint8_t *web_pixels() { return rgba; }
EMSCRIPTEN_KEEPALIVE int16_t *web_audio() { return samples; }
EMSCRIPTEN_KEEPALIVE unsigned web_audio_frames() { return sampleFrames; }
EMSCRIPTEN_KEEPALIVE double web_sample_rate() { return sampleRate; }
EMSCRIPTEN_KEEPALIVE double web_fps() { return framesPerSecond; }
EMSCRIPTEN_KEEPALIVE unsigned web_peek(unsigned addr) {
    if(loaded&&addr>=0x6000&&addr<=0x7fff)if(auto fx=dynamic_cast<NesFxRacingPc*>(_console->GetMapper()))return fx->RecordRam()[addr-0x6000];
    return loaded ? _console->GetMemoryManager()->DebugRead(addr & 65535, true) : 0;
}
EMSCRIPTEN_KEEPALIVE void web_poke(unsigned addr, unsigned value) {
    if(loaded&&addr>=0x6000&&addr<=0x7fff)if(auto fx=dynamic_cast<NesFxRacingPc*>(_console->GetMapper())){fx->RecordRam()[addr-0x6000]=value&255;return;}
    if (loaded) _console->GetMemoryManager()->DebugWrite(addr & 65535, value & 255, true);
}
EMSCRIPTEN_KEEPALIVE void *web_save_ptr() {
    if(loaded)if(auto fx=dynamic_cast<NesFxRacingPc*>(_console->GetMapper()))return fx->RecordRam();
    return loaded ? retro_get_memory_data(RETRO_MEMORY_SAVE_RAM) : nullptr;
}
EMSCRIPTEN_KEEPALIVE unsigned web_save_size() {
    if(loaded&&dynamic_cast<NesFxRacingPc*>(_console->GetMapper()))return 131072;
    return loaded ? retro_get_memory_size(RETRO_MEMORY_SAVE_RAM) : 0;
}
EMSCRIPTEN_KEEPALIVE void web_reset() { if (loaded) retro_reset(); }
EMSCRIPTEN_KEEPALIVE unsigned web_state_size() {
    if (!loaded) return 0;
    std::stringstream stream;
    _console->GetSaveStateManager()->SaveState(stream);
    replayState = stream.str();
    return replayState.size() <= 2097152 ? replayState.size() : 0;
}
EMSCRIPTEN_KEEPALIVE unsigned web_state_save(void *data, unsigned size) {
    if (!loaded || size != replayState.size() || size > 2097152) return 0;
    std::memcpy(data, replayState.data(), size);
    return 1;
}
EMSCRIPTEN_KEEPALIVE unsigned web_state_load(const void *data, unsigned size) {
    if (!loaded || size < 58 || size > 2097152) return 0;
    // ROM名の長さを含むヘッダーを、この固定ROMのものと完全一致させる。
    std::stringstream expected;
    _console->GetSaveStateManager()->GetSaveStateHeader(expected);
    const std::string header = expected.str();
    if (size < header.size() || std::memcmp(data, header.data(), header.size())) return 0;
    try { return retro_unserialize(data, size) ? 1 : 0; }
    catch (...) { return 0; }
}
#ifdef FX_PRESENTATION
#include "presentation-host.inc"
#endif
}
