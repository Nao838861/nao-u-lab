// 実姿勢を読む入力追従器。ロード後は web_run と web_peek だけで走らせる。
// CPU/WRAM/姿勢/時計への書込み、save state、加速、skip は使用しない。
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import {ReplayRecorder,loadState} from '../web/replay.js';
import {unpackReplay,sha256} from '../web/replay-format.js';
import {REPLAY as CURRENT_REPLAY} from '../web/replay-version.js';
import {REPLAY_VERSIONS} from '../web/replay-versions.js';
const archivedEpoch=Number(process.argv.find(x=>x.startsWith('--epoch='))?.split('=')[1]||(process.argv.includes('--legacy')?3:0));
const legacy=!!archivedEpoch;
const REPLAY=legacy?REPLAY_VERSIONS.find(v=>v.epoch===archivedEpoch):CURRENT_REPLAY;
assert.ok(REPLAY,'Requested replay version must be archived');
const outputPrefix=legacy?(archivedEpoch===3?'legacy-replay-':`epoch${archivedEpoch}-replay-`):'replay-';
import {snapshot} from '../web/race.js';
import createCore from '../web/emulator/core.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const mode=process.argv.includes('--grip')?'grip':'drift';
const limit=Number(process.argv.find(x=>x.startsWith('--frames='))?.split('=')[1]||10000);
const stopLaps=Number(process.argv.find(x=>x.startsWith('--laps='))?.split('=')[1]||5);
const out=path.join(root,'emulator','build','drive-'+mode);
fs.mkdirSync(out,{recursive:true});
const {route,tune}=JSON.parse(fs.readFileSync(path.join(root,'emulator','drive-fixture.json')));
const rom=fs.readFileSync(path.join(root,'web',legacy?REPLAY.romPath:'assets/game.nes'));
const wasmBinary=fs.readFileSync(path.join(root,'web','emulator','core.wasm'));
const core=await createCore({wasmBinary});
const ptr=core._malloc(rom.length);core.HEAPU8.set(rom,ptr);
assert.equal(core._web_load_rom(ptr,rom.length),1);core._free(ptr);
const rd=(addr,n=1)=>{let value=0;for(let i=0;i<n;i++)value+=core._web_peek(addr+i)*2**(8*i);return value;};
const signed=(addr,n)=>{const v=rd(addr,n);return v>=2**(n*8-1)?v-2**(n*8):v;};
const wrap=a=>((a+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;

function target(x,y,look) {
  let best=Infinity,bi=0,bt=0;
  for(let i=0;i<route.length;i++) {
    const p=route[i],q=route[(i+1)%route.length],dx=q[0]-p[0],dy=q[1]-p[1];
    const t=Math.max(0,Math.min(1,((x-p[0])*dx+(y-p[1])*dy)/(dx*dx+dy*dy)));
    const d=(x-p[0]-t*dx)**2+(y-p[1]-t*dy)**2;
    if(d<best){best=d;bi=i;bt=t;}
  }
  const segment=bi,distance=Math.sqrt(best);
  for(let z=0;z<route.length;z++) {
    const p=route[bi],q=route[(bi+1)%route.length],len=Math.hypot(q[0]-p[0],q[1]-p[1]),remaining=(1-bt)*len;
    if(look<=remaining){const t=bt+look/len;return{x:p[0]+t*(q[0]-p[0]),y:p[1]+t*(q[1]-p[1]),segment,distance};}
    look-=remaining;bi=(bi+1)%route.length;bt=0;
  }
  return{x:route[bi][0],y:route[bi][1],segment,distance};
}

function controls() {
  const x=signed(0x41,3)/256,y=signed(0x44,3)/256,vx=signed(0x4b,2)/256,vy=signed(0x4e,2)/256,speed=Math.hypot(vx,vy);
  const tx=target(x,y,tune.look_base+speed*tune.look_speed);
  const heading=rd(0x48,2)*Math.PI*2/65536;
  const desired=Math.atan2(tx.x-x,-(tx.y-y));
  const error=wrap(desired-heading-signed(0x51,2)*Math.PI*2/65536*tune.yaw_prediction);
  // 新ルールでは舵を戻して回復を待つ。状態を書き換えず入力だけを変える。
  if(!legacy&&rd(0x6772)&&!rd(0x6771)&&speed<0.5)return {mask:0,x,y,speed,error,segment:tx.segment,distance:tx.distance};
  let mask=1;
  if(error>tune.deadband)mask|=128;
  if(error<-tune.deadband)mask|=64;
  if(speed>tune.drift_speed&&Math.abs(error)>tune.drift_angle)mask|=2;
  if(Math.abs(error)>tune.brake_angle&&speed>tune.brake_speed)mask=(mask&~1)|2;
  return {mask,x,y,speed,error,segment:tx.segment,distance:tx.distance};
}


const run=(n,m=0)=>{for(let i=0;i<n;i++)core._web_run(m);};
run(180);if(mode==='grip'){run(1,32);run(2);}run(1,8);
while(rd(0x6720)!==1)run(1);
const recorder=new ReplayRecorder();recorder.begin(core,mode);const samples=[];
for(let frame=0;frame<limit;frame++){
 const mask=controls().mask;recorder.input(mask);core._web_run(mask);
 if(frame%120===0)samples.push({frame,hash:await sha256(core.HEAPU8.slice(core._web_pixels(),core._web_pixels()+256*240*4)),race:snapshot(core)});
 if(rd(0x6720)===2)break;
}
const race=snapshot(core);if(race.state!==2)console.error({race,position:controls(),tail:rd(0x6772),grass:rd(0x6771)});assert.equal(race.state,2);assert.equal(race.laps,5);
const replay=Object.assign(await recorder.finish(core,race),{epoch:REPLAY.epoch,compat:REPLAY.compat,rom:REPLAY.rom,core:REPLAY.core});assert.ok(replay);
const {state,inputs}=await unpackReplay(replay,REPLAY);
const c=await createCore({wasmBinary});const ptr2=c._malloc(rom.length);c.HEAPU8.set(rom,ptr2);assert.equal(c._web_load_rom(ptr2,rom.length),1);c._free(ptr2);
loadState(c,state);
for(let i=0;i<inputs.length;i++){
 c._web_run(inputs[i]);
 if(i%120===0){const sample=samples[i/120];assert.deepEqual(snapshot(c),sample.race,'race frame '+i);assert.equal(await sha256(c.HEAPU8.slice(c._web_pixels(),c._web_pixels()+256*240*4)),sample.hash,'pixels frame '+i);}
}
assert.deepEqual(snapshot(c),race);assert.equal(await sha256(c.HEAPU8.slice(c._web_pixels(),c._web_pixels()+256*240*4)),replay.finalHash);
fs.mkdirSync(path.join(root,'build'),{recursive:true});
fs.writeFileSync(path.join(root,'build',outputPrefix+mode+'.json'),JSON.stringify(replay));
const result={mode,rom:REPLAY.rom,core:REPLAY.core,epoch:REPLAY.epoch,passed:true,frames:inputs.length,ticks:race.ticks,lapTicks:race.lapTicks,checkpoints:samples.length,stateBytes:state.length,stateGzipBytes:Buffer.from(replay.state,'base64').length,inputGzipBytes:Buffer.from(replay.inputs,'base64').length,jsonBytes:Buffer.byteLength(JSON.stringify(replay))};
fs.writeFileSync(path.join(root,'verification',outputPrefix+mode+'.json'),JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify(result,null,2));
