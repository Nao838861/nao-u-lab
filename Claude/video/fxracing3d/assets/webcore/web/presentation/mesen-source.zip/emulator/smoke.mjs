// JS/WASM を実行し、固定ROMのタイトル・両モードの入力と出力を検査する。
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import createCore from '../web/emulator/core.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const out=path.join(root,'emulator','build','smoke');
fs.mkdirSync(out,{recursive:true});
const rom=fs.readFileSync(path.join(root,'web','assets','game.nes'));
const wasmBinary=fs.readFileSync(path.join(root,'web','emulator','core.wasm'));
const reports=[];
for(const mode of ['drift','grip']) {
  const core=await createCore({wasmBinary});
  const ptr=core._malloc(rom.length);core.HEAPU8.set(rom,ptr);
  assert.equal(core._web_load_rom(ptr,rom.length),1,'ROM loads');core._free(ptr);
  const run=(n,mask=0)=>{for(let i=0;i<n;i++)core._web_run(mask);};
  const word=addr=>core._web_peek(addr)|(core._web_peek(addr+1)<<8)|(core._web_peek(addr+2)<<16);
  const shot=name=>fs.writeFileSync(path.join(out,`${mode}-${name}.rgba`),core.HEAPU8.slice(core._web_pixels(),core._web_pixels()+256*240*4));
  run(180);assert.equal(core._web_peek(0x6720),0,'title state');shot('title');
  if(mode==='grip'){run(1,32);run(2);}
  run(1,8);run(190);
  assert.equal(core._web_peek(0x6720),1,'race state');
  assert.equal(core._web_peek(0x674d),mode==='grip'?1:0,'selected mode');
  const ticksBefore=word(0x6726);run(60);const ticksAfter=word(0x6726);
  assert.equal(ticksAfter-ticksBefore,60,'ROM clock runs exactly once each frame');
  let audioPeak=0,audioFrames=0;
  let minimumLitPixels=256*240;
  const publishedBefore=core._web_peek(0x02)|(core._web_peek(0x03)<<8);
  const t=performance.now();
  for(let frame=0;frame<120;frame++){
    core._web_run(1);
    let lit=0;
    const pixels=core._web_pixels();
    for(let i=0;i<256*240*4;i+=4)lit+=core.HEAPU8[pixels+i]+core.HEAPU8[pixels+i+1]+core.HEAPU8[pixels+i+2]>0;
    minimumLitPixels=Math.min(minimumLitPixels,lit);
    const count=core._web_audio_frames();audioFrames+=count;
    const start=core._web_audio()>>1;
    for(let i=0;i<count*2;i++)audioPeak=Math.max(audioPeak,Math.abs(core.HEAP16[start+i]));
  }
  const ms=performance.now()-t;
  shot('race');
  assert(minimumLitPixels>5000,'accelerating race stays rendered');
  const publishedAfter=core._web_peek(0x02)|(core._web_peek(0x03)<<8);
  assert(publishedAfter-publishedBefore>=119,'accelerating full transfers publish every frame');
  assert(audioFrames>90000 && audioFrames<100000,'48kHz NTSC audio output');
  assert(audioPeak>0,'engine audio is nonzero');
  assert.equal(core._web_sample_rate(),48000);
  assert(core._web_fps()>60 && core._web_fps()<60.2);
  const before=core._web_peek(0x6cff);core._web_poke(0x6cff,123);
  assert.equal(core._web_peek(0x6cff),123,'WRAM poke and peek');core._web_poke(0x6cff,before);
  reports.push({mode,state:core._web_peek(0x6720),modeByte:core._web_peek(0x674d),fps:core._web_fps(),sampleRate:core._web_sample_rate(),audioFrames,audioPeak,ticksBefore,ticksAfter,minimumLitPixels,publishedBefore,publishedAfter,run120FramesMs:ms,saveBytes:core._web_save_size()});
}
const result={romSha256:crypto.createHash('sha256').update(rom).digest('hex'),tests:reports};
fs.writeFileSync(path.join(out,'results.json'),JSON.stringify(result,null,2)+'\n');
console.log(JSON.stringify(result,null,2));
