// 実姿勢を読む入力追従器。ロード後は web_run と web_peek だけで走らせる。
// CPU/WRAM/姿勢/時計への書込み、save state、加速、skip は使用しない。
import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import crypto from 'node:crypto';
import assert from 'node:assert/strict';
import zlib from 'node:zlib';
import createCore from '../web/emulator/core.js';

const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const mode=process.argv.includes('--grip')?'grip':'drift';
const limit=Number(process.argv.find(x=>x.startsWith('--frames='))?.split('=')[1]||10000);
const stopLaps=Number(process.argv.find(x=>x.startsWith('--laps='))?.split('=')[1]||5);
const out=path.join(root,'emulator','build','drive-'+mode);
fs.mkdirSync(out,{recursive:true});
const {route,tune}=JSON.parse(fs.readFileSync(path.join(root,'emulator','drive-fixture.json')));
const rom=fs.readFileSync(path.join(root,'web','assets','game.nes'));
const wasmBinary=fs.readFileSync(path.join(root,'web','emulator','core.wasm'));
const core=await createCore({wasmBinary});
const ptr=core._malloc(rom.length);core.HEAPU8.set(rom,ptr);
assert.equal(core._web_load_rom(ptr,rom.length),1);core._free(ptr);
const rd=(addr,n=1)=>{let value=0;for(let i=0;i<n;i++)value+=core._web_peek(addr+i)*2**(8*i);return value;};
const signed=(addr,n)=>{const v=rd(addr,n);return v>=2**(n*8-1)?v-2**(n*8):v;};
const wrap=a=>((a+Math.PI)%(Math.PI*2)+Math.PI*2)%(Math.PI*2)-Math.PI;

function target(x,y,look) {
  let best=Infinity,bi=0,bt=0;
  for(let i=0;i<route.length;i++) {
    const p=route[i],q=route[(i+1)%route.length],dx=q[0]-p[0],dy=q[1]-p[1];
    const t=Math.max(0,Math.min(1,((x-p[0])*dx+(y-p[1])*dy)/(dx*dx+dy*dy)));
    const d=(x-p[0]-t*dx)**2+(y-p[1]-t*dy)**2;
    if(d<best){best=d;bi=i;bt=t;}
  }
  const segment=bi,distance=Math.sqrt(best);
  for(let z=0;z<route.length;z++) {
    const p=route[bi],q=route[(bi+1)%route.length],len=Math.hypot(q[0]-p[0],q[1]-p[1]),remaining=(1-bt)*len;
    if(look<=remaining){const t=bt+look/len;return{x:p[0]+t*(q[0]-p[0]),y:p[1]+t*(q[1]-p[1]),segment,distance};}
    look-=remaining;bi=(bi+1)%route.length;bt=0;
  }
  return{x:route[bi][0],y:route[bi][1],segment,distance};
}

function controls() {
  const x=signed(0x41,3)/256,y=signed(0x44,3)/256,vx=signed(0x4b,2)/256,vy=signed(0x4e,2)/256,speed=Math.hypot(vx,vy);
  const tx=target(x,y,tune.look_base+speed*tune.look_speed);
  const heading=rd(0x48,2)*Math.PI*2/65536;
  const desired=Math.atan2(tx.x-x,-(tx.y-y));
  const error=wrap(desired-heading-signed(0x51,2)*Math.PI*2/65536*tune.yaw_prediction);
  let mask=1;
  if(error>tune.deadband)mask|=128;
  if(error<-tune.deadband)mask|=64;
  if(speed>tune.drift_speed&&Math.abs(error)>tune.drift_angle)mask|=2;
  if(Math.abs(error)>tune.brake_angle&&speed>tune.brake_speed)mask=(mask&~1)|2;
  return {mask,x,y,speed,error,segment:tx.segment,distance:tx.distance};
}


const run=(n,m=0)=>{for(let i=0;i<n;i++)core._web_run(m);};
run(180);if(mode==='grip'){run(1,32);run(2);}run(1,8);run(190);
const inputs=[];
for(let f=0;f<10000;f++){const m=controls().mask;inputs.push(m);core._web_run(m);if(rd(0x6720)===2)break;}
assert.equal(rd(0x6720),2);
const save=()=>core.HEAPU8.slice(core._web_save_ptr(),core._web_save_ptr()+core._web_save_size());
const inspect=()=>({best:rd(0x673b,3),valid:rd(0x6747),slot:rd(0x440),state:rd(0x6720),ticks:rd(0x6726,3)});
const early=save(),atGoal=inspect();run(120);const late=save(),after=inspect();
fs.mkdirSync(path.join(root,'build'),{recursive:true});
fs.writeFileSync(path.join(root,'build',mode+'-early.sav'),early);fs.writeFileSync(path.join(root,'build',mode+'-late.sav'),late);
const restored=[];
for(const bytes of [early,late]) {
 const c=await createCore({wasmBinary});const p=c._malloc(rom.length);c.HEAPU8.set(rom,p);c._web_load_rom(p,rom.length);c._free(p);c.HEAPU8.set(bytes,c._web_save_ptr());for(let i=0;i<180;i++)c._web_run(0);
 if(mode==='grip'){c._web_run(32);c._web_run(0);for(let i=0;i<60;i++)c._web_run(0);}
 const peek=(a,n=1)=>{let v=0;for(let i=0;i<n;i++)v+=c._web_peek(a+i)*2**(8*i);return v;};
 restored.push({best:peek(0x673b,3),valid:peek(0x6747),ghost:peek(0x440)});
}
const report={mode,atGoal,after,restored,diff:early.reduce((n,v,i)=>n+(v!==late[i]),0),inputBytes:inputs.length,inputGzip:zlib.gzipSync(Uint8Array.from(inputs)).length,saveBytes:late.length};
fs.writeFileSync(path.join(root,'build',mode+'-save-probe.json'),JSON.stringify(report,null,2)+'\n');
console.log(JSON.stringify(report,null,2));
