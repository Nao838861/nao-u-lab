EverDrive N8 Pro / MMC5Racing 3D v005 実機移植 r001

最新 v005 の 6502 コード・物理・音・GSU プログラム・車/木/家のモデルを
変更せず、実機用のメモリ配置と FPGA 回路を用意する。
立方体用 development/superfx-lab の ABI1 回路・配布物は保持する。
この回路は v005 専用の ABI2 サブセットで、一般の MMC5 互換回路ではない。

構成
- 6502: $5113〜$5117 の 8KB バンク、128KB SRAM、$5205/$5206 の乗算。
- GSU: MiSTer の既存コア。25MHz、最新 ROM の CLS=1 を使用する。
- 内蔵 RAM: 作業/コード 8KB、描画中画像 12KB、二重行テーブル、
  二重ラインバッファ、GSU キャッシュ。256×192 の範囲外の行は保持しない。
- 完成画像を CHR PSRAM の $20000/$24000 に転送する。
  ROM が見ている二つの描画領域のうち、非表示側だけを内蔵 RAM に割り当てる。
  CPU/GSU による表示側の読み戻しには対応しない。v005 はこれを必要としない。
- Mode7 DSP: カメラから192行のアフィン係数を生成する専用演算器。
  DSP-1 の命令互換はない。符号付き乗除算を直列化し、回路規模を抑える。
- CHR ROM: 最初の8KBは元の文字、続く102400バイトは元の640×640 2bpp地面。
  128KBにパディングする。PRGは元ROMの前半1MBをそのまま使用する。
- PPU: 実際のNT/属性/パターン読み出しから座標を追跡する。
  1行先の地面を生成し、FX色0を透過して、8×1単位でパレットを選ぶ。
  HUDのスプライト取得と画像転送で外部バスを仲裁する。
- 画像転送と地面表の両方が完成してから、元ROMのNMIが表示を切り替える。

ビルド（このリポジトリのルートから）
  python development/superfx-lab/tools/lab.py fetch
  python development/superfx-lab/tools/lab.py install-ghdl
  python development/racing-n8pro/tools/build.py quartus

Quartus Prime Lite 24.1、Cyclone IV E / EP4CE6F17C8 のデバイスデータが必要。
出力先は build/racing-n8pro。立方体用の出力先とは別。
端子設定は superfx-lab と同じ、固定したメーカー公開ソースから取得する。

検証（<nes_superfx> は別リポジトリの GPT/projects/nes_superfx）
  python development/racing-n8pro/tools/verify_gsu.py --emulator-project <nes_superfx>
  python development/racing-n8pro/tools/verify_dsp.py
  python development/racing-n8pro/tools/verify_display.py
  python development/racing-n8pro/tools/verify_boot.py --emulator-project <nes_superfx>

GSU比較は v005 の既存ビルド/開始スナップショットと racing_profile.exe を使う。
起動テストでは同梱 py65 で実際の6502初期化とNMIを実行し、外部バス操作を
トップ RTL へ再生する。命令フェッチの一部を省く機能検証であり、
6502/PPU全体をサイクル精密に再現するテストではない。
表示テストの外部メモリ70nsは検証用モデルで、実基板を測定した値ではない。

配布
  python development/racing-n8pro/tools/package.py --emulator-project <nes_superfx> --dest <配布先>
検証結果と回路ソースのハッシュが一致したときだけ配布する。

制約
- 実物の N8 Pro / ファミコン上での起動・画面・音は、配布時点では未確認。
- 外部CPU/PPU/SRAM/PSRAMバスの遅延制約は未完了。内部25MHzの合格とは分ける。
- 50MHzのPC版と性能は同じではない。実機での30fps維持は未確認。
- RESETからEverDriveメニューへ戻る機能、ゲーム内メニュー、セーブステートなし。
  メニューへは本体電源の入れ直しで戻る。
- NTSC、無スクロールの256×192描画＋下部HUDに絞る。PAL/別ROMは未検証。
- 最大容量へのFitはビット数だけで判断しない。M9Kの実ブロック消費も確認する。

ライセンス: 新規 RTL/ツールは GPL-3.0-or-later。
GSU のライセンスと出自は ../superfx-lab/vendor に同梱。
