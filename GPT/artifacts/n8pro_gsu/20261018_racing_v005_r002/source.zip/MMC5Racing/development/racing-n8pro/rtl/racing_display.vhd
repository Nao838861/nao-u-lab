-- SPDX-License-Identifier: GPL-3.0-or-later
-- CHR PSRAM: font $00000, packed 640x640 texture $02000,
-- completed FX banks $20000/$24000. Two on-chip scanline buffers.
library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity racing_display is
 port(clk,reset,enabled,active,front,hide,commit,frame_done : in std_logic;
      ppu_a : in std_logic_vector(13 downto 0);ppu_rd : in std_logic;
      ppu_q : out std_logic_vector(7 downto 0);
      chr_a : out unsigned(21 downto 0);chr_d : out std_logic_vector(7 downto 0);
      chr_we_n, chr_drive : out std_logic;chr_q : in std_logic_vector(7 downto 0);
      copy_a : out unsigned(13 downto 0);copy_q : in std_logic_vector(7 downto 0);
      copied, underrun : out std_logic;
      row_a : out unsigned(10 downto 0);row_q : in std_logic_vector(31 downto 0));
end;
architecture rtl of racing_display is
 type lines_t is array(0 to 63) of std_logic_vector(17 downto 0);
 signal lines : lines_t;
 attribute ramstyle : string;attribute ramstyle of lines : signal is "M9K";
 signal line_q,line_d : std_logic_vector(17 downto 0);
 signal line_we : std_logic:='0';signal line_wa,line_ra : natural range 0 to 63:=0;
 signal nt_x : unsigned(4 downto 0):=(others=>'0');signal nt_y : unsigned(4 downto 0):=(others=>'0');
 signal fine : unsigned(2 downto 0):="111";signal nt_fine : unsigned(2 downto 0):="000";
 signal rd_sync : std_logic_vector(2 downto 0):="111";
 signal sprite,grant : std_logic;
 signal state : natural range 0 to 16:=0;signal phase : natural range 0 to 3:=0;
 signal x : natural range 0 to 255:=0;signal y : natural range 0 to 191:=0;
 signal request_y : natural range 0 to 191:=0;signal request,commit_pending : std_logic:='0';
 signal last_y : natural range 0 to 255:=255;
 signal row_base : natural range 0 to 1535:=0;
 signal u,v,du,dv : signed(31 downto 0):=(others=>'0');
 signal bg,valid : std_logic:='0';signal lo,hi,fxlo,fxhi : std_logic_vector(7 downto 0):=(others=>'0');
 signal copy_pending,copy_bank,copy_complete : std_logic:='0';
 signal copy_index : unsigned(13 downto 0):=(others=>'0');signal copy_phase : natural range 0 to 3:=0;
 signal texture_address : unsigned(21 downto 0);
 signal fx_address : unsigned(13 downto 0);
 signal fault : std_logic:='0';
 function btoi(b : std_logic) return natural is begin if b='1' then return 1;else return 0;end if;end;
 function pixel_address(px,py : natural) return unsigned is
   variable xx,yy:unsigned(7 downto 0);
 begin
   xx:=to_unsigned(px,8);yy:=to_unsigned(py,8);
   return yy(7) & xx(7) & yy(6 downto 3) & xx(6 downto 3) & yy(2 downto 0) & '0';
 end;
begin
 copied<=copy_complete;underrun<=fault;copy_a<=copy_index;
 -- Finish an already-started write, including its address/data hold cycle,
 -- before handing the PSRAM bus to a sprite fetch (at most 120 ns).
 sprite<='1' when ppu_rd='0' and (enabled='0' or ppu_a(13 downto 12)="01")
                   and not (copy_pending='1' and state=0 and copy_phase/=0) else '0';
 grant<=not sprite;
 line_ra<=btoi(nt_fine(0))*32+to_integer(nt_x);
 fx_address<=pixel_address(x,y);
 texture_address<=to_unsigned(8192,22)+shift_left(resize(unsigned(v(25 downto 16)),22),7)+
                  shift_left(resize(unsigned(v(25 downto 16)),22),5)+resize(unsigned(u(25 downto 18)),22);
 row_a<=to_unsigned(row_base,11);
 process(all) begin
   chr_a<=to_unsigned(0,22);chr_d<=copy_q;chr_we_n<='1';chr_drive<='0';
   if sprite='1' then chr_a<=resize(unsigned(ppu_a(12 downto 0)),22);
   elsif state=5 or state=6 then
     chr_a<=to_unsigned(16#20000#+btoi(front)*16384,22)+resize(fx_address,22);
     if state=6 then chr_a<=to_unsigned(16#20001#+btoi(front)*16384,22)+resize(fx_address,22);end if;
   elsif state=7 or state=8 then chr_a<=texture_address;
   elsif copy_pending='1' and state=0 then
     chr_a<=to_unsigned(16#20000#+btoi(copy_bank)*16384,22)+resize(copy_index,22);
     if copy_phase/=0 then chr_drive<='1';end if;
     if copy_phase=1 or copy_phase=2 then chr_we_n<='0';end if;
   end if;
   ppu_q<=x"00";
   if enabled='0' or ppu_a(13 downto 12)="01" then ppu_q<=chr_q;
   elsif ppu_a(13)='1' then
     if ppu_a(9 downto 6)="1111" and nt_y<24 then ppu_q<=line_q(17 downto 16)&line_q(17 downto 16)&line_q(17 downto 16)&line_q(17 downto 16);end if;
   elsif active='1' then
     if nt_y>=24 then ppu_q<=x"FF";
     elsif ppu_a(3)='1' then ppu_q<=line_q(15 downto 8);else ppu_q<=line_q(7 downto 0);end if;
   end if;
 end process;
 process(clk) begin
   if rising_edge(clk) then
     line_q<=lines(line_ra);
     if line_we='1' then lines(line_wa)<=line_d;end if;
   end if;
 end process;
 process(clk)
   variable actual_y,next_y : natural;
   variable color : unsigned(1 downto 0);
   variable mask : std_logic_vector(7 downto 0);
   variable palette : std_logic_vector(1 downto 0);
 begin
   if rising_edge(clk) then
     rd_sync<=rd_sync(1 downto 0)&ppu_rd;line_we<='0';
     if reset='1' then
       state<=0;phase<=0;request<='0';copy_pending<='0';copy_complete<='0';
       copy_phase<=0;last_y<=255;fine<="111";nt_fine<="000";fault<='0';commit_pending<='0';
     else
       if frame_done='1' then copy_pending<='1';copy_complete<='0';copy_bank<=not front;copy_index<=(others=>'0');copy_phase<=0;end if;
       if commit='1' then commit_pending<='1';last_y<=255;copy_complete<='0';end if;
       if commit_pending='1' then request<='1';request_y<=0;commit_pending<='0';end if;
       if rd_sync(2 downto 1)="10" and enabled='1' then
         if unsigned(ppu_a)>=16#2000# and unsigned(ppu_a)<16#3000# and ppu_a(9 downto 6)/="1111" then
           nt_x<=unsigned(ppu_a(4 downto 0));nt_y<=unsigned(ppu_a(9 downto 5));
           if unsigned(ppu_a(4 downto 0))=0 then nt_fine<=fine+1;else nt_fine<=fine;end if;
         elsif ppu_a(13 downto 12)="00" then
           fine<=unsigned(ppu_a(2 downto 0));
           actual_y:=to_integer(nt_y)*8+to_integer(unsigned(ppu_a(2 downto 0)));
           if active='1' and actual_y/=last_y and actual_y<192 then
             last_y<=actual_y;
             if actual_y=191 then next_y:=0;else next_y:=actual_y+1;end if;
             request<='1';request_y<=next_y;
             if state/=0 then fault<='1';end if;
           end if;
         end if;
       end if;
       case state is
         when 0 =>
           if request='1' and copy_phase=0 then
             request<='0';y<=request_y;x<=0;row_base<=btoi(front)*768+request_y*4;state<=1;
           elsif copy_pending='1' then
             if grant='0' then copy_phase<=0;
             elsif copy_phase=3 then
               copy_phase<=0;
               if copy_index=16#37FF# then copy_pending<='0';copy_complete<='1';
               elsif copy_index=16#27FF# then copy_index<=to_unsigned(16#3000#,14);
               else copy_index<=copy_index+1;end if;
             else copy_phase<=copy_phase+1;end if;
           end if;
         when 1 => state<=2;phase<=0;
         when 2 =>
           case phase is
             when 0=>u<=signed(row_q);
             when 1=>v<=signed(row_q);
             when 2=>du<=resize(signed(row_q(29 downto 0)),32);bg<=row_q(31);valid<=row_q(30);
             when others=>dv<=signed(row_q);
           end case;
           if phase=3 then state<=4;phase<=0;else row_base<=row_base+1;phase<=phase+1;state<=3;end if;
         when 3 => state<=2;
         when 4 => lo<=x"00";hi<=x"00";phase<=0;state<=5;
         when 5 | 6 =>
           if grant='0' then phase<=0;
           elsif phase<2 then phase<=phase+1;
           else
             phase<=0;
             if state=5 then fxlo<=chr_q;state<=6;
             else fxhi<=chr_q;state<=7;end if;
           end if;
         when 7 =>
           if grant='1' then phase<=1;else phase<=0;end if;
           if valid='1' and u>=0 and v>=0 and u<640*65536 and v<640*65536 then state<=8;
           else
             lo(7-(x mod 8))<=bg;hi(7-(x mod 8))<='1';state<=9;
           end if;
         when 8 =>
           if grant='0' then phase<=0;
           elsif phase<2 then phase<=phase+1;
           else
             color:=unsigned(chr_q(7-to_integer(unsigned(u(17 downto 16)))*2 downto 6-to_integer(unsigned(u(17 downto 16)))*2));
             lo(7-(x mod 8))<=color(0);hi(7-(x mod 8))<=color(1);state<=9;phase<=0;
           end if;
         when 9 =>
           u<=u+du;v<=v+dv;
           if x mod 8=7 then state<=10;else x<=x+1;state<=7;end if;
         when 10 =>
           mask:=fxlo or fxhi;if hide='1' then mask:=x"00";end if;
           palette:='0'&bg;if mask/=x"00" then palette:='1'&bg;end if;
           line_d<=palette & ((hi and not mask) or (fxhi and mask)) & ((lo and not mask) or (fxlo and mask));
           line_wa<=(y mod 2)*32+x/8;line_we<='1';
           if x=255 then state<=0;else x<=x+1;state<=4;end if;
         when others=>state<=0;
       end case;
     end if;
   end if;
 end process;
end;
