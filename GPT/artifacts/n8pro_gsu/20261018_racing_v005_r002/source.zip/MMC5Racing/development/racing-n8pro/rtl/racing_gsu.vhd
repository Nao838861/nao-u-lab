-- SPDX-License-Identifier: GPL-3.0-or-later
-- Racing ABI2: one physical back buffer, compressed to the 192 visible rows.
-- The display controller copies a completed frame to external CHR PSRAM.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity racing_gsu is
  port(clk : in std_logic;
    cpu_a : in std_logic_vector(15 downto 0);
    cpu_di : in std_logic_vector(7 downto 0);
    cpu_rw, m2 : in std_logic;
    cpu_do : out std_logic_vector(7 downto 0);
    selected, host_strobe, running, frame_done, reset_out : out std_logic;
    front_out : out std_logic;
    mode_out : out std_logic_vector(2 downto 0);
    copy_a : in unsigned(13 downto 0);
    copy_q : out std_logic_vector(7 downto 0));
end;
architecture rtl of racing_gsu is
  type fb_t is array(0 to 12287) of std_logic_vector(7 downto 0);
  type work_t is array(0 to 8191) of std_logic_vector(7 downto 0);
  signal fb : fb_t;
  signal workram : work_t;
  attribute ramstyle : string;
  attribute ramstyle of fb, workram : signal is "M9K";
  signal sync_m2 : std_logic_vector(1 downto 0) := "00";
  signal phase : integer range 0 to 7 := 0;
  signal strobe, reg_sel, ram_sel, reset_n : std_logic;
  signal reset_count : integer range 0 to 15 := 15;
  signal gsu_addr : std_logic_vector(23 downto 0);
  signal gsu_q, gsu_ram_d, gsu_ram_q, fb_q, work_q : std_logic_vector(7 downto 0);
  signal gsu_ram_a : std_logic_vector(16 downto 0);
  signal gsu_ce_n, gsu_we_n, rd_n, wr_n : std_logic;
  signal page : unsigned(2 downto 0) := "100";
  signal window_enable, front, go : std_logic := '0';
  signal mode : unsigned(2 downto 0) := "000";
  signal generation : unsigned(15 downto 0) := (others=>'0');
  signal faults : std_logic_vector(7 downto 0) := (others=>'0');
  signal ticks, last_ticks : unsigned(31 downto 0) := (others=>'0');
  signal fill_address, fill_length, fill_cursor, fill_remaining : unsigned(15 downto 0) := (others=>'0');
  signal fill_low, fill_high : std_logic_vector(7 downto 0) := (others=>'0');
  signal fill_busy, fill_done, fill_error, fill_odd : std_logic := '0';
  signal mem_a : unsigned(15 downto 0);
  signal mem_d : std_logic_vector(7 downto 0);
  signal mem_we, mem_valid, mem_work, read_work, read_valid : std_logic;
  signal fb_index, copy_index : integer range 0 to 12287;
  signal copy_valid, copy_read_valid : std_logic;
  signal copy_read_q : std_logic_vector(7 downto 0);
  function visible(a : unsigned(13 downto 0)) return boolean is
  begin return not (a(13)='1' and a(11)='1'); end;
  function compact(a : unsigned(13 downto 0)) return natural is
  begin
    if not visible(a) then return 0;
    elsif a(13)='1' and a(12)='1' then return to_integer(a)-2048;
    else return to_integer(a); end if;
  end;
begin
  strobe <= '1' when sync_m2(1)='1' and phase=2 else '0';
  host_strobe <= strobe;
  reg_sel <= '1' when cpu_a>=x"4800" and cpu_a<=x"4AFF" else '0';
  ram_sel <= '1' when cpu_a>=x"6000" and cpu_a<=x"7FFF" and window_enable='1' else '0';
  selected <= '1' when reg_sel='1' or ram_sel='1' or (cpu_a>=x"4FD0" and cpu_a<=x"4FF5") else '0';
  gsu_addr <= x"003" & "00" & cpu_a(9 downto 0) when reg_sel='1' else x"003030";
  rd_n <= not (reg_sel and strobe and cpu_rw);
  wr_n <= not (reg_sel and strobe and not cpu_rw and not fill_busy);
  reset_n <= '1' when reset_count=0 else '0';
  reset_out <= not reset_n;
  running <= go;
  front_out <= front; mode_out <= std_logic_vector(mode);
  -- CPU only accesses this RAM while the GSU and fill engine are idle.
  mem_a <= fill_cursor when fill_busy='1' else
           page & unsigned(cpu_a(12 downto 0)) when ram_sel='1' and go='0' else
           unsigned(gsu_ram_a(15 downto 0));
  mem_d <= fill_high when fill_busy='1' and fill_odd='1' else
           fill_low when fill_busy='1' else
           cpu_di when ram_sel='1' and go='0' else gsu_ram_d;
  mem_we <= reset_n and (fill_busy or
            (ram_sel and not go and strobe and not cpu_rw) or
            (go and not gsu_ce_n and not gsu_we_n));
  mem_work <= mem_a(15);
  mem_valid <= '1' when (mem_a>=32768 and mem_a<40960) or
                       (mem_a<32768 and visible(mem_a(13 downto 0))) else '0';
  fb_index <= compact(mem_a(13 downto 0));
  copy_index <= compact(copy_a);
  copy_valid <= '1' when visible(copy_a) else '0';
  copy_q <= copy_read_q when copy_read_valid='1' else x"00";
  gsu_ram_q <= work_q when read_work='1' and read_valid='1' else
               fb_q when read_valid='1' else x"00";
  process(clk) begin
    if rising_edge(clk) then
      fb_q <= fb(fb_index);
      work_q <= workram(to_integer(mem_a(12 downto 0)));
      read_work <= mem_work; read_valid <= mem_valid;
      if mem_we='1' and mem_valid='1' then
        if mem_work='1' then workram(to_integer(mem_a(12 downto 0))) <= mem_d;
        else fb(fb_index) <= mem_d; end if;
      end if;
    end if;
  end process;
  process(clk) begin
    if rising_edge(clk) then
      copy_read_q<=fb(copy_index);copy_read_valid<=copy_valid;
    end if;
  end process;
  process(all)
    variable product : unsigned(15 downto 0);
  begin
    cpu_do <= x"00";
    if reg_sel='1' then cpu_do <= gsu_q;
    elsif ram_sel='1' and go='0' and fill_busy='0' then cpu_do<=gsu_ram_q;
    elsif cpu_a>=x"4FD0" and cpu_a<=x"4FD3" then
      cpu_do <= std_logic_vector(last_ticks(to_integer(unsigned(cpu_a(1 downto 0)))*8+7 downto to_integer(unsigned(cpu_a(1 downto 0)))*8));
    else case cpu_a is
      when x"4FE0" => cpu_do <= "00000" & std_logic_vector(mode);
      when x"4FE1" => cpu_do <= "00000" & std_logic_vector(page);
      when x"4FE2" => cpu_do <= "0000000" & front;
      when x"4FE3" => cpu_do <= faults;
      when x"4FE4" => cpu_do <= std_logic_vector(generation(7 downto 0));
      when x"4FE5" => cpu_do <= std_logic_vector(generation(15 downto 8));
      when x"4FE6" => cpu_do <= x"19";
      when x"4FE7" => cpu_do <= x"01";
      when x"4FEF" => cpu_do <= "00000" & fill_error & fill_done & fill_busy;
      when x"4FF0" => cpu_do <= "0000000" & reset_n;
      when x"4FF1" => cpu_do <= x"53";
      when x"4FF2" => cpu_do <= x"02";
      when x"4FF3" => cpu_do <= "0000000" & window_enable;
      when x"4FF5" => cpu_do <= x"01";
      when others => null;
    end case; end if;
  end process;
  process(clk)
    variable ending : unsigned(16 downto 0);
  begin
    if rising_edge(clk) then
      sync_m2 <= sync_m2(0) & m2;
      if sync_m2(1)='0' then phase<=0; elsif phase<7 then phase<=phase+1; end if;
      frame_done <= '0';
      if reset_count>0 then
        reset_count<=reset_count-1; go<='0'; mode<="000"; front<='0'; page<="100";
        generation<=(others=>'0'); faults<=(others=>'0');
        fill_busy<='0'; fill_done<='0'; fill_error<='0'; ticks<=(others=>'0');
      else
        if reg_sel='0' or cpu_a=x"4830" then
          go<=gsu_q(5);
          if go='1' and gsu_q(5)='0' then last_ticks<=ticks; frame_done<='1'; end if;
          if go='0' and gsu_q(5)='1' then ticks<=(others=>'0'); end if;
        end if;
        if go='1' then ticks<=ticks+1; end if;
        if fill_busy='1' then
          fill_cursor<=fill_cursor+1; fill_remaining<=fill_remaining-1; fill_odd<=not fill_odd;
          if fill_remaining=1 then fill_busy<='0'; fill_done<='1'; end if;
        end if;
      end if;
      if strobe='1' and cpu_rw='0' then
        case cpu_a is
          when x"4FF0" => if cpu_di=x"A5" then reset_count<=15; window_enable<='0'; end if;
          when x"4FF3" => window_enable<=cpu_di(0);
          when x"4FE0" => if unsigned(cpu_di)<=4 then mode<=unsigned(cpu_di(2 downto 0)); end if;
          when x"4FE1" => if unsigned(cpu_di)<5 then page<=unsigned(cpu_di(2 downto 0)); end if;
          when x"4FE2" => if go='0' and fill_busy='0' then front<=cpu_di(0); generation<=generation+1; else faults(1)<='1'; end if;
          when x"4FE3" => faults<=faults and not cpu_di;
          when x"4FE8" => fill_address(7 downto 0)<=unsigned(cpu_di);
          when x"4FE9" => fill_address(15 downto 8)<=unsigned(cpu_di);
          when x"4FEA" => fill_length(7 downto 0)<=unsigned(cpu_di);
          when x"4FEB" => fill_length(15 downto 8)<=unsigned(cpu_di);
          when x"4FEC" => fill_low<=cpu_di;
          when x"4FED" => fill_high<=cpu_di;
          when x"4FEE" =>
            ending:=resize(fill_address,17)+resize(fill_length,17);
            if cpu_di=x"01" and go='0' and fill_busy='0' and ending<=40960 then
              fill_cursor<=fill_address; fill_remaining<=fill_length; fill_odd<='0'; fill_error<='0';
              if fill_length/=0 then fill_busy<='1'; fill_done<='0'; else fill_done<='1'; end if;
            else fill_error<='1'; faults(4)<='1'; end if;
          when x"4FEF" => if cpu_di(1)='1' then fill_done<='0'; end if;
                            if cpu_di(2)='1' then fill_error<='0'; end if;
          when others => null;
        end case;
      end if;
    end if;
  end process;
  core : entity work.GSU port map(CLK=>clk, RST_N=>reset_n, ENABLE=>'1',
    ADDR=>gsu_addr, DI=>cpu_di, DO=>gsu_q, RD_N=>rd_n, WR_N=>wr_n,
    SYSCLKF_CE=>strobe, SYSCLKR_CE=>strobe, TURBO=>'0', FASTROM=>'0', IRQ_N=>open,
    ROM_A=>open, ROM_DI=>x"00", ROM_RD_N=>open,
    RAM_A=>gsu_ram_a, RAM_DI=>gsu_ram_q, RAM_DO=>gsu_ram_d, RAM_WE_N=>gsu_we_n, RAM_CE_N=>gsu_ce_n,
    SS_BUSY=>'0', SS_WR=>'0', SS_DO=>open, DBG_IN_CACHE=>open, DBG_MC=>open, DBG_GO_CNT=>open);
end;
