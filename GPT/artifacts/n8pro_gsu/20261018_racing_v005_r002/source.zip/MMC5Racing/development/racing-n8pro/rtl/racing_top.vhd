-- SPDX-License-Identifier: GPL-3.0-or-later
-- N8 Pro only: physical pin names follow domgetter/minimal_nrom.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity racing_top is
  port (
    cpu_d : inout std_logic_vector(7 downto 0);
    cpu_a : in std_logic_vector(14 downto 0);
    cpu_romsel, cpu_rw, m2 : in std_logic;
    cpu_irq, cpu_dir, cpu_ex : out std_logic;
    ppu_d : out std_logic_vector(7 downto 0);
    ppu_a : in std_logic_vector(13 downto 0);
    ppu_rd, ppu_wr, ppu_a13n : in std_logic;
    ppu_ciram_ce, ppu_ciram_a10, ppu_dir, ppu_ex : out std_logic;
    prg_d : inout std_logic_vector(7 downto 0);
    prg_a : out std_logic_vector(21 downto 0);
    prg_ce, prg_oe, prg_we, prg_ub, prg_lb : out std_logic;
    chr_d : inout std_logic_vector(7 downto 0);
    chr_a : out std_logic_vector(21 downto 0);
    chr_ce, chr_oe, chr_we, chr_ub, chr_lb : out std_logic;
    sram_ce, sram_oe, sram_we, mcu_miso : out std_logic;
    mcu_mosi, mcu_clk, mcu_ss, clk50, fds_sw, mcu_busy : in std_logic;
    led, pwm, fifo_rxf, boot_on : out std_logic;
    gpio : inout std_logic_vector(3 downto 0);
    exp : inout std_logic_vector(9 downto 0);
    xio : out std_logic_vector(2 downto 0);
    rx : in std_logic; tx : out std_logic);
end;
architecture rtl of racing_top is
  signal clk25 : std_logic:='0';
  signal ca : std_logic_vector(15 downto 0);
  signal gq,dq,pq : std_logic_vector(7 downto 0);
  signal gsel,strobe,go,frame_done,reset,front,commit,enabled : std_logic;
  signal mode : std_logic_vector(2 downto 0);
  signal copy_a : unsigned(13 downto 0);signal copy_q : std_logic_vector(7 downto 0);
  signal row_a : unsigned(10 downto 0);signal row_q : std_logic_vector(31 downto 0);
  signal dsp_sel,dsp_wr,dsp_busy,dsp_ready,dsp_active,dsp_error,dsp_front,dsp_hide : std_logic;
  signal copied,underrun : std_logic;
  signal chr_addr : unsigned(21 downto 0);signal chr_write_data : std_logic_vector(7 downto 0);signal chr_write_n,chr_drive : std_logic;
  type banks_t is array(0 to 4) of std_logic_vector(7 downto 0);
  signal banks : banks_t := (x"00",x"80",x"80",x"FE",x"80");
  signal mul_a,mul_b : unsigned(7 downto 0):=(others=>'0');signal product:unsigned(15 downto 0);
  signal slot : natural range 0 to 4;
  signal selected_bank,regq : std_logic_vector(7 downto 0);
  signal romsel,sramsel,regsel,drive_cpu : std_logic;
begin
  process(clk50) begin if rising_edge(clk50) then clk25<=not clk25;end if;end process;
  ca<=not cpu_romsel & cpu_a;
  fx: entity work.racing_gsu port map(clk25,ca,cpu_d,cpu_rw,m2,gq,gsel,strobe,go,frame_done,reset,front,mode,copy_a,copy_q);
  dsp_sel<='1' when ca>=x"4FA0" and ca<=x"4FB7" else '0';
  dsp_wr<=dsp_sel and strobe and not cpu_rw;
  commit<='1' when ca=x"4FE2" and strobe='1' and cpu_rw='0' and copied='1' and dsp_ready='1' else '0';
  dsp: entity work.mode7_dsp port map(clk25,reset,unsigned(ca(4 downto 0)),cpu_d,dsp_wr,commit,cpu_d(0),dq,dsp_busy,dsp_ready,dsp_active,dsp_error,dsp_front,dsp_hide,row_a,row_q);
  enabled<='1' when mode/="000" else '0';
  display: entity work.racing_display port map(clk25,reset,enabled,dsp_active,dsp_front,dsp_hide,commit,frame_done,ppu_a,ppu_rd,pq,chr_addr,chr_write_data,chr_write_n,chr_drive,chr_d,copy_a,copy_q,copied,underrun,row_a,row_q);
  slot<=to_integer(unsigned(ca(15 downto 13)))-3 when ca>=x"6000" else 0;
  selected_bank<=banks(slot);
  regsel<='1' when gsel='1' or dsp_sel='1' or (ca>=x"5113" and ca<=x"5117") or ca=x"5205" or ca=x"5206" else '0';
  romsel<='1' when ca>=x"8000" and (selected_bank(7)='1' or slot=4) else '0';
  sramsel<='1' when ca>=x"6000" and romsel='0' and gsel='0' else '0';
  product<=mul_a*mul_b;
  process(all) begin
    regq<=gq;
    if dsp_sel='1' then
      regq<=dq;
      if ca=x"4FB0" then regq(1)<=dsp_ready and copied;end if;
    elsif ca>=x"5113" and ca<=x"5117" then regq<=banks(to_integer(unsigned(ca(2 downto 0)))-3);
    elsif ca=x"5205" then regq<=std_logic_vector(product(7 downto 0));
    elsif ca=x"5206" then regq<=std_logic_vector(product(15 downto 8));
    end if;
  end process;
  process(clk25) begin
    if rising_edge(clk25) and strobe='1' and cpu_rw='0' then
      if ca>=x"5113" and ca<=x"5117" then banks(to_integer(unsigned(ca(2 downto 0)))-3)<=cpu_d;
      elsif ca=x"5205" then mul_a<=unsigned(cpu_d);
      elsif ca=x"5206" then mul_b<=unsigned(cpu_d);end if;
    end if;
  end process;
  drive_cpu<=m2 and cpu_rw and (romsel or sramsel or regsel);
  cpu_dir<=drive_cpu;
  cpu_d<=regq when drive_cpu='1' and regsel='1' else prg_d when drive_cpu='1' else (others=>'Z');
  prg_a<="00000" & selected_bank(3 downto 0) & ca(12 downto 0) when sramsel='1' else
          "00" & selected_bank(6 downto 0) & ca(12 downto 0);
  -- Keep write data driven through the M2 falling edge (SRAM /WE release).
  prg_d<=cpu_d when sramsel='1' and cpu_rw='0' else (others=>'Z');
  prg_ce<=not romsel;prg_oe<=not (romsel and cpu_rw);prg_we<='1';prg_lb<='0';prg_ub<='1';
  sram_ce<=sramsel;sram_oe<=not (sramsel and cpu_rw);sram_we<=not (sramsel and not cpu_rw and m2);
  chr_a<=std_logic_vector(chr_addr);chr_d<=chr_write_data when chr_drive='1' else (others=>'Z');
  chr_ce<='0';chr_oe<=chr_drive;chr_we<=chr_write_n;chr_lb<='0';chr_ub<='1';
  ppu_d<=pq;ppu_dir<=not ppu_rd when enabled='1' and unsigned(ppu_a)<16#3000# else not ppu_rd and not ppu_a(13);
  ppu_ciram_ce<='1' when enabled='1' else not ppu_a(13);ppu_ciram_a10<=ppu_a(10);
  cpu_irq<='1';cpu_ex<='0';ppu_ex<='0';
  boot_on<='0';fifo_rxf<='1';pwm<='0';led<=underrun or dsp_error;
  mcu_miso<='Z';tx<='Z';gpio<=(others=>'Z');exp<=(others=>'Z');xio<=(others=>'Z');
end;
