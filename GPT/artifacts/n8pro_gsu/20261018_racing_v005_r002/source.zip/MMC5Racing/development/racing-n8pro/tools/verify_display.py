"""PPU の先読み・属性・スプライト競合と外部 RAM 転送を検証する。"""
import json,sys,subprocess
from pathlib import Path
import verify_dsp
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE.parent/'superfx-lab/tools'))
import lab
from build import source_hashes

def main():
    out=lab.ROOT/'build/racing-n8pro/display-test';out.mkdir(parents=True,exist_ok=True)
    cameras=[[0,0,h,181,181,pc,ps] for h,pc,ps in [(320,256,13),(768,253,36),(1536,245,76),(4608,187,174)]]
    rows=[verify_dsp.row(c,y) for c in cameras for y in range(192)]
    (out/'rows.hex').write_text(''.join(f'{v:08X}\n' for r in rows for v in r))
    expected=[]
    for c in cameras:
      for y in range(192):
        r=verify_dsp.row(c,y);u,v,du,dv=r
        def signed(v):return v-2**32 if v>=2**31 else v
        u,v,dv=map(signed,[u,v,dv]);du=du&0x3fffffff;du=du-2**30 if du>=2**29 else du
        bg=r[2]>>31;valid=(r[2]>>30)&1
        for x in range(0,256,8):
          lo=hi=fxmask=0
          for bit in range(8):
            uu=u+(x+bit)*du;vv=v+(x+bit)*dv;color=3 if bg else 2
            if valid and 0<=uu<640*65536 and 0<=vv<640*65536:color=((uu>>20)+(vv>>20))&3
            fx=0 if ((x+bit)//32)%3==0 else (((x+bit)//11+y//7)%4)
            if fx:color=fx;fxmask=1
            lo|=(color&1)<<(7-bit);hi|=(color>>1)<<(7-bit)
          expected.extend([lo,hi,(bg+2*fxmask)*85])
    (out/'expected.hex').write_text(''.join(f'{v:02X}\n' for v in expected))
    source='''library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;use std.textio.all;use std.env.all;
entity tb_display is end;
architecture test of tb_display is
 signal clk:std_logic:='0';signal reset,active,front,commit,fd:std_logic:='0';
 signal pa:std_logic_vector(13 downto 0):=(others=>'0');signal rd:std_logic:='1';signal pq,cq,cd,copyq:std_logic_vector(7 downto 0);
 signal ca:unsigned(21 downto 0);signal we:std_logic;signal copya:unsigned(13 downto 0);signal copied,fault:std_logic;
 signal ra:unsigned(10 downto 0);signal rq:std_logic_vector(31 downto 0);signal trial:natural range 0 to 3:=0;
 type table_t is array(0 to 3071) of std_logic_vector(31 downto 0);
 impure function init_rows return table_t is
  file f:text open read_mode is "rows.hex";variable l:line;variable a:table_t;
 begin for i in a'range loop readline(f,l);hread(l,a(i));end loop;return a;end;
 constant rows:table_t:=init_rows;
 function fxbyte(addr:natural) return std_logic_vector is
  variable a:unsigned(13 downto 0);variable x,y,color:natural;variable q:std_logic_vector(7 downto 0):=x"00";
 begin
  a:=to_unsigned(addr,14);x:=to_integer(a(12 downto 12))*128+to_integer(a(7 downto 4))*8;
  y:=to_integer(a(13 downto 13))*128+to_integer(a(11 downto 8))*8+to_integer(a(3 downto 1));
  if y>=192 then return x"00";end if;
  for i in 0 to 7 loop
   color:=0;if ((x+i)/32) mod 3/=0 then color:=((x+i)/11+y/7) mod 4;end if;
   if a(0)='0' then if color mod 2=1 then q(7-i):='1';end if;
   else if color>=2 then q(7-i):='1';end if;end if;
  end loop;return q;
 end;
 type mem_t is array(0 to 262143) of std_logic_vector(7 downto 0);
 impure function init_mem return mem_t is
  variable m:mem_t:=(others=>x"00");variable c:natural;
 begin
  for y in 0 to 639 loop for x in 0 to 639 loop c:=(x/16+y/16) mod 4;
   m(8192+y*160+x/4)(7-(x mod 4)*2 downto 6-(x mod 4)*2):=std_logic_vector(to_unsigned(c,2));
  end loop;end loop;return m;
 end;
 signal mem:mem_t:=init_mem;
begin
 clk<=not clk after 20 ns;
 dut:entity work.racing_display port map(clk,reset,'1',active,front,'0',commit,fd,pa,rd,pq,ca,cd,we,open,cq,copya,copyq,copied,fault,ra,rq);
 cq<=mem(to_integer(ca)) after 70 ns;
 process(we)begin if rising_edge(we) then mem(to_integer(ca))<=cd;end if;end process;
 process(clk)begin if rising_edge(clk) then copyq<=fxbyte(to_integer(copya));rq<=rows(trial*768+to_integer(ra) mod 768);end if;end process;
 process
  file f:text open read_mode is "expected.hex";variable l:line;
  type expected_t is array(0 to 18431) of std_logic_vector(7 downto 0);variable exp:expected_t;
  variable value:std_logic_vector(7 downto 0);
  procedure readppu(addr:natural;variable value:out std_logic_vector(7 downto 0)) is begin
   pa<=std_logic_vector(to_unsigned(addr,14));rd<='0';wait for 250 ns;value:=pq;rd<='1';wait for 122 ns;
  end;
  procedure tile(x,y:natural;check:boolean) is
   variable q:std_logic_vector(7 downto 0);variable at:natural;
  begin
   at:=(y*32+x)*3;
   readppu(16#2000#+(y/8)*32+x,q);readppu(16#23C0#+(y/32)*8+x/4,q);
   if check then assert q=exp(at+2) report "palette y=" & integer'image(y) & " x=" & integer'image(x) & " got " & to_hstring(q) & " expected " & to_hstring(exp(at+2)) severity failure;end if;
   readppu(y mod 8,q);
   if check then assert q=exp(at) report "low y=" & integer'image(y) & " x=" & integer'image(x) & " got " & to_hstring(q) & " expected " & to_hstring(exp(at)) severity failure;end if;
   readppu(8+y mod 8,q);
   if check then assert q=exp(at+1) report "high y=" & integer'image(y) & " x=" & integer'image(x) severity failure;end if;
  end;
 begin
  for t in 0 to 3 loop
   trial<=t;active<='0';front<='0';reset<='1';wait for 200 ns;wait until falling_edge(clk);reset<='0';
   for i in exp'range loop readline(f,l);hread(l,exp(i));end loop;
   wait until falling_edge(clk);fd<='1';wait until falling_edge(clk);fd<='0';
   wait until copied='1' for 4 ms;assert copied='1' report "DMA timeout" severity failure;
   for i in 0 to 16383 loop assert mem(16#24000#+i)=fxbyte(i) report "DMA mismatch " & integer'image(i) severity failure;end loop;
   wait until falling_edge(clk);front<='1';active<='1';commit<='1';wait until falling_edge(clk);commit<='0';wait for 100 us;
   tile(0,0,true);tile(1,0,true);wait for 930 ns;
   for y in 0 to 191 loop
    if y=20 then wait until falling_edge(clk);fd<='1';wait until falling_edge(clk);fd<='0';end if;
    for x in 2 to 31 loop tile(x,y,true);end loop;
    tile(0,y,false);tile(1,y,false);
    for sprite in 0 to 7 loop
     readppu(16#2000#+((y+1)/8)*32,value);readppu(16#2000#+((y+1)/8)*32,value);
     readppu(16#1000#,value);assert value=x"00" report "sprite read/DMA bus collision" severity failure;
     readppu(16#1008#,value);assert value=x"00" report "sprite read/DMA bus collision" severity failure;
    end loop;
    if y<191 then tile(0,y+1,true);tile(1,y+1,true);else tile(0,192,false);tile(1,192,false);end if;
    wait for 930 ns;
   end loop;
   assert fault='0' report "line underrun" severity failure;
   if copied/='1' then wait until copied='1' for 4 ms;end if;
   assert copied='1' report "concurrent DMA timeout" severity failure;
   for i in 0 to 16383 loop assert mem(16#20000#+i)=fxbyte(i) report "concurrent DMA mismatch " & integer'image(i) severity failure;end loop;
   report "DISPLAY CASE PASS " & integer'image(t);
  end loop;
  report "ALL DISPLAY PIXELS PASSED";stop;wait;
 end process;
end;'''
    (out/'tb_display.vhd').write_text(source);ghdl=lab.ghdl_path()
    lab.run([ghdl,'-a','--std=08',HERE/'rtl/racing_display.vhd',out/'tb_display.vhd'],cwd=out)
    r=subprocess.run([ghdl,'-r','--std=08','tb_display','--assert-level=error','--ieee-asserts=disable-at-0'],cwd=out,capture_output=True,text=True)
    (out/'simulation.log').write_text(r.stdout+r.stderr);print(r.stdout)
    r.check_returncode();assert 'ALL DISPLAY PIXELS PASSED' in r.stdout
    (out/'verification.json').write_text(json.dumps({'status':'pass','sources':source_hashes(),'views':4,'pixels':4*256*192,'dma_during_sprite_fetches':'pass','external_read_delay_ns':70,'hardware_tested':False},indent=2)+'\n')

if __name__=='__main__':main()
