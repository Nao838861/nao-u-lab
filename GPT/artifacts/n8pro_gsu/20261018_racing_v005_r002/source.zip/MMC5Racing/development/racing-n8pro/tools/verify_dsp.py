"""カメラ行テーブルの RTL と整数参照式を比較する。"""
import argparse, json, math, random, struct, sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE.parent/'superfx-lab/tools'))
import lab
from build import source_hashes

def div(a,b):return (abs(a)//abs(b))*(-1 if (a<0)!=(b<0) else 1)
def row(c,y):
    x,z,h,cs,sn,pc,ps=c;dy=y-96;den=ps*128+dy*pc;norm=cs*cs+sn*sn
    if den<=0:return [0,0,0x80000000,0]
    height=h*512;forward=div(height*(pc*128-dy*ps),den);depth=div(forward*pc+height*ps,256)
    if not 0<depth<=144*65536:return [0,0,0,0]
    du=div(-depth*cs*256*5,norm*128);dv=div(depth*sn*256*5,norm*128)
    u=(x*512+div(forward*sn*256,norm))*5+320*65536-128*du
    v=(z*512+div(forward*cs*256,norm))*5+320*65536-128*dv
    if not (-2**30<u<2**30 and -2**30<v<2**30 and -2**22<du<2**22 and -2**22<dv<2**22):return [0,0,0,0]
    return [u&0xffffffff,v&0xffffffff,(du&0x3fffffff)|0x40000000,dv&0xffffffff]

def main():
    out=lab.ROOT/'build/racing-n8pro/dsp-test';out.mkdir(parents=True,exist_ok=True)
    rng=random.Random(517);cases=[]
    for h,pc,ps in [(320,256,13),(768,253,36),(1536,245,76),(4608,187,174)]:
        for i in range(8):
            a=i*math.tau/8;cases.append([rng.randrange(-20000,20000),rng.randrange(-20000,20000),h,round(math.cos(a)*256),round(math.sin(a)*256),pc,ps])
    cases.extend([[0,0,16384,256,0,0,256],[-32768,32767,16384,0,-256,0,256]])
    (out/'camera.hex').write_text(''.join(f'{b:02X}\n' for c in cases for b in struct.pack('<7h',*c)))
    (out/'rows.hex').write_text(''.join(f'{v:08X}\n' for c in cases for y in range(192) for v in row(c,y)))
    source='''library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;
use std.textio.all;use std.env.all;
entity tb_dsp is end;
architecture test of tb_dsp is
 signal clk : std_logic:='0';signal reset,wr,commit,cb : std_logic:='0';
 signal a : unsigned(4 downto 0):=(others=>'0');signal di,q : std_logic_vector(7 downto 0):=(others=>'0');
 signal busy,ready,active,err,front,hide : std_logic;
 signal ra : unsigned(10 downto 0):=(others=>'0');signal rq:std_logic_vector(31 downto 0);
begin
 clk<=not clk after 20 ns;
 dut: entity work.mode7_dsp port map(clk,reset,a,di,wr,commit,cb,q,busy,ready,active,err,front,hide,ra,rq);
 process
  file cameras:text open read_mode is "camera.hex";file expected:text open read_mode is "rows.hex";
  variable l:line;variable b:std_logic_vector(7 downto 0);variable v:std_logic_vector(31 downto 0);variable target:natural;
  procedure write_reg(addr,value:natural) is begin
    wait until falling_edge(clk);a<=to_unsigned(addr,5);di<=std_logic_vector(to_unsigned(value,8));wr<='1';
    wait until falling_edge(clk);wr<='0';
  end;
 begin
  reset<='1';wait for 100 ns;wait until falling_edge(clk);reset<='0';
  for trial in 0 to CASES-1 loop
    for i in 0 to 13 loop readline(cameras,l);hread(l,b);write_reg(i,to_integer(unsigned(b)));end loop;
    target:=1-trial mod 2;write_reg(14,target);write_reg(16,1);
    wait until ready='1' for 12 ms;
    assert ready='1' and err='0' report "DSP timeout/error" severity failure;
    for i in 0 to 767 loop
      ra<=to_unsigned(target*768+i,11);wait for 100 ns;readline(expected,l);hread(l,v);
      assert rq=v report "row mismatch case " & integer'image(trial) & " word " & integer'image(i) & " expected " & to_hstring(v) & " got " & to_hstring(rq) severity failure;
    end loop;
    wait until falling_edge(clk);commit<='1';if target=1 then cb<='1';else cb<='0';end if;
    wait until falling_edge(clk);commit<='0';wait for 40 ns;
    assert ready='0' and active='1' and err='0' report "commit failed" severity failure;
    report "DSP CASE PASS " & integer'image(trial);
  end loop;
  report "ALL DSP ROWS PASSED";stop;wait;
 end process;
end;'''.replace('CASES',str(len(cases)))
    (out/'tb_dsp.vhd').write_text(source);ghdl=lab.ghdl_path()
    lab.run([ghdl,'-a','--std=08',HERE/'rtl/serial_math.vhd',HERE/'rtl/mode7_dsp.vhd',out/'tb_dsp.vhd'],cwd=out)
    r=lab.run([ghdl,'-r','--std=08','tb_dsp','--assert-level=error','--ieee-asserts=disable-at-0'],cwd=out,capture_output=True,text=True)
    (out/'simulation.log').write_text(r.stdout+r.stderr);print(r.stdout)
    assert 'ALL DSP ROWS PASSED' in r.stdout
    (out/'verification.json').write_text(json.dumps({'status':'pass','sources':source_hashes(),'cameras':len(cases),'rows':len(cases)*192,'words':len(cases)*768,'hardware_tested':False},indent=2)+'\n')

if __name__=='__main__':main()
