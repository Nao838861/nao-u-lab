-- SPDX-License-Identifier: GPL-3.0-or-later
-- Signed low-48-bit multiply / truncating signed divide, one bit per clock.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity serial_math is
  port(clk, reset, start, divide : in std_logic;
       a,b : in signed(47 downto 0);
       result : out signed(47 downto 0); done : out std_logic);
end;
architecture rtl of serial_math is
  signal busy, divmode, negative : std_logic := '0';
  signal leftv, rightv, accum : unsigned(47 downto 0) := (others=>'0');
  signal count : integer range 0 to 47 := 0;
begin
  process(clk)
    variable remnext : unsigned(48 downto 0);
    variable difference : unsigned(49 downto 0);
    variable qnext, product : unsigned(47 downto 0);
  begin
    if rising_edge(clk) then
      done<='0';
      if reset='1' then busy<='0';
      elsif start='1' and busy='0' then
        busy<='1';divmode<=divide;negative<=a(47) xor b(47);count<=0;accum<=(others=>'0');
        if divide='1' then
          leftv<=unsigned(abs(a));rightv<=unsigned(abs(b));
        else leftv<=unsigned(a);rightv<=unsigned(b);end if;
      elsif busy='1' then
        if divmode='1' then
          remnext:=accum & leftv(47);qnext:=leftv(46 downto 0) & '0';
          difference:=resize(remnext,50)-resize(rightv,50);
          if difference(49)='0' then remnext:=difference(48 downto 0);qnext(0):='1';end if;
          accum<=remnext(47 downto 0);leftv<=qnext;
          if count=47 then
            if negative='1' then result<=-signed(qnext);else result<=signed(qnext);end if;
          end if;
        else
          product:=accum;if rightv(0)='1' then product:=product+leftv;end if;
          accum<=product;leftv<=shift_left(leftv,1);rightv<=shift_right(rightv,1);
          if count=47 then result<=signed(product);end if;
        end if;
        if count=47 then busy<='0';done<='1';else count<=count+1;end if;
      end if;
    end if;
  end process;
end;
