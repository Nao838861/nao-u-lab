-- SPDX-License-Identifier: GPL-3.0-or-later
-- Signed low-48-bit multiply / truncating signed divide, one bit per clock.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity serial_math is
  generic(POSITIVE_DIVISOR : boolean := false; RIGHT_OPERAND_BITS : positive := 48);
  port(clk, reset, start, divide : in std_logic;
       a,b : in signed(47 downto 0);
       result : out signed(47 downto 0); done : out std_logic);
end;
architecture rtl of serial_math is
  signal busy, divmode, negative : std_logic := '0';
  signal leftv,accum : unsigned(47 downto 0) := (others=>'0');
  signal rightv : unsigned(RIGHT_OPERAND_BITS-1 downto 0) := (others=>'0');
  signal count : integer range 0 to 47 := 0;
begin
  process(clk)
    variable remnext : unsigned(48 downto 0);
    variable add_a,add_b,difference : unsigned(49 downto 0);
    variable sum_wide : unsigned(50 downto 0);
    variable qnext, product : unsigned(47 downto 0);
  begin
    if rising_edge(clk) then
      done<='0';
      if reset='1' then busy<='0';
      elsif start='1' and busy='0' then
        busy<='1';divmode<=divide;count<=0;
        if POSITIVE_DIVISOR then negative<=a(47);else negative<=a(47) xor b(47);end if;accum<=(others=>'0');
        if divide='1' then
          leftv<=unsigned(abs(a));
          if POSITIVE_DIVISOR then rightv<=resize(unsigned(b),RIGHT_OPERAND_BITS);negative<=a(47);
          else rightv<=resize(unsigned(abs(b)),RIGHT_OPERAND_BITS);end if;
        else leftv<=unsigned(a);rightv<=resize(unsigned(b),RIGHT_OPERAND_BITS);end if;
      elsif busy='1' then
        if divmode='1' then
          add_a:=resize(accum & leftv(47),50);add_b:=not resize(rightv,50);
        else
          add_a:=resize(accum,50);add_b:=(others=>'0');
          if rightv(0)='1' then add_b:=resize(leftv,50);end if;
        end if;
        -- Appending 1 to both operands supplies the subtraction carry-in.
        sum_wide:=(add_a & divmode)+(add_b & divmode);
        if divmode='1' then
          remnext:=accum & leftv(47);qnext:=leftv(46 downto 0) & '0';
          difference:=sum_wide(50 downto 1);
          if difference(49)='0' then remnext:=difference(48 downto 0);qnext(0):='1';end if;
          accum<=remnext(47 downto 0);leftv<=qnext;
          if count=47 then
            if negative='1' then result<=-signed(qnext);else result<=signed(qnext);end if;
          end if;
        else
          product:=sum_wide(48 downto 1);
          accum<=product;leftv<=shift_left(leftv,1);if RIGHT_OPERAND_BITS<48 then rightv<=unsigned(shift_right(signed(rightv),1));
          else rightv<=shift_right(rightv,1);end if;
          if count=47 then result<=signed(product);end if;
        end if;
        if count=47 then busy<='0';done<='1';else count<=count+1;end if;
      end if;
    end if;
  end process;
end;
