library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity mode7_dsp is
  port(clk, reset : in std_logic;
    cpu_a : in unsigned(4 downto 0);cpu_di : in std_logic_vector(7 downto 0);
    cpu_wr, commit : in std_logic; commit_bank : in std_logic;
    cpu_do : out std_logic_vector(7 downto 0);
    busy_o, ready_o, active_o, error_o, front_o, hide_o : out std_logic;
    row_a : in unsigned(10 downto 0); row_q : out std_logic_vector(31 downto 0));
end;
architecture compare of mode7_dsp is
signal candidate_cpu_do,reference_cpu_do : std_logic_vector(7 downto 0);
signal candidate_busy_o,reference_busy_o : std_logic;
signal candidate_ready_o,reference_ready_o : std_logic;
signal candidate_active_o,reference_active_o : std_logic;
signal candidate_error_o,reference_error_o : std_logic;
signal candidate_front_o,reference_front_o : std_logic;
signal candidate_hide_o,reference_hide_o : std_logic;
signal candidate_row_q,reference_row_q : std_logic_vector(31 downto 0);
begin
cpu_do<=candidate_cpu_do;
busy_o<=candidate_busy_o;
ready_o<=candidate_ready_o;
active_o<=candidate_active_o;
error_o<=candidate_error_o;
front_o<=candidate_front_o;
hide_o<=candidate_hide_o;
row_q<=candidate_row_q;
candidate_dut:entity work.mode7_dsp_candidate port map(clk=>clk,reset=>reset,cpu_a=>cpu_a,cpu_di=>cpu_di,cpu_wr=>cpu_wr,commit=>commit,commit_bank=>commit_bank,cpu_do=>candidate_cpu_do,busy_o=>candidate_busy_o,ready_o=>candidate_ready_o,active_o=>candidate_active_o,error_o=>candidate_error_o,front_o=>candidate_front_o,hide_o=>candidate_hide_o,row_a=>row_a,row_q=>candidate_row_q);
reference_dut:entity work.mode7_dsp_reference port map(clk=>clk,reset=>reset,cpu_a=>cpu_a,cpu_di=>cpu_di,cpu_wr=>cpu_wr,commit=>commit,commit_bank=>commit_bank,cpu_do=>reference_cpu_do,busy_o=>reference_busy_o,ready_o=>reference_ready_o,active_o=>reference_active_o,error_o=>reference_error_o,front_o=>reference_front_o,hide_o=>reference_hide_o,row_a=>row_a,row_q=>reference_row_q);
process begin wait until falling_edge(clk);wait for 1 ps;
if not is_x(reference_cpu_do) then assert candidate_cpu_do=reference_cpu_do report "EQUIVALENCE mode7_dsp.cpu_do" severity failure;end if;
if not is_x(reference_busy_o) then assert candidate_busy_o=reference_busy_o report "EQUIVALENCE mode7_dsp.busy_o" severity failure;end if;
if not is_x(reference_ready_o) then assert candidate_ready_o=reference_ready_o report "EQUIVALENCE mode7_dsp.ready_o" severity failure;end if;
if not is_x(reference_active_o) then assert candidate_active_o=reference_active_o report "EQUIVALENCE mode7_dsp.active_o" severity failure;end if;
if not is_x(reference_error_o) then assert candidate_error_o=reference_error_o report "EQUIVALENCE mode7_dsp.error_o" severity failure;end if;
if not is_x(reference_front_o) then assert candidate_front_o=reference_front_o report "EQUIVALENCE mode7_dsp.front_o" severity failure;end if;
if not is_x(reference_hide_o) then assert candidate_hide_o=reference_hide_o report "EQUIVALENCE mode7_dsp.hide_o" severity failure;end if;
if not is_x(reference_row_q) then assert candidate_row_q=reference_row_q report "EQUIVALENCE mode7_dsp.row_q" severity failure;end if;
end process;end;
