library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;
entity serial_math is
  generic(POSITIVE_DIVISOR : boolean := false);
  port(clk, reset, start, divide : in std_logic;
       a,b : in signed(47 downto 0);
       result : out signed(47 downto 0); done : out std_logic);
end;
architecture compare of serial_math is
signal candidate_result,reference_result : signed(47 downto 0);
signal candidate_done,reference_done : std_logic;
begin
result<=candidate_result;
done<=candidate_done;
candidate_dut:entity work.serial_math_candidate generic map(POSITIVE_DIVISOR=>POSITIVE_DIVISOR) port map(clk=>clk,reset=>reset,start=>start,divide=>divide,a=>a,b=>b,result=>candidate_result,done=>candidate_done);
reference_dut:entity work.serial_math_reference port map(clk=>clk,reset=>reset,start=>start,divide=>divide,a=>a,b=>b,result=>reference_result,done=>reference_done);
process begin wait until falling_edge(clk);wait for 1 ps;
if not is_x(std_logic_vector(reference_result)) then assert candidate_result=reference_result report "EQUIVALENCE serial_math.result" severity failure;end if;
if not is_x(reference_done) then assert candidate_done=reference_done report "EQUIVALENCE serial_math.done" severity failure;end if;
end process;end;
