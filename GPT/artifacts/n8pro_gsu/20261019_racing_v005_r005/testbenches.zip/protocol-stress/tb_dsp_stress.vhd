library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;use std.textio.all;use std.env.all;
entity tb_dsp_stress is end;architecture test of tb_dsp_stress is
signal clk,reset,wr,commit,cb,busy,ready,active,err,front,hide:std_logic:='0';
signal a:unsigned(4 downto 0):=(others=>'0');signal di,q:std_logic_vector(7 downto 0):=(others=>'0');signal ra:unsigned(10 downto 0):=(others=>'0');signal rq:std_logic_vector(31 downto 0);
signal lfsr:unsigned(15 downto 0):=x"ACE1";
begin clk<=not clk after 20 ns;
dut:entity work.mode7_dsp port map(clk,reset,a,di,wr,commit,cb,q,busy,ready,active,err,front,hide,ra,rq);
process(clk) begin if rising_edge(clk) then
 lfsr<=lfsr(14 downto 0)&(lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));ra<=resize(lfsr mod 1536,11);
end if;end process;
process
 file f:text open read_mode is "stress-cameras.hex";variable l:line;variable value:std_logic_vector(7 downto 0);variable target:natural;
 procedure write_reg(addr,v:natural) is begin
  wait until falling_edge(clk);a<=to_unsigned(addr,5);di<=std_logic_vector(to_unsigned(v mod 256,8));wr<='1';wait until falling_edge(clk);wr<='0';
 end;
 procedure reset_dsp is begin reset<='1';wait for 80 ns;wait until falling_edge(clk);reset<='0';end;
begin
 reset_dsp;
 for trial in 0 to 33-1 loop
  for i in 0 to 13 loop readline(f,l);hread(l,value);write_reg(i,to_integer(unsigned(value)));end loop;
  target:=1;if front='1' then target:=0;end if;
  write_reg(14,target);write_reg(18,trial);write_reg(19,255-trial);write_reg(22,trial mod 2);
  write_reg(16,1);
  if trial<24 then
   -- Registers remain writable while the captured camera is rendering.
   for i in 0 to 13 loop write_reg(i,trial*17+i*29);end loop;
   write_reg(16,1); -- duplicate START while busy
   commit<='1';cb<=front;wait until falling_edge(clk);commit<='0';
   if trial mod 8=7 then
    reset_dsp;assert busy='0' and ready='0' and active='0' severity failure;
   else
    if ready/='1' then wait until ready='1' for 12 ms;end if;
    assert ready='1' and err='1' report "Stress completion" severity failure;
    wait for 70 us;write_reg(16,1); -- START while ready
    cb<=front;commit<='1';wait until falling_edge(clk);commit<='0';wait for 80 ns;assert ready='1' severity failure;
    if target=1 then cb<='1';else cb<='0';end if;
    commit<='1';wait until falling_edge(clk);commit<='0';wait for 80 ns;
    assert ready='0' and active='1' report "Stress commit" severity failure;
   end if;
  else
   wait for 1 us;assert busy='0' and ready='0' and err='1' report "Invalid camera accepted" severity failure;
  end if;
 end loop;
 reset_dsp;write_reg(14,2);write_reg(16,1);wait for 80 ns;assert busy='0' and err='1' severity failure;
 report "ALL STRESS TESTS PASSED DSP";stop;wait;
end process;end;