library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;use std.textio.all;use std.env.all;
entity tb_math_stress is end;architecture test of tb_math_stress is
signal clk,reset,start,divide,done:std_logic:='0';signal a,b,q:signed(47 downto 0):=(others=>'0');
begin clk<=not clk after 20 ns;
dut:entity work.serial_math port map(clk,reset,start,divide,a,b,q,done);
process
 file f:text open read_mode is "math.hex";variable l:line;variable mode:std_logic_vector(3 downto 0);variable av,bv,want:std_logic_vector(47 downto 0);variable trials:natural:=0;
begin
 reset<='1';wait for 80 ns;wait until falling_edge(clk);reset<='0';
 while not endfile(f) loop
  readline(f,l);hread(l,mode);hread(l,av);hread(l,bv);hread(l,want);
  a<=signed(av);b<=signed(bv);divide<=mode(0);start<='1';wait until falling_edge(clk);start<='0';
  for i in 1 to 48 loop
   if i=7 then start<='1';a<=not a;b<=not b;elsif i=8 then start<='0';end if;
   wait until falling_edge(clk);wait for 2 ps;
   if i<48 then assert done='0' report "Early math completion" severity failure;end if;
  end loop;
  assert done='1' and std_logic_vector(q)=want report "Arithmetic boundary mismatch " & integer'image(trials) severity failure;
  wait until falling_edge(clk);wait for 2 ps;assert done='0' severity failure;trials:=trials+1;
 end loop;
 report "ALL STRESS TESTS PASSED math " & integer'image(trials);stop;wait;
end process;end;