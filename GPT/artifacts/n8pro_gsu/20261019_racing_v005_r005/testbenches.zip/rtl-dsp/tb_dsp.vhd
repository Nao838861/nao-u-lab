library ieee;
use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;
use std.textio.all;use std.env.all;
entity tb_dsp is end;
architecture test of tb_dsp is
 signal clk : std_logic:='0';signal reset,wr,commit,cb : std_logic:='0';
 signal a : unsigned(4 downto 0):=(others=>'0');signal di,q : std_logic_vector(7 downto 0):=(others=>'0');
 signal busy,ready,active,err,front,hide : std_logic;
 signal ra : unsigned(10 downto 0):=(others=>'0');signal rq:std_logic_vector(31 downto 0);
begin
 clk<=not clk after 20 ns;
 dut: entity work.mode7_dsp port map(clk,reset,a,di,wr,commit,cb,q,busy,ready,active,err,front,hide,ra,rq);
 process
  file cameras:text open read_mode is "camera.hex";file expected:text open read_mode is "rows.hex";
  variable l:line;variable b:std_logic_vector(7 downto 0);variable v:std_logic_vector(31 downto 0);variable target:natural;
  procedure write_reg(addr,value:natural) is begin
    wait until falling_edge(clk);a<=to_unsigned(addr,5);di<=std_logic_vector(to_unsigned(value,8));wr<='1';
    wait until falling_edge(clk);wr<='0';
  end;
 begin
  reset<='1';wait for 100 ns;wait until falling_edge(clk);reset<='0';
  for trial in 0 to 34-1 loop
    for i in 0 to 13 loop readline(cameras,l);hread(l,b);write_reg(i,to_integer(unsigned(b)));end loop;
    target:=1-trial mod 2;write_reg(14,target);write_reg(16,1);
    wait until ready='1' for 12 ms;
    assert ready='1' and err='0' report "DSP timeout/error" severity failure;
    for i in 0 to 767 loop
      ra<=to_unsigned(target*768+i,11);wait for 100 ns;readline(expected,l);hread(l,v);
      assert rq=v report "row mismatch case " & integer'image(trial) & " word " & integer'image(i) & " expected " & to_hstring(v) & " got " & to_hstring(rq) severity failure;
    end loop;
    wait until falling_edge(clk);commit<='1';if target=1 then cb<='1';else cb<='0';end if;
    wait until falling_edge(clk);commit<='0';wait for 40 ns;
    assert ready='0' and active='1' and err='0' report "commit failed" severity failure;
    report "DSP CASE PASS " & integer'image(trial);
  end loop;
  report "ALL DSP ROWS PASSED";stop;wait;
 end process;
end;