-- SPDX-License-Identifier: GPL-3.0-or-later
-- Camera -> affine scanline table. Exact integer equations of Mode7Ground.hpp.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity mode7_dsp is
  port(clk, reset : in std_logic;
    cpu_a : in unsigned(4 downto 0);cpu_di : in std_logic_vector(7 downto 0);
    cpu_wr, commit : in std_logic; commit_bank : in std_logic;
    cpu_do : out std_logic_vector(7 downto 0);
    busy_o, ready_o, active_o, error_o, front_o, hide_o : out std_logic;
    row_a : in unsigned(10 downto 0); row_q : out std_logic_vector(31 downto 0));
end;
architecture rtl of mode7_dsp is
  type bytes_t is array(0 to 23) of std_logic_vector(7 downto 0);
  signal regs : bytes_t := (others=>(others=>'0'));
  type camera_t is array(0 to 6) of signed(15 downto 0);
  signal c : camera_t := (others=>(others=>'0'));
  type rows_t is array(0 to 511) of std_logic_vector(31 downto 0);
  signal rows0,rows1,rows2 : rows_t;
  signal rows_q0,rows_q1,rows_q2 : std_logic_vector(31 downto 0);
  signal row_bank : unsigned(1 downto 0);
  attribute ramstyle : string;
  attribute ramstyle of rows0,rows1,rows2 : signal is "M9K";
  signal row_we : std_logic := '0';
  signal row_wa : integer range 0 to 1535 := 0;
  signal row_d : std_logic_vector(31 downto 0);
  type gen_t is array(0 to 1) of std_logic_vector(15 downto 0);
  signal gen : gen_t := (others=>(others=>'0'));
  signal hides : std_logic_vector(1 downto 0) := "00";
  signal busy, ready, active, error, front, target, bg, valid : std_logic := '0';
  signal y : integer range 0 to 191 := 0;
  signal state : integer range 0 to 40 := 0;
  signal waiting, math_start, math_div, math_done : std_logic := '0';
  signal ma, mb, result : signed(47 downto 0) := (others=>'0');
  signal denominator,numerator : signed(16 downto 0) := (others=>'0');
  signal height : signed(24 downto 0) := (others=>'0');
  signal norm, forward, depth, du, dv, u, v : signed(31 downto 0) := (others=>'0');
  signal origin : signed(15 downto 0);
  signal origin_step,projected_origin : signed(31 downto 0);
  signal hps : signed(32 downto 0) := (others=>'0');
  function bank(b : std_logic) return natural is
  begin if b='1' then return 1;else return 0;end if;end;
  function wide(a : signed) return signed is begin return resize(a,48);end;
  function times5(a : signed) return signed is begin return shift_left(a,2)+a;end;
begin
  row_q<=rows_q0 when row_bank=0 else rows_q1 when row_bank=1 else rows_q2;
  origin<=c(0) when state=13 else c(1);
  origin_step<=du when state=13 else dv;
  projected_origin<=resize(times5(shift_left(wide(origin),9)+result)+to_signed(320*65536,48)-shift_left(wide(origin_step),7),32);
  busy_o<=busy;ready_o<=ready;active_o<=active;error_o<=error;front_o<=front;hide_o<=hides(bank(front));
  arithmetic : entity work.serial_math generic map(POSITIVE_DIVISOR=>true) port map(clk,reset,math_start,math_div,ma,mb,result,math_done);
  process(clk) begin
    if rising_edge(clk) then
      if row_we='1' then
        case row_wa/512 is
          when 0 => rows0(row_wa mod 512)<=row_d;
          when 1 => rows1(row_wa mod 512)<=row_d;
          when others => rows2(row_wa mod 512)<=row_d;
        end case;
      end if;
      rows_q0<=rows0(to_integer(row_a(8 downto 0)));
      rows_q1<=rows1(to_integer(row_a(8 downto 0)));
      rows_q2<=rows2(to_integer(row_a(8 downto 0)));
      row_bank<=row_a(10 downto 9);
    end if;
  end process;
  process(all) begin
    cpu_do<=x"00";
    if cpu_a<24 then cpu_do<=regs(to_integer(cpu_a));end if;
    case to_integer(cpu_a) is
      when 16 => cpu_do<="0000" & active & error & ready & busy;
      when 17 => cpu_do<=x"01";
      when 20 => cpu_do<=gen(bank(front))(7 downto 0);
      when 21 => cpu_do<=gen(bank(front))(15 downto 8);
      when others => null;
    end case;
  end process;
  process(clk)
    variable packed : std_logic_vector(31 downto 0);
    variable tmp : signed(47 downto 0);
    variable truncated : signed(39 downto 0);
    procedure calculate(a,b : signed; division : std_logic) is
    begin ma<=wide(a);mb<=wide(b);math_div<=division;math_start<='1';waiting<='1';end;
  begin
    if rising_edge(clk) then
      math_start<='0';row_we<='0';
      if reset='1' then
        busy<='0';ready<='0';active<='0';error<='0';front<='0';waiting<='0';state<=0;
        regs<=(others=>(others=>'0'));gen<=(others=>(others=>'0'));hides<="00";
      else
        if cpu_wr='1' and cpu_a<24 then
          if cpu_a=16 then
            if cpu_di=x"01" and busy='0' and ready='0' and unsigned(regs(14))<=1 and regs(14)(0)/=front then
              for i in 0 to 6 loop c(i)<=signed(regs(i*2+1)) & signed(regs(i*2));end loop;
              target<=regs(14)(0);gen(bank(regs(14)(0)))<=regs(19)&regs(18);
              hides(bank(regs(14)(0)))<=regs(22)(0);
              busy<='1';error<='0';state<=0;y<=0;waiting<='0';
            else error<='1';end if;
          elsif cpu_a/=17 and cpu_a/=20 and cpu_a/=21 then regs(to_integer(cpu_a))<=cpu_di;end if;
        end if;
        if commit='1' then
          if ready='1' and busy='0' and target=commit_bank and target/=front then
            front<=target;ready<='0';active<='1';
          else error<='1';end if;
        end if;
        if busy='1' then
          if waiting='1' then
            if math_done='1' then waiting<='0';state<=state+1;end if;
          else
            case state is
              when 0 =>
                norm<=resize(c(3)*c(3),32)+resize(c(4)*c(4),32);
                height<=shift_left(resize(c(2),25),9);
                hps<=shift_left(resize(c(2)*c(6),33),9);state<=1;
              when 1 =>
                if c(2)<=0 or c(2)>16384 or norm<32768 or norm>131072 or c(5)<0 or c(5)>256 or c(6)<0 or c(6)>256 then
                  error<='1';busy<='0';
                else state<=2;end if;
              when 2 =>
                denominator<=shift_left(resize(c(6),17),7)+resize(to_signed(y-96,8)*c(5),17);
                numerator<=shift_left(resize(c(5),17),7)-resize(to_signed(y-96,8)*c(6),17);
                u<=(others=>'0');v<=(others=>'0');du<=(others=>'0');dv<=(others=>'0');bg<='1';valid<='0';state<=3;
              when 3 =>
                if denominator<=0 then state<=30;else bg<='0';calculate(height,numerator,'0');end if;
              when 4 => calculate(result,denominator,'1');
              when 5 => forward<=resize(result,32);calculate(result,c(5),'0');
              when 6 =>
                tmp:=result+wide(hps);
                -- Truncation toward zero: arithmetic shift plus one for a negative fraction.
                -- The shifted signed 48-bit value fits exactly in signed 40 bits.
                truncated:=tmp(47 downto 8);
                if tmp(47)='1' and tmp(7 downto 0)/=0 then truncated:=truncated+1;end if;
                depth<=resize(truncated,32);
                state<=7;
              when 7 =>
                if depth<=0 or depth>144*65536 then state<=30;else calculate(depth,c(3),'0');end if;
              when 8 => calculate(-shift_left(times5(result),1),norm,'1');
              when 9 => du<=resize(result,32);calculate(depth,c(4),'0');
              when 10 => calculate(shift_left(times5(result),1),norm,'1');
              when 11 => dv<=resize(result,32);calculate(forward,c(4),'0');
              when 12 => calculate(shift_left(result,8),norm,'1');
              when 13 =>
                u<=projected_origin;calculate(forward,c(3),'0');
              when 14 => calculate(shift_left(result,8),norm,'1');
              when 15 =>
                v<=projected_origin;state<=16;
              when 16 =>
                if u>-(2**30) and u<2**30 and v>-(2**30) and v<2**30 and du>-(2**22) and du<2**22 and dv>-(2**22) and dv<2**22 then valid<='1';
                else u<=(others=>'0');v<=(others=>'0');du<=(others=>'0');dv<=(others=>'0');end if;
                state<=30;
              when 30 to 33 =>
                row_we<='1';row_wa<=(bank(target)*192+y)*4+((state+2) mod 4);
                case state is
                  when 30 => row_d<=std_logic_vector(u);
                  when 31 => row_d<=std_logic_vector(v);
                  when 32 => row_d<=bg & valid & std_logic_vector(du(29 downto 0));
                  when others => row_d<=std_logic_vector(dv);
                end case;
                state<=state+1;
              when 34 =>
                if y=191 then busy<='0';ready<='1';else y<=y+1;state<=2;end if;
              when others => null;
            end case;
          end if;
        end if;
      end if;
    end if;
  end process;
end;
