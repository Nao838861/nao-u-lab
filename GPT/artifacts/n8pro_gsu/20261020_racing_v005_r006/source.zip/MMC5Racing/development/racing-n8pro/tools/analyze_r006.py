"""r006の採否と残った描画コストを、保存済みの測定値から集計する。"""
import collections, json, re
from optimize_r006 import ROOT


def main():
    read=lambda p:json.loads(p.read_text(encoding='utf-8'))
    report=read(ROOT/'final-full/verification.json');rows=report['all']
    labels={n:int(v,16) for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.([^\s]+)',(ROOT/'final-full/gsu.lbl').read_text())}
    names=['render_entry','mul8','mul15','mul14','transform','faces','clip_plane','intersect','project_model_polygon','project_polygon','raster_polygon','edge_span','edge_rows','fill_spans','divide','tree_transform','car_camera']
    cuts=sorted((labels[n],n) for n in names);counts=collections.Counter()
    profile=read(ROOT/'final-full/profile.json')
    for x in profile:
        group=next((n for a,n in reversed(cuts) if a<=labels[x['label']]),'other')
        counts[group]+=x['clocks']
    total=sum(r['after'] for r in rows)
    # The first three clocks per invocation precede the first assembly label.
    missing=total-sum(counts.values());assert missing==3*len(rows)
    counts['before_first_label']=missing
    route=[r for r in rows if r['name'].startswith('route')]
    software=[];fpga=[]
    for folder in sorted(ROOT.iterdir()):
        if (folder/'result.json').exists():fpga.append(read(folder/'result.json'))
        if folder.name.endswith('-small') and (folder/'verification.json').exists():
            r=read(folder/'verification.json');software.append(dict(variant=folder.name,**{k:r[k] for k in ['status','identical_frames','saving_percent','max_after_ms','rom_sha256']}))
    result=dict(status='pass',rom_sha256=report['rom_sha256'],identical_frames=len(rows),
                saving_percent=report['saving_percent'],route_saving_percent=100*(1-sum(r['after'] for r in route)/sum(r['before'] for r in route)),
                slower_cases=[r for r in rows if r['after']>r['before']],
                cost_by_code_region=[dict(region=k,clocks=v,percent=100*v/total) for k,v in counts.most_common()],
                profile_scope='Native instruction-model clocks attributed by PC; code regions include calls/jumps at their own PC, not inclusive call-stack time',
                software_trials=software,fpga_trials=fpga)
    out=ROOT/'release/summary.json';out.write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k not in ['software_trials','fpga_trials']}))


if __name__=='__main__':main()
