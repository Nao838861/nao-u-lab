"""r004固定ソースから独立した容量最適化案を生成し、同じ25MHz制約でFitする。"""
import argparse,hashlib,json,re,shutil,subprocess
from pathlib import Path
from build import HERE,OUT,lab,prepare

ROOT=OUT/'r005'
REVISION='c0304dccc3b62114d134662336486944c8df8c8a'

def replace(s,a,b):
    assert a in s,a[:80]
    return s.replace(a,b)

def baseline():
    target=ROOT/'reference';target.mkdir(parents=True,exist_ok=True)
    files=[lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',*sorted((HERE/'rtl').glob('*.vhd'))]
    for source in files:
        name=source.relative_to(lab.ROOT).as_posix();dest=target/source.name
        data=subprocess.check_output(['git','show',REVISION+':'+name],cwd=lab.ROOT)
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    return target

def patches(folder,variant):
    if 'rows' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,'type rows_t is array(0 to 1535)','type rows_t is array(0 to 511)')
        s=replace(s,'signal rows : rows_t;','signal rows0,rows1,rows2 : rows_t;\n  signal rows_q0,rows_q1,rows_q2 : std_logic_vector(31 downto 0);\n  signal row_bank : unsigned(1 downto 0);')
        s=replace(s,'attribute ramstyle of rows : signal','attribute ramstyle of rows0,rows1,rows2 : signal')
        s=replace(s,"if row_we='1' then rows(row_wa)<=row_d;end if;\n      row_q<=rows(to_integer(row_a));",'''if row_we='1' then
        case row_wa/512 is
          when 0 => rows0(row_wa mod 512)<=row_d;
          when 1 => rows1(row_wa mod 512)<=row_d;
          when others => rows2(row_wa mod 512)<=row_d;
        end case;
      end if;
      rows_q0<=rows0(to_integer(row_a(8 downto 0)));
      rows_q1<=rows1(to_integer(row_a(8 downto 0)));
      rows_q2<=rows2(to_integer(row_a(8 downto 0)));
      row_bank<=row_a(10 downto 9);''')
        s=replace(s,'  busy_o<=busy;', '''  row_q<=rows_q0 when row_bank=0 else rows_q1 when row_bank=1 else rows_q2;
  busy_o<=busy;''')
        p.write_text(s)
    if 'origin' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,'signal hps :','signal origin : signed(15 downto 0);\n  signal origin_step,projected_origin : signed(31 downto 0);\n  signal hps :')
        s=replace(s,'  busy_o<=busy;', '''  origin<=c(0) when state=13 else c(1);
  origin_step<=du when state=13 else dv;
  projected_origin<=resize(times5(shift_left(wide(origin),9)+result)+to_signed(320*65536,48)-shift_left(wide(origin_step),7),32);
  busy_o<=busy;''')
        s=replace(s,'tmp:=times5(shift_left(wide(c(0)),9)+result)+to_signed(320*65536,48)-shift_left(wide(du),7);\n                u<=resize(tmp,32);','u<=projected_origin;')
        s=replace(s,'tmp:=times5(shift_left(wide(c(1)),9)+result)+to_signed(320*65536,48)-shift_left(wide(dv),7);\n                v<=resize(tmp,32);','v<=projected_origin;')
        p.write_text(s)
    if 'narrow' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,'signal height, denominator, numerator, norm,','signal denominator,numerator : signed(16 downto 0) := (others=>\'0\');\n  signal height : signed(24 downto 0) := (others=>\'0\');\n  signal norm,')
        s=replace(s,'height<=shift_left(resize(c(2),32),9);','height<=shift_left(resize(c(2),25),9);')
        s=replace(s,'denominator<=shift_left(resize(c(6),32),7)+resize(to_signed(y-96,9)*c(5),32);','denominator<=shift_left(resize(c(6),17),7)+resize(to_signed(y-96,8)*c(5),17);')
        s=replace(s,'numerator<=shift_left(resize(c(5),32),7)-resize(to_signed(y-96,9)*c(6),32);','numerator<=shift_left(resize(c(5),17),7)-resize(to_signed(y-96,8)*c(6),17);')
        p.write_text(s)
    if 'subtract' in variant:
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'variable remnext : unsigned(48 downto 0);','variable remnext : unsigned(48 downto 0);\n    variable difference : unsigned(49 downto 0);')
        s=replace(s,"if remnext>=resize(rightv,49) then remnext:=remnext-resize(rightv,49);qnext(0):='1';end if;", "difference:=resize(remnext,50)-resize(rightv,50);\n          if difference(49)='0' then remnext:=difference(48 downto 0);qnext(0):='1';end if;")
        p.write_text(s)
    if 'adder' in variant:
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'variable remnext : unsigned(48 downto 0);','variable remnext : unsigned(48 downto 0);\n    variable add_a,add_b,difference : unsigned(49 downto 0);\n    variable sum_wide : unsigned(50 downto 0);')
        s=replace(s,"elsif busy='1' then\n        if divmode='1' then",'''elsif busy='1' then
        if divmode='1' then
          add_a:=resize(accum & leftv(47),50);add_b:=not resize(rightv,50);
        else
          add_a:=resize(accum,50);add_b:=(others=>'0');
          if rightv(0)='1' then add_b:=resize(leftv,50);end if;
        end if;
        -- Appending 1 to both operands supplies the subtraction carry-in.
        sum_wide:=(add_a & divmode)+(add_b & divmode);
        if divmode='1' then''')
        s=replace(s,"if remnext>=resize(rightv,49) then remnext:=remnext-resize(rightv,49);qnext(0):='1';end if;", "difference:=sum_wide(50 downto 1);\n          if difference(49)='0' then remnext:=difference(48 downto 0);qnext(0):='1';end if;")
        s=replace(s,"product:=accum;if rightv(0)='1' then product:=product+leftv;end if;",'product:=sum_wide(48 downto 1);')
        p.write_text(s)
    if 'positive' in variant:
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'entity serial_math is','entity serial_math is\n  generic(POSITIVE_DIVISOR : boolean := false);')
        s=replace(s,"leftv<=unsigned(abs(a));rightv<=unsigned(abs(b));", "leftv<=unsigned(abs(a));\n          if POSITIVE_DIVISOR then rightv<=unsigned(b);negative<=a(47);\n          else rightv<=unsigned(abs(b));end if;")
        p.write_text(s)
        p=folder/'mode7_dsp.vhd';s=p.read_text();s=replace(s,'entity work.serial_math port map','entity work.serial_math generic map(POSITIVE_DIVISOR=>true) port map');p.write_text(s)
    if 'comb' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,"begin ma<=wide(a);mb<=wide(b);math_div<=division;math_start<='1';waiting<='1';end;", "begin math_start<='1';waiting<='1';end;")
        s=replace(s,'  busy_o<=busy;', '''  -- The controller holds state through start and arithmetic completion.
  -- Select operands combinationally; the arithmetic unit latches them on start.
  process(all) begin
    ma<=(others=>'0');mb<=(others=>'0');math_div<='0';
    case state is
      when 3 => ma<=wide(height);mb<=wide(numerator);
      when 4 => ma<=result;mb<=wide(denominator);math_div<='1';
      when 5 => ma<=result;mb<=wide(c(5));
      when 7 => ma<=wide(depth);mb<=wide(c(3));
      when 8 => ma<=-shift_left(times5(result),1);mb<=wide(norm);math_div<='1';
      when 9 => ma<=wide(depth);mb<=wide(c(4));
      when 10 => ma<=shift_left(times5(result),1);mb<=wide(norm);math_div<='1';
      when 11 => ma<=wide(forward);mb<=wide(c(4));
      when 12 | 14 => ma<=shift_left(result,8);mb<=wide(norm);math_div<='1';
      when 13 => ma<=wide(forward);mb<=wide(c(3));
      when others => null;
    end case;
  end process;
  busy_o<=busy;''')
        p.write_text(s)
    if 'right18' in variant:
        assert 'positive' in variant
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'generic(POSITIVE_DIVISOR : boolean := false);','generic(POSITIVE_DIVISOR : boolean := false; RIGHT_OPERAND_BITS : positive := 48);')
        s=replace(s,"signal leftv, rightv, accum : unsigned(47 downto 0) := (others=>'0');", "signal leftv,accum : unsigned(47 downto 0) := (others=>'0');\n  signal rightv : unsigned(RIGHT_OPERAND_BITS-1 downto 0) := (others=>'0');")
        s=replace(s,"negative<=a(47) xor b(47);count<=0;", "count<=0;\n        if POSITIVE_DIVISOR then negative<=a(47);else negative<=a(47) xor b(47);end if;")
        s=replace(s,'rightv<=unsigned(b);','rightv<=resize(unsigned(b),RIGHT_OPERAND_BITS);')
        s=replace(s,'rightv<=unsigned(abs(b));','rightv<=resize(unsigned(abs(b)),RIGHT_OPERAND_BITS);')
        s=replace(s,'rightv<=shift_right(rightv,1);', '''if RIGHT_OPERAND_BITS<48 then rightv<=unsigned(shift_right(signed(rightv),1));
          else rightv<=shift_right(rightv,1);end if;''')
        p.write_text(s)
        p=folder/'mode7_dsp.vhd';s=p.read_text();s=replace(s,'generic map(POSITIVE_DIVISOR=>true)','generic map(POSITIVE_DIVISOR=>true,RIGHT_OPERAND_BITS=>18)');p.write_text(s)
    if 'compact' in variant:
        p=folder/'racing_gsu.vhd';s=p.read_text()
        s=replace(s,"elsif a(13)='1' and a(12)='1' then return to_integer(a)-2048;\n    else return to_integer(a); end if;", "else return to_integer(a(13) & (a(12) and not a(13)) &\n      ((a(13) and a(12)) or (not a(13) and a(11))) & a(10 downto 0));end if;")
        p.write_text(s)
    if 'shortdiv' in variant:
        assert 'right18' in variant and 'subtract' in variant
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'unsigned(48 downto 0);','unsigned(RIGHT_OPERAND_BITS downto 0);')
        s=replace(s,'unsigned(49 downto 0);','unsigned(RIGHT_OPERAND_BITS+1 downto 0);')
        s=replace(s,'remnext:=accum & leftv(47);','remnext:=accum(RIGHT_OPERAND_BITS-1 downto 0) & leftv(47);')
        s=replace(s,'difference:=resize(remnext,50)-resize(rightv,50);','difference:=resize(remnext,RIGHT_OPERAND_BITS+2)-resize(rightv,RIGHT_OPERAND_BITS+2);')
        s=replace(s,"if difference(49)='0' then remnext:=difference(48 downto 0);", "if difference(RIGHT_OPERAND_BITS+1)='0' then remnext:=difference(RIGHT_OPERAND_BITS downto 0);")
        s=replace(s,'accum<=remnext(47 downto 0);','accum<=resize(remnext(RIGHT_OPERAND_BITS-1 downto 0),48);')
        p.write_text(s)
    if 'mb19' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,"signal ma, mb, result : signed(47 downto 0) := (others=>'0');", "signal ma,result : signed(47 downto 0) := (others=>'0');\n  signal mb : signed(18 downto 0) := (others=>'0');")
        s=replace(s,'ma,mb,result,math_done','ma,wide(mb),result,math_done')
        s=replace(s,'ma<=wide(a);mb<=wide(b);','ma<=wide(a);mb<=resize(b,19);')
        p.write_text(s)
    if 'rowmult' in variant:
        p=folder/'mode7_dsp.vhd';s=p.read_text()
        s=replace(s,'  function bank(b : std_logic)', '''  -- Called only after PC/PS validation (0..256): unsigned 9x7 products.
  function row_product(a : signed(15 downto 0); ordinate : natural) return signed is
    variable magnitude : unsigned(6 downto 0);
    variable product : unsigned(15 downto 0);
  begin
    if ordinate<96 then magnitude:=to_unsigned(96-ordinate,7);
    else magnitude:=to_unsigned(ordinate-96,7);end if;
    product:=unsigned(a(8 downto 0))*magnitude;
    if ordinate<96 then return -signed('0' & product);else return signed('0' & product);end if;
  end;
  function bank(b : std_logic)''')
        s=replace(s,'resize(to_signed(y-96,8)*c(5),17)','row_product(c(5),y)')
        s=replace(s,'resize(to_signed(y-96,8)*c(6),17)','row_product(c(6),y)')
        p.write_text(s)

def main():
    p=argparse.ArgumentParser();p.add_argument('variant');p.add_argument('--generate-only',action='store_true');p.add_argument('--seed',type=int);a=p.parse_args()
    reference=baseline();out=ROOT/a.variant;src=out/'src';src.mkdir(parents=True,exist_ok=True)
    for f in reference.glob('*.vhd'):shutil.copy2(f,src/f.name)
    patches(src,a.variant)
    if a.generate_only:return
    base=OUT/'quartus'
    if not (base/'racing.qsf').exists():base=prepare()
    q=out/'quartus';q.mkdir(exist_ok=True)
    lines=[s for s in (base/'racing.qsf').read_text().splitlines() if '-name VHDL_FILE ' not in s]
    files=[src/n for n in ['dpram_difclk.vhd','GSU_PKG.vhd','GSU.vhd','serial_math.vhd','mode7_dsp.vhd','racing_display.vhd','racing_gsu.vhd','racing_top.vhd']]
    lines += [f'set_global_assignment -name VHDL_FILE "{f.as_posix()}"' for f in files]
    if 'area' in a.variant:lines += ['set_global_assignment -name OPTIMIZATION_TECHNIQUE AREA']
    if 'mux' in a.variant:lines += ['set_global_assignment -name MUX_RESTRUCTURE ON']
    if a.seed is not None:lines += [f'set_global_assignment -name SEED {a.seed}']
    (q/'racing.qsf').write_text('\n'.join(lines)+'\n');(q/'racing.qpf').write_text('PROJECT_REVISION = "racing"\n')
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
    with (out/'quartus.log').open('w') as log:
        r=subprocess.run([lab.quartus_candidates()[0],'--flow','compile','racing'],cwd=q,stdout=log,stderr=subprocess.STDOUT)
    text=(out/'quartus.log').read_text();summary=(q/'output_files/racing.fit.summary').read_text() if (q/'output_files/racing.fit.summary').exists() else ''
    setup=[float(s) for s in re.findall(r'Worst-case setup slack is ([\d.-]+)',text)];hold=[float(s) for s in re.findall(r'Worst-case hold slack is ([\d.-]+)',text)]
    report=dict(variant=a.variant,reference_commit=REVISION,exit_code=r.returncode,sources=hashes,fit_summary=summary,
                logic_elements=int(re.search(r'Total logic elements : ([\d,]+)',summary)[1].replace(',','')) if 'Total logic elements' in summary else None,
                setup_min_ns=min(setup) if setup else None,hold_min_ns=min(hold) if hold else None)
    fit=q/'output_files/racing.fit.rpt'
    if fit.exists():
        match=re.search(r'; \|racing_top\s+;.*?;\s*([\d,]+)\s*;\s*(\d+)\s*;',fit.read_text())
        if match:report['memory_bits']=int(match[1].replace(',',''));report['m9k_blocks']=int(match[2])
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
    r.check_returncode()

if __name__=='__main__':main()
