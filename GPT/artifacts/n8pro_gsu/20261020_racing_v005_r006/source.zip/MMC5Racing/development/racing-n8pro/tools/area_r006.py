"""r005回路から独立した容量削減案を生成する。外部応答クロックは変えない。"""
import argparse, hashlib, json, re, shutil, subprocess
from pathlib import Path
from build import HERE, OUT, lab, prepare
from optimize_r006 import REVISION, ROOT, replace


def baseline():
    target=ROOT/'reference'
    target.mkdir(parents=True,exist_ok=True)
    for f in [lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',*sorted((HERE/'rtl').glob('*.vhd'))]:
        data=subprocess.check_output(['git','show',REVISION+':'+f.relative_to(lab.ROOT).as_posix()],cwd=lab.ROOT)
        dest=target/f.name
        if dest.exists():assert dest.read_bytes()==data
        else:dest.write_bytes(data)
    return target


def patches(folder, flags):
    p=folder/'mode7_dsp.vhd';s=p.read_text()
    if 'depth' in flags:
        s=replace(s,'    variable tmp : signed(47 downto 0);', '    variable tmp : signed(47 downto 0);\n    variable truncated : signed(39 downto 0);')
        s=replace(s,"if tmp<0 then depth<=resize(-shift_right(-tmp,8),32);else depth<=resize(shift_right(tmp,8),32);end if;", """-- Truncation toward zero: arithmetic shift plus one for a negative fraction.
                -- The shifted signed 48-bit value fits exactly in signed 40 bits.
                truncated:=tmp(47 downto 8);
                if tmp(47)='1' and tmp(7 downto 0)/=0 then truncated:=truncated+1;end if;
                depth<=resize(truncated,32);""")
    if 'address' in flags:
        s=replace(s,'row_wa<=bank(target)*768+y*4+state-30;', 'row_wa<=(bank(target)*192+y)*4+((state+2) mod 4);')
    if 'read' in flags:
        s=replace(s,"    if cpu_a<24 then cpu_do<=regs(to_integer(cpu_a));end if;\n    case to_integer(cpu_a) is", """    case to_integer(cpu_a) is
      when 0 to 15 => cpu_do<=regs(to_integer(cpu_a(3 downto 0)));
      when 18 => cpu_do<=regs(18);
      when 19 => cpu_do<=regs(19);
      when 22 => cpu_do<=regs(22);
      when 23 => cpu_do<=regs(23);""")
    p.write_text(s)
    if 'count' in flags:
        p=folder/'serial_math.vhd';s=p.read_text()
        s=replace(s,'negative<=a(47) xor b(47);count<=0;','negative<=a(47) xor b(47);count<=47;')
        s=replace(s,'count=47','count=0')
        s=replace(s,'count<=count+1','count<=count-1')
        p.write_text(s)


def main():
    p=argparse.ArgumentParser();p.add_argument('variant');p.add_argument('--seed',type=int,default=3);p.add_argument('--tag');p.add_argument('--generate-only',action='store_true');a=p.parse_args()
    flags=set(a.variant.split('-'));assert flags<={'baseline','depth','address','read','count'}
    out=ROOT/(a.tag or a.variant);src=out/'src';src.mkdir(parents=True,exist_ok=True)
    for f in baseline().glob('*.vhd'):shutil.copy2(f,src/f.name)
    patches(src,flags)
    if a.generate_only:return
    base=OUT/'quartus'
    if not (base/'racing.qsf').exists():base=prepare()
    q=out/'quartus';q.mkdir(exist_ok=True)
    lines=[s for s in (base/'racing.qsf').read_text().splitlines() if not any('-name '+n+' ' in s for n in ['VHDL_FILE','SEED','OPTIMIZATION_TECHNIQUE'])]
    files=[src/n for n in ['dpram_difclk.vhd','GSU_PKG.vhd','GSU.vhd','serial_math.vhd','mode7_dsp.vhd','racing_display.vhd','racing_gsu.vhd','racing_top.vhd']]
    lines += [f'set_global_assignment -name VHDL_FILE "{f.as_posix()}"' for f in files]
    lines += ['set_global_assignment -name OPTIMIZATION_TECHNIQUE AREA',f'set_global_assignment -name SEED {a.seed}']
    (q/'racing.qsf').write_text('\n'.join(lines)+'\n');(q/'racing.qpf').write_text('PROJECT_REVISION = "racing"\n')
    hashes={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in files}
    with (out/'quartus.log').open('w') as log:
        r=subprocess.run([lab.quartus_candidates()[0],'--flow','compile','racing'],cwd=q,stdout=log,stderr=subprocess.STDOUT)
    text=(out/'quartus.log').read_text();summary=(q/'output_files/racing.fit.summary').read_text() if (q/'output_files/racing.fit.summary').exists() else ''
    setup=[float(s) for s in re.findall(r'Worst-case setup slack is ([\d.-]+)',text)];hold=[float(s) for s in re.findall(r'Worst-case hold slack is ([\d.-]+)',text)]
    report=dict(variant=a.variant,seed=a.seed,reference_commit=REVISION,exit_code=r.returncode,sources=hashes,fit_summary=summary,
                logic_elements=int(re.search(r'Total logic elements : ([\d,]+)',summary)[1].replace(',','')) if 'Total logic elements' in summary else None,
                setup_min_ns=min(setup) if setup else None,hold_min_ns=min(hold) if hold else None)
    fit=q/'output_files/racing.fit.rpt'
    if fit.exists():
        match=re.search(r'; \|racing_top\s+;.*?;\s*([\d,]+)\s*;\s*(\d+)\s*;',fit.read_text())
        if match:report['memory_bits']=int(match[1].replace(',',''));report['m9k_blocks']=int(match[2])
    (out/'result.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report));r.check_returncode()


if __name__=='__main__':main()
