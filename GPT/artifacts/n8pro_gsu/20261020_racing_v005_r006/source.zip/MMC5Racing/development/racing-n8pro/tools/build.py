"""N8 Pro レース回路の合成。立方体版と異なるビルド先を使う。"""
import argparse,hashlib,json,re,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE.parent/'superfx-lab/tools'))
import lab
OUT=lab.ROOT/'build/racing-n8pro'

def prepare(seed=None,area=False):
    q=OUT/'quartus';q.mkdir(parents=True,exist_ok=True)
    if not (lab.BUILD/'quartus/gsu.qsf').exists():lab.prepare()
    base=(lab.BUILD/'quartus/gsu.qsf').read_text()
    lines=[s.replace('TOP_LEVEL_ENTITY n8pro_top','TOP_LEVEL_ENTITY racing_top') for s in base.splitlines() if not re.search(r' -name (VHDL_FILE|SDC_FILE) ',s)]
    files=[lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',*sorted((HERE/'rtl').glob('*.vhd'))]
    lines += [f'set_global_assignment -name VHDL_FILE "{p.as_posix()}"' for p in files]
    lines += [f'set_global_assignment -name SDC_FILE "{(lab.LAB/"rtl/n8pro.sdc").as_posix()}"']
    if seed is not None:lines += [f'set_global_assignment -name SEED {seed}']
    if area:lines += ['set_global_assignment -name OPTIMIZATION_TECHNIQUE AREA']
    (q/'racing.qsf').write_text('\n'.join(lines)+'\n');(q/'racing.qpf').write_text('PROJECT_REVISION = "racing"\n')
    return q

def source_hashes():
    return lab.hashes([lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',*sorted((HERE/'rtl').glob('*.vhd'))])

def main():
    p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','quartus']);p.add_argument('--seed',type=int);p.add_argument('--area',action='store_true')
    a=p.parse_args();q=prepare(a.seed,a.area)
    if a.command=='quartus':
        inputs=source_hashes()|lab.hashes([q/'racing.qsf',q/'racing.qpf'])
        with (OUT/'quartus.log').open('w') as log:
            result=subprocess.run([lab.quartus_candidates()[0],'--flow','compile','racing'],cwd=q,stdout=log,stderr=subprocess.STDOUT)
        print((OUT/'quartus.log').read_text()[-6000:]);result.check_returncode()
        rbf=q/'output_files/racing.rbf'
        assert inputs==source_hashes()|lab.hashes([q/'racing.qsf',q/'racing.qpf']),'Sources changed during compilation'
        text=(OUT/'quartus.log').read_text()
        setup=[float(v) for v in re.findall(r'Worst-case setup slack is ([\d.-]+)',text)]
        hold=[float(v) for v in re.findall(r'Worst-case hold slack is ([\d.-]+)',text)]
        assert setup and hold and min(setup)>0 and min(hold)>0,'Internal clock timing failed'
        summary=(q/'output_files/racing.fit.summary').read_text()
        fit=(q/'output_files/racing.fit.rpt').read_text()
        resources=re.search(r'; \|racing_top\s+;.*?;\s*([\d,]+)\s*;\s*(\d+)\s*;',fit)
        (OUT/'bitstream-manifest.json').write_text(json.dumps({'sha256':hashlib.sha256(rbf.read_bytes()).hexdigest(),'inputs':inputs,
            'seed':a.seed or 1,'area_optimization':a.area,
            'logic_elements':int(re.search(r'Total logic elements : ([\d,]+)',summary)[1].replace(',','')),
            'm9k_blocks':int(resources[2]),'memory_bits':int(resources[1].replace(',','')),
            'dsp_9bit_elements':int(re.search(r'Embedded Multiplier 9-bit elements : (\d+)',summary)[1]),
            'internal_setup_min_ns':min(setup),'internal_hold_min_ns':min(hold),'hardware_tested':False,'timing_signoff':False},indent=2)+'\n')

if __name__=='__main__':main()
