"""共有メッシュで景物数を増やし、木の幹の表示距離を延ばした r004 を生成。"""
import argparse,json,math,struct,subprocess,sys
from pathlib import Path
from optimize_rom import assemble,digest,HERE
from iterate_r004 import OUT

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--cc65',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True);variants=p.add_mutually_exclusive_group()
    variants.add_argument('--dense',action='store_true');variants.add_argument('--balanced',action='store_true')
    p.add_argument('--out',type=Path);a=p.parse_args()
    sys.path.insert(0,str(a.project/'tools'));from build_racing_scenery import models,TREES,HOUSES
    trees=list(TREES);houses=list(HOUSES)
    if a.dense:
        trees += [(184,170),(112,328),(304,436),(458,502),(524,320),(186,43),(192,470),(496,630)]
        houses += [(104,260),(574,245)]
    if a.balanced:
        # Spread the added house along the infield instead of clustering both
        # large houses at the same bend. Keep the original scenery in place.
        trees += [(184,170),(112,328)];houses += [(420,420)]
    out=a.out or OUT/('balanced' if a.balanced else 'dense' if a.dense else 'normal');out.mkdir(parents=True,exist_ok=True)
    # Assemble a private source copy with the instance count encoded.
    for name in ['gsu.s','scenery.inc','planes.inc','gsu.cfg']: (out/name).write_bytes((HERE/'gsu'/name).read_bytes())
    s=(out/'gsu.s').read_text();(out/'gsu.s').write_text(f'SCENERY_TREES={len(trees)}\nSCENERY_HOUSES={len(houses)}\n'+s)
    subprocess.run([a.cc65/'ca65.exe','-g','-I',a.project/'.cache/casfx','-I',out,out/'gsu.s','-o',out/'gsu.o'],check=True)
    subprocess.run([a.cc65/'ld65.exe','-C',out/'gsu.cfg',out/'gsu.o','-o',out/'gsu.bin','-Ln',out/'gsu.lbl'],check=True)
    code=(out/'gsu.bin').read_bytes();assert len(code)==4096
    original=a.base.read_bytes();rom=bytearray(original);car,tree,house=models()
    for bank in [1,2]:
        base=16+bank*8192;mesh=bytearray(rom[base:base+8192]);mesh[0x100:0x1000]=bytes(0xf00)
        def put(addr,data,limit):
            assert addr+len(data)<=limit,(hex(addr),len(data),hex(limit))
            mesh[addr-0x8000:addr-0x8000+len(data)]=data
        put(0x8100,car.vertex_bytes(),0x8200);put(0x8200,car.face_bytes(0x8600,planes=0x9e80+17*12),0x8300)
        put(0x8300,tree.vertex_bytes(),0x8348);put(0x8348,house.vertex_bytes(),0x8400)
        put(0x8c00,tree.face_bytes(0x8600,world=True,planes=0x9e80),0x8c60)
        put(0x8c60,house.face_bytes(0x8600,world=True,planes=0x9e80+7*12),0x8d00)
        for i,(x,z) in enumerate(trees+houses):
            is_tree=i<len(trees);m=tree if is_tree else house;vptr=0x8300 if is_tree else 0x8348;fptr=0x8c00 if is_tree else 0x8c60
            radius=math.ceil(max(math.sqrt(x*x+y*y+z*z) for x,y,z in m.vertices)*128)+16
            cx,cz=round((x-320)*128/5),round((z-320)*128/5)
            local=list(struct.iter_unpack('<3h',m.vertex_bytes()));world=list(struct.iter_unpack('<3h',m.vertex_bytes((x,z))))
            assert max(abs(local[j][k]+[cx,0,cz][k]-v[k]) for j,v in enumerate(world) for k in range(3))<=1
            put(0x8400+i*16,struct.pack('<8H',vptr,len(m.vertices),fptr,len(m.faces),fptr+(36 if is_tree else 0),4 if is_tree else len(m.faces),radius,5 if is_tree else len(m.vertices)),0x8540)
            put(0x8540+i*6,struct.pack('<3h',cx,0,cz),0x8600)
        put(0x9000,code,0xa000);rom[base:base+8192]=mesh
    assert rom[1048592:1048596]==b'M7R5';rom[1048595]=ord('6')
    assert rom[:8208]==original[:8208] and rom[24592:1048595]==original[24592:1048595] and rom[1048596:]==original[1048596:]
    (out/'game.nes').write_bytes(rom)
    report={'rom_sha256':digest(rom),'source_sha256':digest(original),'trees':trees,'houses':houses,'trunk_lod_depth_world':64,
            'shared_local_meshes':True,'coordinate_rounding_max_q7':1,'gsu_clock_hz':25000000,'fast_internal_ram':True,'hardware_tested':False}
    (out/'rom-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

if __name__=='__main__':main()
