"""保存済みr004の景物・6502・地面・音を保ち、現行GSUコードだけを更新する。"""
import argparse,hashlib,json,subprocess
from pathlib import Path
from build import HERE,OUT

BASE_SHA256='b51e0294ab5ea3d930a30968859bb961a3b003568d9dde5a06da52bf7d926b04'

def main():
    p=argparse.ArgumentParser();p.add_argument('--base',type=Path,required=True);p.add_argument('--project',type=Path,required=True)
    p.add_argument('--cc65',type=Path,required=True);p.add_argument('--out',type=Path,default=OUT/'r005/release');a=p.parse_args()
    digest=lambda b:hashlib.sha256(b).hexdigest();base=a.base.read_bytes()
    assert digest(base)==BASE_SHA256 and base[1048592:1048596]==b'M7R6'
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=True)
    for name in ['gsu.s','scenery.inc','planes.inc','gsu.cfg']:(out/name).write_bytes((HERE/'gsu'/name).read_bytes())
    source=(out/'gsu.s').read_text();(out/'gsu.s').write_text('SCENERY_TREES=10\nSCENERY_HOUSES=3\n'+source)
    subprocess.run([a.cc65/'ca65.exe','-g','-I',a.project/'.cache/casfx','-I',out,out/'gsu.s','-o',out/'gsu.o'],check=True)
    subprocess.run([a.cc65/'ld65.exe','-C',out/'gsu.cfg',out/'gsu.o','-o',out/'gsu.bin','-Ln',out/'gsu.lbl'],check=True)
    code=(out/'gsu.bin').read_bytes();assert len(code)==4096;rom=bytearray(base);allowed=set()
    for bank in [1,2]:
        start=16+bank*8192+4096;rom[start:start+4096]=code;allowed.update(range(start,start+4096))
    changed=[i for i,(x,y) in enumerate(zip(base,rom)) if x!=y];assert set(changed)<=allowed
    (out/'GSU_MMC5Racing3D_v005_opt_r005.nes').write_bytes(rom)
    report=dict(rom_sha256=digest(rom),base_sha256=digest(base),changed_bytes=len(changed),only_gsu_code_changed=True,
                trees=10,houses=3,trunk_lod_depth_world=64,gsu_clock_hz=25000000,rom_format='M7R6',hardware_tested=False,
                sources={name:digest((HERE/'gsu'/name).read_bytes()) for name in ['gsu.s','scenery.inc','planes.inc','gsu.cfg']})
    (out/'rom-manifest.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

if __name__=='__main__':main()
