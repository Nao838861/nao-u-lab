"""旧・候補回路を同じ入力で並走し、各クロックの全出力を比較する。"""
import argparse,hashlib,importlib,json,re,sys
from pathlib import Path
from area_r005 import baseline,ROOT,REVISION,lab

def rename(source,entity,new,dependencies=()):
    source=re.sub(r'\bentity\s+'+entity+r'\s+is',f'entity {new} is',source,flags=re.I)
    source=re.sub(r'(\barchitecture\s+\w+\s+of\s+)'+entity+r'\b',r'\g<1>'+new,source,flags=re.I)
    for dep in dependencies:source=re.sub(r'work\.'+dep+r'\b','work.'+dep+'_reference',source,flags=re.I)
    return source

def pair(source,reference,folder):
    entity=re.search(r'\bentity\s+(\w+)\s+is',source,re.I)[1]
    header=re.search(r'\bentity\s+'+entity+r'\s+is(.*?)\bend\s*;',source,re.S|re.I)[0]
    ports=header[header.lower().index('port(')+5:header.rfind(')')]
    definitions=[];ins=[];outs=[]
    for declaration in ports.split(';'):
        names,mode,typ=re.fullmatch(r'\s*([\w\s,]+)\s*:\s*(in|out)\s+(.+?)\s*',declaration,re.S|re.I).groups()
        for name in names.replace(' ','').replace('\n','').split(','):
            definitions.append((name,mode.lower(),typ));(ins if mode.lower()=='in' else outs).append(name)
    signals=[];assignments=[];checks=[]
    for name,mode,typ in definitions:
        if mode=='out':
            signals.append(f'signal candidate_{name},reference_{name} : {typ};')
            assignments.append(f'{name}<=candidate_{name};')
            ref=f'reference_{name}'
            test=f'std_logic_vector({ref})' if typ.lower().startswith(('unsigned','signed')) else ref
            checks.append(f'if not is_x({test}) then assert candidate_{name}=reference_{name} report "EQUIVALENCE {entity}.{name}" severity failure;end if;')
    def mapping(prefix):return ','.join(f'{name}=>{name if mode=="in" else prefix+"_"+name}' for name,mode,typ in definitions)
    wrapper='library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;\n'+header+'\narchitecture compare of '+entity+' is\n'+'\n'.join(signals)+'\nbegin\n'
    generic='generic map(POSITIVE_DIVISOR=>POSITIVE_DIVISOR) ' if 'POSITIVE_DIVISOR' in header else ''
    if 'RIGHT_OPERAND_BITS' in header:generic='generic map(POSITIVE_DIVISOR=>POSITIVE_DIVISOR,RIGHT_OPERAND_BITS=>RIGHT_OPERAND_BITS) '
    wrapper+='\n'.join(assignments)+f'\ncandidate_dut:entity work.{entity}_candidate {generic}port map({mapping("candidate")});\nreference_dut:entity work.{entity}_reference port map({mapping("reference")});\n'
    wrapper+='process begin wait until falling_edge(clk);wait for 1 ps;\n'+'\n'.join(checks)+'\nend process;end;\n'
    paths=[folder/(entity+suffix+'.vhd') for suffix in ['_reference','_candidate','_compare']]
    paths[0].write_text(rename(reference,entity,entity+'_reference',['serial_math']))
    paths[1].write_text(rename(source,entity,entity+'_candidate'))
    paths[2].write_text(wrapper)
    return paths,entity

def main():
    p=argparse.ArgumentParser();p.add_argument('--variant',type=Path,required=True);p.add_argument('--out',type=Path,required=True)
    p.add_argument('--test',choices=['dsp','display','boot','gsu'],required=True);a,extra=p.parse_known_args()
    ref=baseline();folder=a.out.resolve();folder.mkdir(parents=True,exist_ok=True);src=a.variant.resolve()/'src'
    run=lab.run;paired=[]
    def compile_pair(args,**kwargs):
        if '-a' in args and any(str(f).endswith('.vhd') for f in args):
            actual=[]
            for f in args:
                path=Path(f)
                if path.suffix=='.vhd' and (src/path.name).exists():
                    candidate=(src/path.name).read_text();reference=(ref/path.name).read_text()
                    if candidate!=reference and path.stem in ['serial_math','mode7_dsp','racing_display','racing_gsu']:
                        paths,entity=pair(candidate,reference,folder);actual.extend(paths);paired.append(entity)
                    else:actual.append(src/path.name)
                else:actual.append(f)
            args=actual
        return run(args,**kwargs)
    lab.run=compile_pair
    sys.argv=['verify_'+a.test+'.py','--out',str(folder),*extra]
    module=importlib.import_module('verify_'+a.test);module.main()
    report=json.loads((folder/'verification.json').read_text())
    report['sources']={name:hashlib.sha256((src/Path(name).name).read_bytes()).hexdigest() if (src/Path(name).name).exists() else sha for name,sha in report['sources'].items()}
    report.update(reference_commit=REVISION,cycle_equivalence='pass',compared_modules=paired,
                  equivalence_scope='Every falling clock edge; all defined reference outputs; existing directed harness inputs, not formal proof',
                  variant_sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(src.glob('*.vhd'))})
    (folder/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print('CYCLE EQUIVALENCE PASS',paired)

if __name__=='__main__':main()
