"""r003 の描画画像を基準に、最適化の各段階を独立保存して比較する。"""
import argparse,json,struct,subprocess,sys
from pathlib import Path
from optimize_rom import assemble,patch_rom,digest,HERE
OUT=HERE.parents[1]/'build/racing-n8pro/r004'

def make_rom(original,code):
    rom=bytearray(patch_rom(original,code))
    if original[1048592:1048596]==b'M7R6':return bytes(rom)
    for bank in [1,2]:
        base=16+bank*8192
        for start,count in [(0x200,14),(0xca0,7),(0xd00,10)]:
            for i in range(count):
                at=base+start+i*12+2;value=struct.unpack_from('<H',rom,at)[0]
                assert 0x9e00<=value<0x9f80
                struct.pack_into('<H',rom,at,value+0x80)
    return bytes(rom)

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--cc65',type=Path,required=True)
    p.add_argument('--base',type=Path,required=True);p.add_argument('--tag',required=True);p.add_argument('--full',action='store_true');a=p.parse_args()
    out=OUT/a.tag;out.mkdir(parents=True,exist_ok=True)
    original=a.base.read_bytes();code=assemble(a.project,a.cc65,out)
    rom=make_rom(original,code);(out/'game.nes').write_bytes(rom)
    comparison=json.loads((OUT.parent/'optimization/comparison/verification.json').read_text())
    rows=comparison['all'] if a.full else comparison['initial']+comparison['worst']
    probe=a.project/'build/racing/v003/racing_profile.exe';data=bytearray(40960)
    results=[]
    for i,row in enumerate(rows):
        samples=[]
        for name,source in [('before',original),('after',rom)]:
            data[:32768]=bytes(32768);data[32768:]=source[8208:16400];data[0x8004:0x8006]=b'\x00\x40'
            struct.pack_into('<11h',data,0x8008,*row['pose']);(out/'input.bin').write_bytes(data)
            clocks=int(subprocess.check_output([probe,out/'input.bin',out/name],text=True))
            samples.append((clocks,(out/(name+'.frame')).read_bytes()))
        if samples[0][1]!=samples[1][1]:raise AssertionError(('pixels',row['name'],sum(x!=y for x,y in zip(samples[0][1],samples[1][1]))))
        results.append(dict(name=row['name'],view=row['view'],pose=row['pose'],before=samples[0][0],after=samples[1][0]))
        if (i+1)%128==0:print(f'{a.tag}: {i+1}/{len(rows)}',flush=True)
    report={'status':'pass','tag':a.tag,'base_sha256':digest(original),'rom_sha256':digest(rom),'identical_frames':len(rows),
            'saving_percent':100*(1-sum(r['after'] for r in results)/sum(r['before'] for r in results)),
            'cases':results,'scope':'Mesen native GSU instruction model, not hardware FPS'}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='cases'}));print([(r['name'],r['before'],r['after']) for r in results[:8]])

if __name__=='__main__':main()
