"""r004と同じ景物・色・画素を保つGSU最適化を、命令クロック付きで比較する。"""
import argparse,hashlib,json,re,struct,subprocess
from pathlib import Path
from area_r005 import ROOT,REVISION,replace,lab,HERE

def main():
    p=argparse.ArgumentParser();p.add_argument('--tag',required=True);p.add_argument('--base',type=Path,required=True)
    p.add_argument('--cases',type=Path,required=True);p.add_argument('--project',type=Path,required=True);p.add_argument('--cc65',type=Path,required=True)
    p.add_argument('--experiment',required=True);p.add_argument('--small',action='store_true');a=p.parse_args()
    assert set(a.experiment.split('-'))<=set(['floor','branches','inside','clear','regs'])
    out=ROOT/a.tag;out.mkdir(parents=True,exist_ok=True)
    for name in ['gsu.s','scenery.inc','planes.inc','gsu.cfg']:
        data=subprocess.check_output(['git','show',REVISION+':development/racing-n8pro/gsu/'+name],cwd=lab.ROOT)
        (out/name).write_bytes(data)
    s=(out/'gsu.s').read_text()
    if 'floor' in a.experiment:
        s=replace(s,'''edge_rows:
  cache
  from r2''','''edge_rows:
  cache
  ; Normalize negative slopes once, so r1 always holds floor(x) and
  ; r5/r8 is a nonnegative fraction. The row loop then has one direction.
  from r9
  sub #0
  bpl normalized_edge
  nop
  from r5
  sub #0
  beq normalized_phase
  nop
  dec r1
  from r8
  sub r5
  move r5,r0
normalized_phase:
  from r6
  sub #0
  beq normalized_edge
  nop
  dec r7
  from r8
  sub r6
  move r6,r0
normalized_edge:
  from r2''')
        s=replace(s,'''  from r9
  sub #0
  bmi negative_fraction
  nop
  inc r4
  bra exact_edge
  nop
negative_fraction:
  dec r14
exact_edge:''','''  inc r4
exact_edge:''')
        s=replace(s,'''  with r1
  add r9
remainder_ok:''','''  inc r1
remainder_ok:''')
    if 'branches' in a.experiment:
        s=replace(s,'''  bge keep_left
  nop
  from r4
  stw (r3)''','''  bge keep_left
  from r4
  stw (r3)''')
        s=replace(s,'''  blt keep_right
  nop
  from r14
  stw (r3)''','''  blt keep_right
  from r14
  stw (r3)''')
    if 'inside' in a.experiment:
        s=replace(s,'''  from r14
  sub #0
  jlt raster_return
  iwt r0,#192''','''  from r14
  sub #0
  jlt raster_return
  ; All edge intersections stay within the polygon's integer X bounds.
  ibt r6,#0
  from r10
  sub #0
  bmi horizontal_bounds_ready
  nop
  iwt r0,#256
  from r14
  cmp r0
  bge horizontal_bounds_ready
  nop
  ibt r6,#1
horizontal_bounds_ready:
  save $80dc,r6
  iwt r0,#192''')
        s=replace(s,'''  load r2,$80ba
  load r10,$80bc''','''  load r2,$80ba
  load r9,$80dc
  load r10,$80bc''')
        s=replace(s,'''  to r4
  ldw (r3)
  add2 r3
  from r1''','''  to r4
  ldw (r3)
  add2 r3
  from r9
  sub #0
  bne horizontal_inside
  nop
  from r1''')
        s=replace(s,'''  bge fill_next
  nop
  from r4
  sub #0''','''  bge fill_next
  nop
horizontal_inside:
  from r4
  sub #0''')
    if 'clear' in a.experiment:
        s=replace(s,'''  iwt r13,#clear_span
clear_span:
  iwt r0,#$7fff
  stw (r3)
  add2 r3
  iwt r0,#$8000
  stw (r3)
  inc r3''','''  iwt r13,#clear_span
  iwt r0,#$7fff
clear_span:
  stw (r3)
  add2 r3
  not
  stw (r3)
  not
  inc r3''')
    if 'regs' in a.experiment:
        s=replace(s,'''  ldw (r7)
  save $80be,r0
  add2 r7
  ldw (r7)
  save $80c0,r0
  ldw (r8)
  save $80c2,r0
  add2 r8
  ldw (r8)
  save $80c4,r0
  call edge_span''','''  to r9
  ldw (r8)
  add2 r8
  to r10
  ldw (r8)
  to r3
  ldw (r7)
  add2 r7
  to r8
  ldw (r7)
  move r7,r3
  call edge_span''')
        s=replace(s,'''  save $80c6,r11
  load r7,$80be
  load r8,$80c0
  load r9,$80c2
  load r10,$80c4
  from r10''','''  save $80c6,r11
  ; Endpoints arrive in registers, without four stores and reloads.
  from r10''')
    (out/'gsu.s').write_text('SCENERY_TREES=10\nSCENERY_HOUSES=3\n'+s)
    subprocess.run([a.cc65/'ca65.exe','-g','-l',out/'gsu.lst','-I',a.project/'.cache/casfx','-I',out,out/'gsu.s','-o',out/'gsu.o'],check=True)
    subprocess.run([a.cc65/'ld65.exe','-C',out/'gsu.cfg',out/'gsu.o','-o',out/'gsu.bin','-Ln',out/'gsu.lbl'],check=True)
    original=a.base.read_bytes();rom=bytearray(original);code=(out/'gsu.bin').read_bytes();assert len(code)==4096
    for bank in [1,2]:rom[16+bank*8192+4096:16+(bank+1)*8192]=code
    (out/'game.nes').write_bytes(rom)
    data=json.loads(a.cases.read_text());rows=data['selected'] if a.small else data['all'];probe=a.project/'build/r004-core-calibrated/racing_profile.exe'
    memory=bytearray(40960);memory[0x8004:0x8006]=b'\x00\x40';results=[]
    for i,row in enumerate(rows):
        samples=[]
        for name,source in [('before',original),('after',rom)]:
            memory[:32768]=bytes(32768);memory[32768:]=source[8208:16400];struct.pack_into('<11h',memory,0x8008,*row['pose'])
            (out/'input.bin').write_bytes(memory)
            clocks=int(subprocess.check_output([probe,out/'input.bin',out/name,'fast'],text=True));samples.append((clocks,(out/(name+'.frame')).read_bytes()))
        assert samples[0][1]==samples[1][1],('frame',row['name'],sum(x!=y for x,y in zip(samples[0][1],samples[1][1])))
        results.append(dict(name=row['name'],pose=row['pose'],before=samples[0][0],after=samples[1][0]))
        if (i+1)%128==0:print(i+1,len(rows),flush=True)
    digest=lambda b:hashlib.sha256(b).hexdigest()
    report=dict(status='pass',identical_frames=len(rows),base_sha256=digest(original),rom_sha256=digest(rom),probe_sha256=digest(probe.read_bytes()),
                saving_percent=100*(1-sum(r['after'] for r in results)/sum(r['before'] for r in results)),
                max_before_ms=max(r['before'] for r in results)/25000,max_after_ms=max(r['after'] for r in results)/25000,all=results,
                scope='25MHz Mesen instruction model; RTL and full ROM frame-rate verification required')
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k!='all'}))

if __name__=='__main__':main()
