"""r005を固定基準に、画素を保つGSU最適化案の速度を比較する。"""
import argparse, hashlib, json, re, struct, subprocess
from pathlib import Path
from build import HERE, OUT, lab

REVISION = 'cdfc8e572e5405ded052c69cd6189c0eca9503ca'
ROOT = OUT / 'r006'


def replace(s, old, new):
    assert old in s, old[:100]
    return s.replace(old, new)


def patches(s, flags):
    if 'shift' in flags:
        s = replace(s, '  from r4\n  add r4\n  move r4,r0\n  with r5\n  adc r5',
                    '  with r4\n  add r4\n  with r5\n  adc r5')
    if 'multiply' in flags:
        s = replace(s, '  lmult\n  move r5,r0\n  from r4\n  hib\n  move r4,r0\n  from r5\n  lob\n  swap\n  or r4',
                    '  to r5\n  lmult\n  with r4\n  hib\n  from r5\n  lob\n  swap\n  or r4')
    if 'ceil' in flags:
        s = replace(s, '''edge_row:
  move r4,r1
  move r14,r1
  from r5
  sub #0
  beq exact_edge
  nop
  inc r4
exact_edge:''', '''edge_row:
  ; r1=floor(x), r5>=0. Carry from r5-1 is exactly (r5!=0).
  from r5
  sub #1
  from r1
  to r4
  adc #0
exact_edge:''')
        s = replace(s, '  from r14\n  cmp r0\n  blt keep_right\n  from r14',
                    '  from r1\n  cmp r0\n  blt keep_right\n  from r1')
    if 'yaw' in flags:
        s = replace(s, 'transform:\n  cache', 'transform:\n  cache\n  load r1,$800e\n  load r2,$8010')
        s = replace(s, '  load r6,$800e\n  inline_mul8', '  move r6,r1\n  inline_mul8')
        s = replace(s, '  load r6,$8010\n  inline_mul8', '  move r6,r2\n  inline_mul8')
    if 'zero' in flags:
        s = replace(s, '''fast_edge_bottom:
  call divide
  move r1,r7''', '''fast_edge_bottom:
  ; Vertical-ish edges have quotient zero: stay in the current cache window.
  from r4
  cmp r6
  bcs edge_nonzero_quotient
  nop
  move r5,r4
  ibt r4,#0
  bra edge_quotient_ready
  nop
edge_nonzero_quotient:
  call divide
edge_quotient_ready:
  move r1,r7''')
    if 'early' in flags:
        s = replace(s, 'edge_span:\n  save $80c6,r11\n', 'edge_span:\n')
        start=s.index('edge_span:');end=s.index('  ; If the sorted start',start)
        s=s[:start]+s[start:end].replace('edge_return','edge_trivial_return')+s[end:]
        s=replace(s, '  ; If the sorted start', '  save $80c6,r11\n  ; If the sorted start')
        s=replace(s, 'edge_return:\n  load r11,$80c6\n', 'edge_return:\n  load r11,$80c6\nedge_trivial_return:\n')
    if 'cache' in flags:
        s=replace(s,'edge_rows:\n  cache','edge_rows:')
    if 'rows' in flags:
        s=replace(s, '''edge_row:
''', '''  from r10
  sub r2
  move r12,r0
  iwt r13,#edge_row
edge_row:
''')
        s=replace(s, '''  inc r2
  from r2
  cmp r10
  blt edge_row
  nop''', '''  loop
  nop''')
    if 'height' in flags:
        s=replace(s, 'transform:\n  cache', 'transform:\n  cache\n  iwt r0,#$8000\n  save $80de,r0')
        s=replace(s, '''  load r0,$800c
  load r6,$8042
  sub r6
  move r12,r0
  load r6,$8012
  inline_mul8
  move r3,r0
  move r0,r14''', '''  load r0,$8042
  load r6,$80de
  cmp r6
  bne height_miss
  nop
  load r3,$80e0
  load r12,$80e2
  bra height_ready
  nop
height_miss:
  save $80de,r0
  move r6,r0
  load r0,$800c
  sub r6
  move r12,r0
  load r6,$8012
  inline_mul8
  move r3,r0
  save $80e0,r3
  move r0,r12
  load r6,$8014
  inline_mul8
  move r12,r0
  save $80e2,r12
height_ready:
  move r0,r14''')
        s=replace(s, '''  move r0,r12
  load r6,$8014
  inline_mul8
  move r6,r3
  add r6
  stw (r8)''', '''  move r6,r12
  from r3
  add r6
  stw (r8)''')
    if 'pointers' in flags:
        for reg in ['r3','r7','r8']:
            s=s.replace(f'  add2 {reg}\n  add2 {reg}',f'  with {reg}\n  add #4')
    if 'direct' in flags:
        s=replace(s,'  move r6,r3\n  add r6','  add r3')
        s=replace(s,'  move r6,r3\n  sub r6','  sub r3')
        s=replace(s,'  move r6,r3\n  from r6\n  sub r0','  from r3\n  sub r0')
    if 'dispatch' in flags:
        s=replace(s,'  ibt r10,#0\nvertex:', '  iwt r10,#vertex\nvertex:')
        s=replace(s,'''  inc r10
  dec r9
  beq vertices_done
  nop
  from r10
  hib
  beq next_car_vertex
  nop
  jump world_read
next_car_vertex:
  jump vertex''','''  dec r9
  beq vertices_done
  nop
  jmp r10
  nop''')
    if 'pitch' in flags:
        s=replace(s,'  save $8050,r11','  save $8050,r11\n  load r11,$8014')
        s=replace(s,'  load r6,$8014\n  inline_mul8','  move r6,r11\n  inline_mul8')
    if flags & {'four', 'generic4', 'generic2'}:
        bits=2 if 'generic2' in flags else 4
        for prefix in (['projection_division', 'division'] if 'four' in flags else ['division']):
            s=replace(s,'\n'+prefix+'''_small_check:
''','\n'+prefix+'''_small_check:
  from r5
  sub #0
  bne '''+prefix+'''_byte_check
  nop
  from r4
  .repeat {bits}
    lsr
  .endrepeat
  cmp r6
  bcs '''+prefix+'''_byte_check
  nop
  move r5,r0
  from r4
  and #{mask}
  swap
  .repeat {shift}
    add r0
  .endrepeat
  move r4,r0
  ibt r12,#{bits}
  bra '''+prefix+'''_setup
  nop
'''+prefix+'''_byte_check:
''')
            s=s.replace('{bits}',str(bits)).replace('{mask}',str((1<<bits)-1)).replace('{shift}',str(8-bits))
    return s


def main():
    p = argparse.ArgumentParser()
    for name in ['tag', 'experiment']:
        p.add_argument('--' + name, required=True)
    for name in ['base', 'cases', 'project', 'cc65']:
        p.add_argument('--' + name, type=Path, required=True)
    p.add_argument('--small', action='store_true')
    a = p.parse_args()
    flags = set(a.experiment.split('-'))
    assert flags <= {'baseline', 'shift', 'multiply', 'ceil', 'yaw', 'zero', 'early', 'cache', 'rows', 'height', 'pointers', 'four', 'generic4', 'generic2', 'direct', 'dispatch', 'pitch'}
    out = ROOT / a.tag
    out.mkdir(parents=True, exist_ok=True)
    for name in ['gsu.s', 'scenery.inc', 'planes.inc', 'gsu.cfg']:
        data = subprocess.check_output(['git', 'show', REVISION + ':development/racing-n8pro/gsu/' + name], cwd=lab.ROOT)
        (out / name).write_bytes(data)
    s = patches((out / 'gsu.s').read_text(), flags)
    if 'yaw' in flags:
        p = out/'scenery.inc'
        p.write_text(replace(p.read_text(), 'tree_transform:\n', 'tree_transform:\n  load r1,$800e\n  load r2,$8010\n'))
    if 'height' in flags:
        p=out/'scenery.inc'
        p.write_text(replace(p.read_text(), 'tree_transform:\n', 'tree_transform:\n  iwt r0,#$8000\n  save $80de,r0\n'))
    if 'dispatch' in flags:
        p=out/'scenery.inc';p.write_text(replace(p.read_text(),'  iwt r10,#256','  iwt r10,#world_read'))
    if 'pitch' in flags:
        p=out/'scenery.inc';p.write_text(replace(p.read_text(),'  save $8050,r11','  save $8050,r11\n  load r11,$8014'))
    (out / 'gsu.s').write_text('SCENERY_TREES=10\nSCENERY_HOUSES=3\n' + s)
    subprocess.run([a.cc65/'ca65.exe', '-g', '-l', out/'gsu.lst', '-I', a.project/'.cache/casfx', '-I', out, out/'gsu.s', '-o', out/'gsu.o'], check=True)
    subprocess.run([a.cc65/'ld65.exe', '-C', out/'gsu.cfg', out/'gsu.o', '-o', out/'gsu.bin', '-Ln', out/'gsu.lbl'], check=True)
    original = a.base.read_bytes()
    assert hashlib.sha256(original).hexdigest() == 'd5b6016be1127c47ba2d654d09befcb1be61f8c3a6cd532a63cb76c9051fd725'
    rom = bytearray(original)
    code = (out/'gsu.bin').read_bytes()
    assert len(code) == 4096
    for bank in [1, 2]:
        rom[16+bank*8192+4096:16+(bank+1)*8192] = code
    (out/'game.nes').write_bytes(rom)
    data = json.loads(a.cases.read_text())
    rows = data['selected'] if a.small else data['all']
    probe = a.project/'build/r004-core-calibrated/racing_profile.exe'
    memory = bytearray(40960)
    results = []
    hist = [0]*65536
    for i, row in enumerate(rows):
        samples = []
        for name, source in [('before', original), ('after', rom)]:
            memory[:32768] = bytes(32768)
            memory[32768:] = source[8208:16400]
            memory[0x8004:0x8006] = b'\x00\x40'
            struct.pack_into('<11h', memory, 0x8008, *row['pose'])
            (out/'input.bin').write_bytes(memory)
            clocks = int(subprocess.check_output([probe, out/'input.bin', out/name, 'fast'], text=True))
            samples.append((clocks, (out/(name+'.frame')).read_bytes()))
        assert samples[0][1] == samples[1][1], ('frame', row['name'], sum(x!=y for x,y in zip(samples[0][1], samples[1][1])))
        hist = [a+b for a,b in zip(hist, struct.unpack('<65536Q', (out/'after.clocks').read_bytes()))]
        results.append(dict(name=row['name'], pose=row['pose'], before=samples[0][0], after=samples[1][0]))
        if (i+1)%128 == 0:
            print(i+1, len(rows), flush=True)
    labels = sorted((int(addr,16), name) for addr,name in re.findall(r'al ([0-9A-Fa-f]+) \.([^\s]+)', (out/'gsu.lbl').read_text()))
    profile = sorted([dict(label=name, clocks=sum(hist[addr:labels[n+1][0] if n+1<len(labels) else 65536])) for n,(addr,name) in enumerate(labels)], key=lambda x:-x['clocks'])
    (out/'profile.json').write_text(json.dumps(profile, indent=2)+'\n')
    digest = lambda b: hashlib.sha256(b).hexdigest()
    report = dict(status='pass', identical_frames=len(rows), base_sha256=digest(original), rom_sha256=digest(rom), probe_sha256=digest(probe.read_bytes()),
                  saving_percent=100*(1-sum(r['after'] for r in results)/sum(r['before'] for r in results)),
                  max_before_ms=max(r['before'] for r in results)/25000, max_after_ms=max(r['after'] for r in results)/25000, all=results,
                  scope='25MHz Mesen instruction model; RTL and full ROM frame-rate verification required')
    (out/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='all'}))
    print(json.dumps(profile[:25]))


if __name__ == '__main__':
    main()
