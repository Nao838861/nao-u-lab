"""固定した v005 から、回路を変更しない GSU 最適化 ROM を生成する。"""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

HERE = Path(__file__).resolve().parents[1]
OUT = HERE.parents[1] / 'build/racing-n8pro/optimization'
SOURCE_HASH = 'cb62bb356af4c86632ea061c7f1132b36f6d0502ff8de4bdf8a804802aa41a75'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def assemble(project, cc65, destination, baseline=False, repeats=1):
    destination.mkdir(parents=True, exist_ok=True)
    source = project/'demos/racing/v005' if baseline else HERE/'gsu'
    text = (source/'gsu.s').read_text()
    assert text.count('  call trees\n') == 1
    text = text.replace('  call trees\n', '  call trees\n' * repeats)
    (destination/'gsu.s').write_text(text)
    includes = project/'build/racing/v005' if baseline else source
    for name in ['scenery.inc', 'planes.inc', 'gsu.cfg']:
        original = source/name if (source/name).exists() else includes/name
        (destination/name).write_bytes(original.read_bytes())
    subprocess.run([cc65/'ca65.exe', '-g', '-I', project/'.cache/casfx', '-I', destination,
                    destination/'gsu.s', '-o', destination/'gsu.o'], check=True)
    subprocess.run([cc65/'ld65.exe', '-C', destination/'gsu.cfg', destination/'gsu.o',
                    '-o', destination/'gsu.bin', '-Ln', destination/'gsu.lbl'], check=True)
    data = (destination/'gsu.bin').read_bytes()
    assert len(data) == 4096
    return data


def patch_rom(original, code):
    result = bytearray(original)
    for bank in [1, 2]:
        start = 16 + bank*8192 + 4096
        result[start:start+4096] = code
    assert result[:8208] == original[:8208]
    assert result[16+3*8192:] == original[16+3*8192:]
    return bytes(result)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emulator-project', type=Path, required=True)
    parser.add_argument('--cc65-bin', type=Path, required=True)
    args = parser.parse_args()
    project = args.emulator_project.resolve()
    original = (project/'releases/GSU_MMC5Racing3D_v005.nes').read_bytes()
    assert digest(original) == SOURCE_HASH
    code = assemble(project, args.cc65_bin.resolve(), OUT/'optimized')
    baseline = assemble(project, args.cc65_bin.resolve(), OUT/'baseline', baseline=True)
    assert baseline == original[16+8192+4096:16+16384], 'Baseline assembly does not reproduce v005'
    assert baseline == original[16+16384+4096:16+24576], 'GRIP/DRIFT GSU programs differ'
    rom = patch_rom(original, code)
    name = 'GSU_MMC5Racing3D_v005_opt_r002.nes'
    (OUT/name).write_bytes(rom)
    sources = {p.relative_to(HERE).as_posix(): digest(p.read_bytes()) for p in sorted((HERE/'gsu').iterdir()) if p.is_file()}
    report = dict(source_rom_sha256=SOURCE_HASH, rom_sha256=digest(rom), code_sha256=digest(code),
                  sources=sources, changed='Only GSU code in PRG banks 1 and 2', hardware_tested=False)
    (OUT/'rom-manifest.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
