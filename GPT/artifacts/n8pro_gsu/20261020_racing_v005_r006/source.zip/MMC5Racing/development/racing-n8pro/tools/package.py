"""検証済みソースに対応する v005 実機試験 ROM/RBF をまとめる。"""
import argparse,hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path
from build import HERE,OUT,lab,source_hashes
SOURCE_HASH='cb62bb356af4c86632ea061c7f1132b36f6d0502ff8de4bdf8a804802aa41a75'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def revision(root):return subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip()

def main():
    p=argparse.ArgumentParser();p.add_argument('--emulator-project',type=Path,required=True);p.add_argument('--dest',type=Path,required=True);a=p.parse_args()
    project=a.emulator_project.resolve();dest=a.dest.resolve();dest.mkdir(parents=True,exist_ok=True)
    source=project/'releases/GSU_MMC5Racing3D_v005.nes';assert sha(source)==SOURCE_HASH
    current=source_hashes();meta=json.loads((OUT/'bitstream-manifest.json').read_text())
    q=OUT/'quartus';assert meta['inputs']==current|lab.hashes([q/'racing.qsf',q/'racing.qpf'])
    rbf=q/'output_files/racing.rbf';assert sha(rbf)==meta['sha256']
    for name in ['gsu-test','dsp-test','display-test','boot-test']:
        test=json.loads((OUT/name/'verification.json').read_text())
        assert test['status']=='pass' and test['sources']==current,('stale verification',name)
    data=source.read_bytes();assert data[1048592:1048596]==b'M7R4'
    prg=data[16:1048592];font=data[2097168:];assert len(font)==8192
    texture=data[1048608:1048608+102400]
    header=b'NES\x1a'+bytes([64,16,1,0])+bytes(8)
    rom=header+prg+(font+texture).ljust(131072,b'\0')
    target=dest/'sdcard/GSU-RACING-V005';target.mkdir(parents=True,exist_ok=True)
    romfile=target/'GSU_MMC5Racing3D_v005_N8Pro_r001.nes';romfile.write_bytes(rom)
    assert rom[16:16+1048576]==data[16:16+1048576]
    assert rom[16+1048576+8192:16+1048576+8192+102400]==texture
    shutil.copy2(rbf,target/'gsu.rbf')
    verification=dest/'verification';verification.mkdir(exist_ok=True)
    for name in ['gsu-test','dsp-test','display-test','boot-test']:
        shutil.copy2(OUT/name/'verification.json',verification/(name+'.json'))
        shutil.copy2(OUT/name/'simulation.log',verification/(name+'.log'))
    for name in ['racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin']:
        shutil.copy2(q/'output_files'/name,verification/name)
    shutil.copy2(OUT/'bitstream-manifest.json',verification/'bitstream-manifest.json')
    sourcezip=dest/'source.zip'
    with zipfile.ZipFile(sourcezip,'w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE,lab.LAB,lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        # v005 model/code sources supplement the exact emulator source revision.
        for folder in [project/'demos/racing/v005',project/'demos/racing/v004',project/'demos/ground/v003']:
            for f in sorted(folder.iterdir()):
                if f.is_file() and f.suffix in ['.s','.inc','.md']:z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
        for f in [project/'tools/build_racing_scenery.py',project/'tools/build_racing_mode7.py',project/'src/Mode7Ground.hpp']:
            z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
    fit=(q/'output_files/racing.fit.summary').read_text()
    le=re.search(r'Total logic elements : (.+)',fit).group(1)
    fitall=(q/'output_files/racing.fit.rpt').read_text();m9k=re.search(r'; M9Ks\s*; ([^;]+)',fitall).group(1).strip()
    readme=f'''EverDrive N8 Pro：MMC5Racing 3D v005 実機試験版 r001
2026-10-17 / 実機動作は未確認

動かし方
1. 本体の電源を切ってから、sdcard/GSU-RACING-V005 フォルダーごとSDへコピー。
2. N8 Proメニューで
   GSU-RACING-V005/GSU_MMC5Racing3D_v005_N8Pro_r001.nes を選び Start Game。
3. 初期化に数秒かかります。5秒ほど待っても黒いままなら、本体RESETを一度押します。
4. メニューに戻るときは電源を入れ直します。RESETはメニュー復帰用ではありません。

ROMと同じフォルダーの gsu.rbf は必須です。立方体用RBFとは互換性がありません。
既存の GSU-CUBE / GSU-SELFTEST フォルダーはそのまま残してください。
PCの play_mmc5racing_3d.cmd はこれまでどおりPC版を起動します。

操作
A: アクセル、B: ブレーキ/ドリフト、左右: 操舵
SELECT: 視点切替、上: ポリゴン表示切替、下: GRIP/DRIFT、START: 走行リセット
車・木・家・地面・物理・音は最新v005のデータ/プログラムを維持。

今回の検証
- 最新GSUの4視点、論理描画RAM 65,536バイトが参照出力と一致。
- 地面DSP 34カメラ/6,528行が整数参照計算と一致。
- 地面/透明合成/属性パレット 196,608画素が一致。
  表示・スプライト取得と外部メモリ転送の同時動作も確認。
- 実6502初期化/NMIの282,122外部バス操作、最初のGSU描画、
  完成画像のPSRAM転送とフロント切替をトップRTLで確認。
- Quartus: LE {le}、M9K {m9k}。
  内部setup最小余裕 {meta['internal_setup_min_ns']}ns、hold {meta['internal_hold_min_ns']}ns。

実機でこれから確認すること
実物での初回起動、画面・音、外部SRAM/PSRAM/PPUのタイミング、継続走行。
回路シミュレーションの合格は実機動作確認とは区別しています。
GSUは25MHzです。PC版50MHzと同じ速度や、実機30fpsの維持は保証していません。
外部I/Oの遅延制約は未完了。NTSC用で、PAL・セーブステート・ゲーム内メニューは未対応。

黒画面/画像化け/停止があれば、電源投入直後とRESET後の違い、
画面・音の有無、本体型番とN8 Pro OS版が切り分けに役立ちます。

manifest.json: ROM/RBFハッシュとソースrevision
verification/: 合成・タイミング・RTL検証記録
source.zip: 回路/ツール/ライセンス。回路はGPLv3。
回路ソース: https://github.com/Nao838861/MMC5Racing
ゲームソース: https://github.com/Nao838861/nao-u-lab （GPT/projects/nes_superfx）
'''
    (dest/'README.txt').write_text(readme,encoding='utf-8-sig')
    manifest={'version':'v005_N8Pro_r001','source_rom_sha256':SOURCE_HASH,'rom_sha256':sha(romfile),'rbf_sha256':sha(target/'gsu.rbf'),
        'hardware_source_commit':revision(lab.ROOT),'hardware_branch':subprocess.check_output(['git','branch','--show-current'],cwd=lab.ROOT,text=True).strip(),
        'game_source_commit':revision(project),'gsu_clock_hz':25000000,'prg_code_changed':False,'hardware_tested':False,'timing_signoff':False,
        'memory_layout':'1MiB unchanged PRG +128KiB CHR(font+original ground);20KiB on-chip GSU backing;external completed frames',
        'source_zip_sha256':sha(sourcezip),'files':{f.relative_to(dest).as_posix():sha(f) for f in sorted(dest.rglob('*')) if f.is_file() and f.name not in ['manifest.json','N8Pro_Racing_v005_r001_test.zip']}}
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=dest/'N8Pro_Racing_v005_r001_test.zip'
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps({'archive':str(archive),'rom_sha256':sha(romfile),'rbf_sha256':sha(rbf),'rom_bytes':len(rom),'archive_bytes':archive.stat().st_size},indent=2))

if __name__=='__main__':main()
