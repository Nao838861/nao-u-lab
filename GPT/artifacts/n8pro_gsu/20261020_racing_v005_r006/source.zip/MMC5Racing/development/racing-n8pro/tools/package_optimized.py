"""r001 の回路を維持した r002 最適化 ROM と検証結果を配布する。"""
import argparse
import json
import shutil
import subprocess
import zipfile
from pathlib import Path
from optimize_rom import HERE, OUT, SOURCE_HASH, digest
from build import source_hashes, lab


def read(path):
    return json.loads(path.read_text())


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emulator-project', type=Path, required=True)
    parser.add_argument('--baseline-package', type=Path, required=True)
    parser.add_argument('--dest', type=Path, required=True)
    args = parser.parse_args()
    project, baseline, dest = args.emulator_project.resolve(), args.baseline_package.resolve(), args.dest.resolve()
    original = (project/'releases/GSU_MMC5Racing3D_v005.nes').read_bytes()
    assert digest(original) == SOURCE_HASH
    rom = (OUT/'GSU_MMC5Racing3D_v005_opt_r002.nes').read_bytes()
    manifest = read(OUT/'rom-manifest.json')
    assert manifest['rom_sha256'] == digest(rom)
    assert manifest['sources'] == {p.relative_to(HERE).as_posix(): digest(p.read_bytes()) for p in sorted((HERE/'gsu').iterdir()) if p.is_file()}
    names = ['comparison', 'rtl-baseline', 'rtl-optimized', 'rtl-stress-baseline', 'rtl-stress-optimized', 'boot-test']
    reports = {name: read(OUT/name/'verification.json') for name in names}
    current = source_hashes()
    for name, report in reports.items():
        assert report['status']=='pass', name
        if name!='comparison':assert report['sources']==current, ('stale RTL', name)
    for name in ['comparison', 'rtl-optimized']:
        assert reports[name]['rom_sha256']==digest(rom), name
    assert reports['boot-test']['source_rom_sha256']==digest(rom)
    assert reports['rtl-baseline']['rom_sha256']==SOURCE_HASH
    for name in ['baseline','optimized']:
        assert reports['rtl-stress-'+name]['rom_sha256']==digest((OUT/f'stress-4-{name}/stress.nes').read_bytes())
    assert reports['rtl-baseline']['poses']==reports['rtl-optimized']['poses']
    assert reports['rtl-stress-baseline']['poses']==reports['rtl-stress-optimized']['poses']
    oldmeta = read(baseline/'manifest.json')
    for name in ['gsu-test', 'dsp-test', 'display-test', 'boot-test']:
        assert read(baseline/f'verification/{name}.json')['sources']==current, 'r001 circuit changed'
    rbf = baseline/'sdcard/GSU-RACING-V005/gsu.rbf'
    assert digest(rbf.read_bytes())==oldmeta['rbf_sha256']
    oldrom = (baseline/'sdcard/GSU-RACING-V005/GSU_MMC5Racing3D_v005_N8Pro_r001.nes').read_bytes()
    assert digest(oldrom)==oldmeta['rom_sha256']
    target = dest/'sdcard/GSU-RACING-V005-R002'
    target.mkdir(parents=True, exist_ok=True)
    hardware = b'NES\x1a'+bytes([64,16,1,0])+bytes(8)+rom[16:1048592]+(rom[2097168:]+rom[1048608:1151008]).ljust(131072,b'\0')
    # Outside the two GSU code banks, every byte must match the r001 hardware ROM.
    a, b = bytearray(hardware), bytearray(oldrom)
    for bank in [1,2]:
        start=16+bank*8192+4096
        a[start:start+4096]=b[start:start+4096]
    assert bytes(a)==oldrom and len(hardware)==1179664
    (target/'GSU_MMC5Racing3D_v005_N8Pro_r002.nes').write_bytes(hardware)
    shutil.copy2(rbf, target/'gsu.rbf')
    pc = dest/'pc'
    pc.mkdir(exist_ok=True)
    (pc/'GSU_MMC5Racing3D_v005_opt_r002.nes').write_bytes(rom)
    (dest/'play_pc_25mhz.cmd').write_text('''@echo off
setlocal
set "GSU_ROOT=%~dp0..\\..\\..\\.tmp\\nesfx-audio-repo\\GPT\\projects\\nes_superfx"
python "%GSU_ROOT%\\tools\\launch.py" --mapper n8pro-racing-gsu --runtime "%GSU_ROOT%\\runtime_mode7" --gsu-mhz 25 "%~dp0pc\\GSU_MMC5Racing3D_v005_opt_r002.nes"
if errorlevel 1 pause
''', encoding='ascii')
    verification = dest/'verification'
    verification.mkdir(exist_ok=True)
    for name in names:
        shutil.copy2(OUT/name/'verification.json', verification/(name+'.json'))
        if (OUT/name/'simulation.log').exists():shutil.copy2(OUT/name/'simulation.log', verification/(name+'.log'))
    for name in ['rom-manifest.json', 'poses.json', 'stress-poses.json', 'profile.json']:
        shutil.copy2(OUT/name, verification/name)
    # Unchanged circuit evidence is clearly labelled, not presented as a new fit.
    evidence = verification/'unchanged-r001-circuit'
    evidence.mkdir(exist_ok=True)
    for name in ['bitstream-manifest.json','racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin','dsp-test.json','display-test.json']:
        shutil.copy2(baseline/'verification'/name, evidence/name)
    timing = []
    for pose, before, after in zip(reports['rtl-baseline']['poses'], reports['rtl-baseline']['rtl_clocks'], reports['rtl-optimized']['rtl_clocks']):
        assert after<before, pose
        timing.append(dict(name=pose['name'], before_ms=before/25000, after_ms=after/25000,
                           savings_percent=round((1-after/before)*100,3)))
    (verification/'timing-summary.json').write_text(json.dumps(timing,indent=2)+'\n')
    with zipfile.ZipFile(dest/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE, lab.LAB, lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        z.write(project/'LICENSE','nes_superfx/LICENSE')
    initial = timing[:4]
    text = '''MMC5Racing 3D v005 / N8 Pro 最適化試験版 r002（2026-10-18）

実機動作は未確認。r001 と同じ FPGA 回路（gsu.rbf）を使い、GSU の命令だけを最適化。
地面、空、車、木、家、LOD、音、物理、6502プログラムは変更していない。
パレット自動選択の提案は保留。実機用メモリと25MHz設定もそのまま。

実機での起動
1. 本体の電源を切り、sdcard/GSU-RACING-V005-R002 をフォルダーごと SD にコピー。
2. 中の GSU_MMC5Racing3D_v005_N8Pro_r002.nes を選び Start Game。
3. 5秒程度待っても黒いままなら本体RESETを一度押す。
4. メニューには電源を入れ直して戻る。
ROMと同じフォルダーの gsu.rbf が必要。従来の立方体版とr001は保持する。

A: 加速、B: ブレーキ/ドリフト、左右: 操舵、SELECT: 視点切替。
上: ポリゴン表示切替、下: GRIP/DRIFT、START: 走行リセット。

PC確認
このワークスペース内では play_pc_25mhz.cmd で専用Mesenを起動できる。
pc/ のROMはPC専用。SDには sdcard/ 側を使用する。
PCとFPGAは待ち時間のモデルが異なり、同じ25MHz指定でも描画時間は同じではない。

変更
- 頂点変換の固定小数点乗算をループ内に置き、命令キャッシュ外への往復を削減。
- 中間座標と積をレジスタに保持し、RAMへの書き戻しと読み直しを削減。
- 上端クリップ不要の辺は、端点・符号・除数をレジスタに保持してDDA初期化を短縮。
- 固定14/15ビット右シフトの上位8ビット分をHIB命令で処理。
- FPGA回路、外部メモリ転送量、RAM容量、コードの4KB領域は維持。

検証
- 通常1,412条件＋景物2/4回描画の8条件、計1,420フレームの全16KBが旧版と一致。
- 25MHzのGSU RTLで開始4視点と重い4場面の全画素を照合。
- 4回描画の重い1場面も旧版/最適化版をRTLで照合。
- 実6502の起動/NMI外部バス再生、GSU、DSP、完成画像のPSRAM転送を確認。
- 回路はr001のバイナリと完全一致。r001の合成・タイミング資料を同梱。

開始4視点のGSU時間（RTLシミュレーション、実機実測ではない）
'''
    text += '\n'.join(f"{i}: {r['before_ms']:.3f} → {r['after_ms']:.3f} ms（{r['savings_percent']:.1f}%短縮）" for i,r in enumerate(initial))
    text += '''

限界
計測はGSUのGO〜STOP。消去、CPU処理、DSP待ち、画像転送、VBlank待ちは含まない。
描画反復は同じ景物を重ねる合成負荷試験で、異なる物体を4倍置いた試験ではない。
全場面30fpsや実機起動の保証ではない。重い場面の数値はverification/timing-summary.json参照。
外部バスタイミングと実機での継続走行は未確認。r001の黒画面原因を直す変更ではない。

verification/: 比較結果、回路シミュレーション記録、元の回路の合成記録。
source.zip: 最適化GSU、回路、ビルド/検証ツール、ライセンス。
'''
    (dest/'README.txt').write_text(text,encoding='utf-8-sig')
    archive = dest/'N8Pro_Racing_v005_r002_test.zip'
    output = dict(version='v005_N8Pro_r002', source_rom_sha256=SOURCE_HASH,
                  pc_rom_sha256=digest(rom), rom_sha256=digest(hardware), rbf_sha256=oldmeta['rbf_sha256'],
                  hardware_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab.ROOT,text=True).strip(),
                  unchanged_rbf=True, rtl_sources=current, gsu_sources=manifest['sources'], gsu_clock_hz=25000000,
                  hardware_tested=False, timing_signoff=False,
                  files={p.relative_to(dest).as_posix():digest(p.read_bytes()) for p in sorted(dest.rglob('*')) if p.is_file() and p.name not in ['manifest.json',archive.name]})
    (dest/'manifest.json').write_text(json.dumps(output,indent=2)+'\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps(dict(archive=str(archive),rom_sha256=output['rom_sha256'],timing=timing),indent=2))


if __name__ == '__main__':
    main()
