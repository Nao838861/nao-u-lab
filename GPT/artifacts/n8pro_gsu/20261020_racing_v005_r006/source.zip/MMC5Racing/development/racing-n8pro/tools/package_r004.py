"""検証済みの景物増量版を、旧版を上書きせずPC/N8 Pro用に保存する。"""
import argparse,hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
from build import source_hashes,lab,HERE,OUT

def digest(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--dest',type=Path,required=True);a=p.parse_args()
    project=a.project.resolve();dest=a.dest.resolve();r004=OUT/'r004';game=r004/'balanced-release/game.nes';rom=game.read_bytes()
    sha=digest(rom);core=project/'build/r004-core-calibrated/MesenCore.dll';core_sha=digest(core.read_bytes())
    sources=source_hashes();bitstream=read(OUT/'bitstream-manifest.json');rbf=OUT/'quartus/output_files/racing.rbf'
    assert all(bitstream['inputs'].get(k)==v for k,v in sources.items()) and digest(rbf.read_bytes())==bitstream['sha256']
    reports={
        'rtl-gsu':r004/'rtl-release-final/verification.json',
        'rtl-boot':r004/'boot-release-final/verification.json',
        'rtl-display':OUT/'palette-test/verification.json',
        'native-1600':r004/'balanced-release/scan.json',
        'model-vs-rtl':r004/'model-release-final/verification.json',
        'full-route-fps':project/'build/r004/full-route-release/verification.json',
        'heavy-ppu-fps':project/'build/r004/ppu-balanced-final/verification.json',
        'legacy-r003':project/'build/r004/legacy-r003-final/verification.json',
    }
    for name,path in reports.items():
        r=read(path);assert r['status']=='pass',name
        if name.startswith('rtl-'):assert r['sources']==sources,name
        if name not in ['rtl-display','legacy-r003']:assert r.get('rom_sha256',r.get('source_rom_sha256'))==sha,name
        if 'core_sha256' in r:assert r['core_sha256']==core_sha,name
    assert read(reports['full-route-fps'])['below_30fps']==0
    ppu=read(reports['heavy-ppu-fps']);assert min(ppu['measured_fps'])>=30
    target=dest/'sdcard/GSU-RACING-V005-R004';target.mkdir(parents=True,exist_ok=True)
    hardware=b'NES\x1a'+bytes([64,16,1,0])+bytes(8)+rom[16:1048592]+(rom[2097168:]+rom[1048608:1151008]).ljust(131072,b'\0')
    assert len(hardware)==1179664 and hardware[16:1048592]==rom[16:1048592]
    (target/'GSU_MMC5Racing3D_v005_N8Pro_r004.nes').write_bytes(hardware);shutil.copy2(rbf,target/'gsu.rbf')
    pc=dest/'pc';pc.mkdir(exist_ok=True);shutil.copy2(game,pc/'GSU_MMC5Racing3D_v005_opt_r004.nes');shutil.copy2(core,pc/core.name)
    shutil.copy2(project/'runtime_r004/Mesen-LICENSE.txt',pc/'Mesen-LICENSE.txt')
    (dest/'play_pc_25mhz.cmd').write_text('''@echo off
setlocal
set "GSU_ROOT=%~dp0..\\..\\..\\.tmp\\nesfx-audio-repo\\GPT\\projects\\nes_superfx"
python "%GSU_ROOT%\\tools\\setup_mode7_runtime.py" --core "%~dp0pc\\MesenCore.dll" --mesen-dir "%GSU_ROOT%\\runtime_sky" --out "%GSU_ROOT%\\runtime_r004"
if errorlevel 1 exit /b 1
python "%GSU_ROOT%\\tools\\launch.py" --mapper n8pro-racing-gsu --runtime "%GSU_ROOT%\\runtime_r004" --gsu-mhz 25 "%~dp0pc\\GSU_MMC5Racing3D_v005_opt_r004.nes"
if errorlevel 1 pause
''',encoding='ascii')
    ver=dest/'verification';ver.mkdir(exist_ok=True)
    for name,path in reports.items():
        shutil.copy2(path,ver/(name+'.json'))
        for log in ['simulation.log','emulator.log','timing.csv','clocks.json','fps.json']:
            if (path.parent/log).exists():shutil.copy2(path.parent/log,ver/(name+'-'+log))
    for name in ['racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin']:shutil.copy2(OUT/'quartus/output_files'/name,ver/name)
    shutil.copy2(OUT/'bitstream-manifest.json',ver/'bitstream-manifest.json')
    shutil.copy2(r004/'balanced-release/rom-manifest.json',ver/'rom-manifest.json')
    shutil.copy2(r004/'balanced-release/ppu-cases.json',ver/'selected.json')
    for name in ['contract.log','build-manifest.json']:shutil.copy2(core.parent/name,ver/name)
    shutil.copy2(lab.BUILD/'simulation-report.json',ver/'legacy-rtl-diagnostic.json')
    for stage in ['cached_planes','tight_cull','packed_plots','rtl-fast','rtl-dense-single','rtl-dense-cache','model-dense-calibrated','model-clustered-calibrated']:
        folder=ver/'iterations'/stage;folder.mkdir(parents=True,exist_ok=True)
        for name in ['verification.json','gsu.s','scenery.inc']:
            if (r004/stage/name).exists():shutil.copy2(r004/stage/name,folder/name)
    pictures=dest/'screenshots';pictures.mkdir(exist_ok=True)
    for image in (project/'build/r004/ppu-balanced-final').glob('*.png'):shutil.copy2(image,pictures/image.name)
    shutil.copy2(HERE/'R004_OPTIMIZATION.md',dest/'optimization.md')
    rtl_times=read(reports['rtl-gsu'])['rtl_ms'];model_max=read(reports['native-1600'])['max_model_ms']
    margins=[r['model_margin_percent'] for r in read(reports['model-vs-rtl'])['cases']]
    (dest/'README.txt').write_text(f'''MMC5Racing 3D v005 / 景物増量・最適化 r004（2026-10-18）

木10本・家3軒（旧8本・2軒）。幹は奥行き64ワールド単位まで表示（旧24）。
地面・音・物理・家の形状・r003の空パレットは維持。家のLODなし。

PC: play_pc_25mhz.cmd を実行。専用Mesen、GSU 25MHz。
このワークスペースの .tmp/nesfx-audio-repo と既存 runtime_sky を参照する。
専用コアは pc/MesenCore.dll に保存。実行先は別フォルダー runtime_r004。
通常版Mesenでは動かない。旧r001/r002/r003のROM・コア・ランチャーは保持。

N8 Pro: sdcard/GSU-RACING-V005-R004 をフォルダーごとSDにコピー。
電源を入れ直してメニューから GSU_MMC5Racing3D_v005_N8Pro_r004.nes を起動。
必ず同梱のgsu.rbfを使う。旧RBFでは今回の速度にはならない。
黒いままなら一度本体RESET、メニューに戻るには電源を入れ直す。
実機動作は未確認。従来の黒画面問題を直したとする版ではない。

検証:
- Mesen 25MHzで全周64地点×4視点×3ドリフト角＝768姿勢、全姿勢30.05fps以上。
- 重い代表8姿勢を各120VBlank計測し、30.05fps。遠方の木2姿勢も30fps以上。
- 1,600姿勢の高速/従来メモリーモデルで全描画バッファ一致。
- 代表8姿勢のRTL描画{min(rtl_times):.2f}〜{max(rtl_times):.2f}ms。CPU/DSP/転送を含めないGSU単体値。
- 命令時間モデルの最悪{model_max:.2f}ms。代表8姿勢ではRTLより{min(margins):.2f}〜{max(margins):.2f}%長い見積もり。
- FPGA 6,118/6,272 LE。25MHz内部setup余裕3.377ns、hold余裕0.133ns。
- 6502起動/NMIバス、GSU/DSP/画面DMA、65,536通りの空合成、旧ROMの互換を検証。

30fpsは検査した配置・姿勢の範囲。20景物の2倍配置は一部で不足するため配布版には採用しない。
外部バスのタイミング保証と実機確認は別途必要。Mesenはサイクル完全一致モデルではない。
共有メッシュ化による座標丸め差は最大1/128ワールド単位（輪郭の1画素差はあり得る）。

操作: A加速、Bブレーキ/ドリフト、左右操舵、SELECT視点、上ポリゴン表示切替、下GRIP/DRIFT、START走行リセット。
optimization.mdに採否と再生成手順、verification/に測定、source.zipにソースとライセンス。
''',encoding='utf-8-sig')
    with zipfile.ZipFile(dest/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE,lab.LAB,lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        for folder in [project/'src',project/'tools']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
        z.write(project/'LICENSE','nes_superfx/LICENSE')
        z.write(project/'build/generated/source_manifest.json','nes_superfx/generated-source-manifest.json')
    archive=dest/'N8Pro_Racing_v005_r004_test.zip'
    manifest=dict(version='v005_N8Pro_r004',pc_rom_sha256=sha,rom_sha256=digest(hardware),rbf_sha256=bitstream['sha256'],core_sha256=core_sha,
                  rtl_sources=sources,hardware_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab.ROOT,text=True).strip(),
                  emulator_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),
                  gsu_clock_hz=25000000,trees=10,houses=3,trunk_lod_depth_world=64,hardware_tested=False,timing_signoff=False,
                  files={f.relative_to(dest).as_posix():digest(f.read_bytes()) for f in sorted(dest.rglob('*')) if f.is_file() and f.name not in ['manifest.json',archive.name]})
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,rom_sha256=sha)))

if __name__=='__main__':main()
