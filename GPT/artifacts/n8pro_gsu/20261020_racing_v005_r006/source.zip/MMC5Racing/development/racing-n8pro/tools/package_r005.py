"""容量削減の比較証拠と、同じMesenコアで動くr005を独立保存する。"""
import argparse,hashlib,json,re,shutil,subprocess,zipfile
from pathlib import Path
from build import HERE,OUT,source_hashes,lab
from area_r005 import REVISION

def digest(data):return hashlib.sha256(data).hexdigest()
def read(path):return json.loads(path.read_text())

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--baseline',type=Path,required=True)
    p.add_argument('--dest',type=Path,required=True);a=p.parse_args();project=a.project.resolve();baseline=a.baseline.resolve();dest=a.dest.resolve()
    root=OUT/'r005';release=root/'release';romfile=release/'GSU_MMC5Racing3D_v005_opt_r005.nes';rom=romfile.read_bytes();sha=digest(rom)
    previous=read(baseline/'manifest.json');core=baseline/'pc/MesenCore.dll';core_sha=digest(core.read_bytes());assert core_sha==previous['core_sha256']
    current=source_hashes();bitstream=read(OUT/'bitstream-manifest.json');rbf=OUT/'quartus/output_files/racing.rbf'
    assert all(bitstream['inputs'].get(k)==v for k,v in current.items()) and digest(rbf.read_bytes())==bitstream['sha256']
    assert bitstream['logic_elements']<6118 and bitstream['m9k_blocks']<30
    assert digest((root/'area/quartus/output_files/racing.rbf').read_bytes())==previous['rbf_sha256']
    assert (root/'rows2-origin-narrow-adder-positive-compact-area-seed3/quartus/output_files/racing.rbf').read_bytes()==rbf.read_bytes()
    reports={
        'native-1600':root/'regs-clear-full/verification.json',
        'rtl-gsu':release/'rtl-gsu/verification.json',
        'rtl-dsp':release/'rtl-dsp/verification.json',
        'rtl-boot-r004':release/'rtl-boot-r004/verification.json',
        'rtl-boot-r005':release/'rtl-boot-r005/verification.json',
        'protocol-stress':root/'rows2-origin-narrow-adder-positive-compact-area/stress/verification.json',
        'model-vs-rtl':release/'model-vs-rtl/verification.json',
        'compact-address':release/'compact-address.json',
        'full-route-fps':project/'build/r005/full-route/verification.json',
        'ppu-fps':project/'build/r005/ppu/verification.json',
    }
    for name,path in reports.items():
        r=read(path);assert r['status']=='pass',name
        if name.startswith('rtl-'):assert r['sources']==current and r['cycle_equivalence']=='pass',name
        if name in ['native-1600','rtl-gsu','rtl-boot-r005','model-vs-rtl','full-route-fps','ppu-fps']:
            assert r.get('rom_sha256',r.get('source_rom_sha256'))==sha,name
        if name=='rtl-boot-r004':assert r['source_rom_sha256']==previous['pc_rom_sha256']
        if 'core_sha256' in r:assert r['core_sha256']==core_sha
    stress=read(reports['protocol-stress'])
    assert all(stress['sources'][Path(k).name]==v for k,v in current.items())
    assert read(reports['full-route-fps'])['below_30fps']==0 and min(read(reports['ppu-fps'])['measured_fps'])>=30
    target=dest/'sdcard/GSU-RACING-V005-R005';target.mkdir(parents=True,exist_ok=True)
    hardware=b'NES\x1a'+bytes([64,16,1,0])+bytes(8)+rom[16:1048592]+(rom[2097168:]+rom[1048608:1151008]).ljust(131072,b'\0')
    assert len(hardware)==1179664
    (target/'GSU_MMC5Racing3D_v005_N8Pro_r005.nes').write_bytes(hardware);shutil.copy2(rbf,target/'gsu.rbf')
    pc=dest/'pc';pc.mkdir(exist_ok=True);shutil.copy2(romfile,pc/romfile.name);shutil.copy2(core,pc/core.name);shutil.copy2(baseline/'pc/Mesen-LICENSE.txt',pc/'Mesen-LICENSE.txt')
    # Preserve release file hashes across Windows Git checkouts.
    (dest/'.gitattributes').write_text('* -text\n',encoding='ascii')
    (dest/'play_pc_25mhz.cmd').write_text('''@echo off
setlocal
set "GSU_ROOT=%~dp0..\\..\\..\\.tmp\\nesfx-audio-repo\\GPT\\projects\\nes_superfx"
python "%GSU_ROOT%\\tools\\setup_mode7_runtime.py" --core "%~dp0pc\\MesenCore.dll" --mesen-dir "%GSU_ROOT%\\runtime_sky" --out "%GSU_ROOT%\\build\\r005\\runtime"
if errorlevel 1 exit /b 1
python "%GSU_ROOT%\\tools\\launch.py" --mapper n8pro-racing-gsu --runtime "%GSU_ROOT%\\build\\r005\\runtime" --gsu-mhz 25 "%~dp0pc\\GSU_MMC5Racing3D_v005_opt_r005.nes"
if errorlevel 1 pause
''',encoding='ascii')
    ver=dest/'verification';ver.mkdir(exist_ok=True)
    for name,path in reports.items():
        shutil.copy2(path,ver/(name+'.json'))
        for log in ['simulation.log','emulator.log','timing.csv','clocks.json','fps.json']:
            if (path.parent/log).exists():shutil.copy2(path.parent/log,ver/(name+'-'+log))
    for name in ['rom-manifest.json','selected.json']:shutil.copy2(release/name,ver/name)
    shutil.copy2(OUT/'bitstream-manifest.json',ver/'bitstream-manifest.json')
    for name in ['racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin']:shutil.copy2(OUT/'quartus/output_files'/name,ver/name)
    # The display source did not change; retain its existing exhaustive proof.
    shutil.copy2(baseline/'verification/rtl-display.json',ver/'inherited-display-r004.json')
    assert read(ver/'inherited-display-r004.json')['sources']['development/racing-n8pro/rtl/racing_display.vhd']==current['development/racing-n8pro/rtl/racing_display.vhd']
    experiments=[]
    with zipfile.ZipFile(dest/'experiments.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in sorted(root.iterdir()):
            if not (folder/'result.json').exists():continue
            result=read(folder/'result.json');experiments.append(result)
            for f in [folder/'result.json',folder/'quartus.log',folder/'quartus/racing.qsf',*sorted((folder/'src').glob('*.vhd'))]:
                if f.exists():z.write(f,f.relative_to(root).as_posix())
        for stage in ['floor-branches-full','inside-floor-full','regs-clear-full']:
            for name in ['gsu.s','scenery.inc','verification.json']:z.write(root/stage/name,stage+'/'+name)
    (ver/'experiments.json').write_text(json.dumps(experiments,indent=2)+'\n')
    with zipfile.ZipFile(dest/'testbenches.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ['rtl-gsu','rtl-dsp','rtl-boot-r004','rtl-boot-r005','protocol-stress']:
            for f in sorted(reports[name].parent.iterdir()):
                if f.suffix in ['.vhd','.hex','.log','.json']:z.write(f,name+'/'+f.name)
    pictures=dest/'screenshots';pictures.mkdir(exist_ok=True)
    for f in (project/'build/r005/ppu').glob('*.png'):shutil.copy2(f,pictures/f.name)
    shutil.copy2(HERE/'R005_OPTIMIZATION.md',dest/'optimization.md')
    (dest/'README.txt').write_text(f'''MMC5Racing 3D v005 / 最適化・FPGA容量削減 r005（2026-10-19）

PC: play_pc_25mhz.cmd を実行。専用Mesen・25MHz。コアDLLと時間モデルはr004と同じ。
このワークスペースの .tmp/nesfx-audio-repo と既存 runtime_sky を参照する。
実行フォルダーは専用の build/r005/runtime。通常版Mesenでは動かない。

N8 Pro: sdcard/GSU-RACING-V005-R005 をフォルダーごとSDへコピー。
電源を入れ直して GSU_MMC5Racing3D_v005_N8Pro_r005.nes を起動。同梱のgsu.rbfを使用。
黒いままなら一度本体RESET。メニューへは電源を入れ直す。実機動作は未確認。

FPGA: 6,118→{bitstream['logic_elements']:,} LE（空き154→{6272-bitstream['logic_elements']}）。RAM 30→{bitstream['m9k_blocks']}ブロック。
RAMのデータ量は同じ。乗算器は15個。内部setup余裕{bitstream['internal_setup_min_ns']}ns、hold余裕{bitstream['internal_hold_min_ns']}ns。
旧ROM・新ROMの両方で、検査した入力に対する旧回路との出力値・応答クロック一致を確認。
新しいRBFはr004 ROMでも同じ応答になる設計。旧ROM＋新RBFで比較できる。
外部バスタイミングと実機の保証は未完了。LEの空きはまだ全体の約5%。

GSU: 1,600姿勢の画像が一致し、命令モデル合計4.47%短縮。RTL代表8場面の最大23.76→22.60ms。
GSU単体の値で、画面転送やCPU処理を含まない。Mesen全体は全周768姿勢すべて30.05fps以上。
木10本・家3軒、幹の境界64。景物・地面・色・音・物理はr004のまま。

操作: A加速、Bブレーキ/ドリフト、左右操舵、SELECT視点、上ポリゴン表示切替、下GRIP/DRIFT、START走行リセット。
optimization.mdに全18案と採否。verification/に結果、experiments.zipに試行ソースとログ、
testbenches.zipに比較テスト、source.zipにソースとライセンス。旧版・記録動画は保持。
''',encoding='utf-8-sig')
    with zipfile.ZipFile(dest/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE,lab.LAB,lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        for f in sorted((root/'reference').glob('*.vhd')):z.write(f,'reference_r004/'+f.name)
        for folder in [project/'src',project/'tools']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
        for name in ['LICENSE','sources.lock.json']:
            if (project/name).exists():z.write(project/name,'nes_superfx/'+name)
        for name in ['NesFxGsu.hpp','source_manifest.json']:z.write(project/'build/generated'/name,'nes_superfx/generated/'+name)
    archive=dest/'N8Pro_Racing_v005_r005_test.zip'
    manifest=dict(version='v005_N8Pro_r005',pc_rom_sha256=sha,rom_sha256=digest(hardware),rbf_sha256=bitstream['sha256'],core_sha256=core_sha,
                  unchanged_mesen_core=True,rtl_sources=current,reference_commit=REVISION,baseline_rbf_sha256=previous['rbf_sha256'],
                  hardware_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab.ROOT,text=True).strip(),
                  emulator_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),
                  gsu_clock_hz=25000000,trees=10,houses=3,trunk_lod_depth_world=64,hardware_tested=False,timing_signoff=False,
                  resources={k:bitstream[k] for k in ['logic_elements','m9k_blocks','dsp_9bit_elements','seed']},
                  files={f.relative_to(dest).as_posix():digest(f.read_bytes()) for f in sorted(dest.rglob('*')) if f.is_file() and f.name not in ['manifest.json',archive.name]})
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,rom_sha256=sha,rbf_sha256=manifest['rbf_sha256'])))

if __name__=='__main__':main()
