"""r005を残して、r006のROM・同一回路・再現ソース・測定証拠を別保存する。"""
import argparse, hashlib, json, shutil, subprocess, zipfile
from pathlib import Path
from build import HERE, OUT, source_hashes, lab
from optimize_r006 import ROOT, REVISION


def digest(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text(encoding='utf-8'))


def main():
    p=argparse.ArgumentParser()
    for name in ['project','baseline','dest']:p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();project=a.project.resolve();baseline=a.baseline.resolve();dest=a.dest.resolve()
    release=ROOT/'release';romfile=release/'GSU_MMC5Racing3D_v005_opt_r006.nes';rom=romfile.read_bytes();sha=digest(rom)
    previous=read(baseline/'manifest.json');core=baseline/'pc/MesenCore.dll';rbf=baseline/'sdcard/GSU-RACING-V005-R005/gsu.rbf'
    assert digest(core.read_bytes())==previous['core_sha256'] and digest(rbf.read_bytes())==previous['rbf_sha256']
    current=source_hashes();assert current==previous['rtl_sources']
    assert (ROOT/'baseline/quartus/output_files/racing.rbf').read_bytes()==rbf.read_bytes()
    reports={
        'native-1600':ROOT/'final-full/verification.json',
        'summary':release/'summary.json',
        'rtl-gsu':release/'rtl-gsu/verification.json',
        'rtl-boot':release/'rtl-boot/verification.json',
        'model-vs-rtl':release/'model-vs-rtl/verification.json',
        'full-route-fps':project/'build/r006/full-route/verification.json',
        'ppu-fps':project/'build/r006/ppu/verification.json',
        'stress-20-native':ROOT/'stress-20/verification.json',
        'stress-20-fps':project/'build/r006/stress-full-route/verification.json',
    }
    stress=read(reports['stress-20-native'])
    for name,path in reports.items():
        r=read(path)
        assert r['status'] in (['pass','below_target'] if name=='stress-20-fps' else ['pass']),name
        if not name.startswith('stress-20'):assert r.get('rom_sha256',r.get('source_rom_sha256'))==sha,name
        if name.startswith('rtl-'):assert r['sources']==current,name
        if 'core_sha256' in r:assert r['core_sha256']==previous['core_sha256'],name
        if name=='stress-20-fps':assert r['rom_sha256']==stress['rom_sha256']
    assert not read(reports['summary'])['slower_cases']
    assert read(reports['full-route-fps'])['below_30fps']==0 and min(read(reports['ppu-fps'])['measured_fps'])>=30
    sd=dest/'sdcard/GSU-RACING-V005-R006';sd.mkdir(parents=True,exist_ok=True)
    hardware=b'NES\x1a'+bytes([64,16,1,0])+bytes(8)+rom[16:1048592]+(rom[2097168:]+rom[1048608:1151008]).ljust(131072,b'\0')
    assert len(hardware)==1179664
    (sd/'GSU_MMC5Racing3D_v005_N8Pro_r006.nes').write_bytes(hardware);shutil.copy2(rbf,sd/'gsu.rbf')
    pc=dest/'pc';pc.mkdir(exist_ok=True)
    for f in [romfile,core,baseline/'pc/Mesen-LICENSE.txt']:shutil.copy2(f,pc/f.name)
    (dest/'.gitattributes').write_text('* -text\n',encoding='ascii')
    (dest/'play_pc_25mhz.cmd').write_text('''@echo off
setlocal
set "GSU_ROOT=%~dp0..\\..\\..\\.tmp\\nesfx-audio-repo\\GPT\\projects\\nes_superfx"
python "%GSU_ROOT%\\tools\\setup_mode7_runtime.py" --core "%~dp0pc\\MesenCore.dll" --mesen-dir "%GSU_ROOT%\\runtime_sky" --out "%GSU_ROOT%\\build\\r006\\runtime"
if errorlevel 1 exit /b 1
python "%GSU_ROOT%\\tools\\launch.py" --mapper n8pro-racing-gsu --runtime "%GSU_ROOT%\\build\\r006\\runtime" --gsu-mhz 25 "%~dp0pc\\GSU_MMC5Racing3D_v005_opt_r006.nes"
if errorlevel 1 pause
''',encoding='ascii')
    ver=dest/'verification';ver.mkdir(exist_ok=True)
    for name,path in reports.items():
        shutil.copy2(path,ver/(name+'.json'))
        for log in ['simulation.log','emulator.log','timing.csv','clocks.json','fps.json']:
            if (path.parent/log).exists():shutil.copy2(path.parent/log,ver/(name+'-'+log))
    for name in ['rom-manifest.json','selected.json','ppu-cases.json']:shutil.copy2(release/name,ver/name)
    for name in ['bitstream-manifest.json','rtl-dsp.json','protocol-stress.json','inherited-display-r004.json']:
        shutil.copy2(baseline/'verification'/name,ver/('inherited-r005-'+name))
    for name in ['racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin']:
        shutil.copy2(ROOT/'baseline/quartus/output_files'/name,ver/name)
    with zipfile.ZipFile(dest/'experiments.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in sorted(ROOT.iterdir()):
            if (folder/'result.json').exists():
                for f in [folder/'result.json',folder/'quartus.log',folder/'quartus/racing.qsf',*sorted((folder/'src').glob('*.vhd'))]:
                    z.write(f,f.relative_to(ROOT).as_posix())
            elif (folder/'verification.json').exists():
                for f in sorted(folder.iterdir()):
                    if f.is_file() and f.suffix in ['.s','.inc','.cfg','.lbl','.json','.nes']:z.write(f,f.relative_to(ROOT).as_posix())
        fixture=lab.ROOT/'build/racing-n8pro/r004/dense/game.nes'
        assert digest(fixture.read_bytes())==stress['fixture_sha256']
        z.write(fixture,'stress-20/fixture-r004.nes')
    with zipfile.ZipFile(dest/'testbenches.zip','w',zipfile.ZIP_DEFLATED) as z:
        for name in ['rtl-gsu','rtl-boot']:
            for f in sorted(reports[name].parent.iterdir()):
                if f.suffix in ['.vhd','.hex','.log','.json']:z.write(f,name+'/'+f.name)
    pictures=dest/'screenshots';pictures.mkdir(exist_ok=True)
    for f in (project/'build/r006/ppu').glob('*.png'):shutil.copy2(f,pictures/f.name)
    shutil.copy2(HERE/'R006_OPTIMIZATION.md',dest/'optimization.md')
    (dest/'README.txt').write_text('''MMC5Racing 3D v005 / 継続最適化 r006（2026-10-20）

PC: play_pc_25mhz.cmd を実行。r004/r005と同じ専用Mesenコア・25MHz。
このワークスペースの .tmp/nesfx-audio-repo と runtime_sky を参照する。
実行フォルダーは専用の build/r006/runtime。通常版Mesenでは動かない。

N8 Pro: sdcard/GSU-RACING-V005-R006 をフォルダーごとSDへコピーし、
GSU_MMC5Racing3D_v005_N8Pro_r006.nes を起動。同梱gsu.rbfはr005と同じバイト列。
実機動作は未確認。黒いままなら本体RESETを一度試す。メニューへは電源を入れ直す。

GSU: r005より1,600姿勢の合計5.80%短縮、全画像一致。遅くなった姿勢はなし。
RTL代表8場面の最大22.60→21.04ms（GSU単体、CPU・画面転送を含まない）。
配布版は木10本・家3軒、幹の境界64。色・形・地面・音・物理を維持。
Mesen全体は全周768姿勢すべて30.05fps以上、重い8姿勢も各120VBlankで30.05fps。

FPGA追加案は採用せず、5,957/6,272 LE・M9K 28/30を保持。
20景物の負荷版は別の試験用。30fps保証を広げたものではない。
詳しい採否・残るボトルネック・検証限界はoptimization.md、測定値はverification/。
experiments.zipに試行ソースと負荷版、testbenches.zipにRTLテスト、source.zipにソース。
旧版と記録動画は保持。

操作: A加速、Bブレーキ/ドリフト、左右操舵、SELECT視点、上ポリゴン表示切替、
下GRIP/DRIFT、START走行リセット。
''',encoding='utf-8-sig')
    with zipfile.ZipFile(dest/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE,lab.LAB,lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        for f in sorted((ROOT/'reference').glob('*.vhd')):z.write(f,'reference_r005/'+f.name)
        for folder in [project/'src',project/'tools']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
        for name in ['LICENSE','sources.lock.json']:
            if (project/name).exists():z.write(project/name,'nes_superfx/'+name)
        for name in ['NesFxGsu.hpp','source_manifest.json']:z.write(project/'build/generated'/name,'nes_superfx/generated/'+name)
    archive=dest/'N8Pro_Racing_v005_r006_test.zip'
    manifest=dict(version='v005_N8Pro_r006',pc_rom_sha256=sha,rom_sha256=digest(hardware),rbf_sha256=previous['rbf_sha256'],core_sha256=previous['core_sha256'],
                  unchanged_mesen_core=True,unchanged_fpga_bitstream=True,rtl_sources=current,reference_commit=REVISION,
                  hardware_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab.ROOT,text=True).strip(),
                  emulator_source_commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),
                  gsu_clock_hz=25000000,trees=10,houses=3,trunk_lod_depth_world=64,hardware_tested=False,timing_signoff=False,
                  resources=previous['resources'],files={f.relative_to(dest).as_posix():digest(f.read_bytes()) for f in sorted(dest.rglob('*')) if f.is_file() and f.name not in ['manifest.json',archive.name]})
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n',encoding='utf-8')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps(dict(archive=str(archive),bytes=archive.stat().st_size,rom_sha256=sha,rbf_sha256=manifest['rbf_sha256'])))


if __name__=='__main__':main()
