"""空の適応パレット版 r003 を、既存 r002 を変更せず保存する。"""
import argparse,hashlib,json,shutil,subprocess,zipfile
from pathlib import Path
from build import source_hashes,lab,HERE,OUT

def digest(data):return hashlib.sha256(data).hexdigest()
def read(p):return json.loads(p.read_text())
def main():
    p=argparse.ArgumentParser();p.add_argument('--emulator-project',type=Path,required=True)
    p.add_argument('--baseline-package',type=Path,required=True);p.add_argument('--dest',type=Path,required=True);a=p.parse_args()
    project=a.emulator_project.resolve();dest=a.dest.resolve();baseline=a.baseline_package.resolve()
    romfile=project/'build/sky-palette/GSU_MMC5Racing3D_v005_sky_r003.nes';rom=romfile.read_bytes()
    old=(baseline/'pc/GSU_MMC5Racing3D_v005_opt_r002.nes').read_bytes()
    patch=read(romfile.with_suffix('.json'));assert digest(old)==patch['source_sha256'] and digest(rom)==patch['sha256']
    assert [i for i,(x,y) in enumerate(zip(old,rom)) if x!=y]==patch['changed_file_offsets']
    current=source_hashes();bitstream=read(OUT/'bitstream-manifest.json')
    assert all(bitstream['inputs'].get(k)==v for k,v in current.items())
    reports={name:read(OUT/name/'verification.json') for name in ['palette-test','sky-boot-test']}
    for name,r in reports.items():assert r['status']=='pass' and r['sources']==current,name
    assert reports['sky-boot-test']['source_rom_sha256']==digest(rom)
    ppu=read(project/'build/sky-palette/ppu/verification.json')
    assert ppu['status']=='pass' and ppu['rom_sha256']==digest(rom) and ppu['identical_gsu_clocks']
    rbf=OUT/'quartus/output_files/racing.rbf';assert digest(rbf.read_bytes())==bitstream['sha256']
    core=project/'build/sky-core/MesenCore.dll';assert digest(core.read_bytes())==ppu['core_sha256']
    target=dest/'sdcard/GSU-RACING-V005-R003';target.mkdir(parents=True,exist_ok=True)
    hardware=b'NES\x1a'+bytes([64,16,1,0])+bytes(8)+rom[16:1048592]+(rom[2097168:]+rom[1048608:1151008]).ljust(131072,b'\0')
    oldhardware=(baseline/'sdcard/GSU-RACING-V005-R002/GSU_MMC5Racing3D_v005_N8Pro_r002.nes').read_bytes()
    assert len(hardware)==1179664
    assert [i for i,(x,y) in enumerate(zip(oldhardware,hardware)) if x!=y]==[i for i in patch['changed_file_offsets'] if i<1048592]
    (target/'GSU_MMC5Racing3D_v005_N8Pro_r003.nes').write_bytes(hardware);shutil.copy2(rbf,target/'gsu.rbf')
    pc=dest/'pc';pc.mkdir(exist_ok=True);shutil.copy2(romfile,pc/romfile.name);shutil.copy2(core,pc/core.name)
    shutil.copy2(project/'runtime_sky/Mesen-LICENSE.txt',pc/'Mesen-LICENSE.txt')
    (dest/'play_pc_25mhz.cmd').write_text('''@echo off
setlocal
set "GSU_ROOT=%~dp0..\\..\\..\\.tmp\\nesfx-audio-repo\\GPT\\projects\\nes_superfx"
if not exist "%GSU_ROOT%\\runtime_sky\\Mesen.exe" (
  python "%GSU_ROOT%\\tools\\setup_mode7_runtime.py" --core "%~dp0pc\\MesenCore.dll" --mesen-dir "%GSU_ROOT%\\runtime_mode7" --out "%GSU_ROOT%\\runtime_sky"
  if errorlevel 1 exit /b 1
)
python "%GSU_ROOT%\\tools\\launch.py" --mapper n8pro-racing-gsu --runtime "%GSU_ROOT%\\runtime_sky" --gsu-mhz 25 "%~dp0pc\\GSU_MMC5Racing3D_v005_sky_r003.nes"
if errorlevel 1 pause
''',encoding='ascii')
    verification=dest/'verification';verification.mkdir(exist_ok=True)
    for name in reports:
        for source,targetname in [('verification.json',name+'.json'),('simulation.log',name+'.log')]:shutil.copy2(OUT/name/source,verification/targetname)
    for name in ['racing.fit.summary','racing.fit.rpt','racing.sta.rpt','racing.pin']:shutil.copy2(OUT/'quartus/output_files'/name,verification/name)
    shutil.copy2(OUT/'bitstream-manifest.json',verification/'bitstream-manifest.json')
    shutil.copy2(romfile.with_suffix('.json'),verification/'rom-manifest.json')
    for name in ['contract.log','build-manifest.json']:shutil.copy2(project/'build/sky-core'/name,verification/name)
    for name in ['verification.json','clocks.json']:shutil.copy2(project/'build/sky-palette/ppu'/name,verification/('ppu-'+name))
    shutil.copy2(project/'build/sky-palette/legacy/verification.json',verification/'legacy-ppu.json')
    pictures=dest/'screenshots';pictures.mkdir(exist_ok=True)
    for name in ['object-0-v0-a8192-d40.png','object-8-v0-a8192-d40.png','object-8-v1-a8192-d40.png']:
        for version in ['ppu','legacy']:shutil.copy2(project/'build/sky-palette'/version/name,pictures/(version+'-'+name))
    text='''MMC5Racing 3D v005 / 空の適応パレット版 r003（2026-10-18）

依頼: 「空側を、水色、灰色、緑色、赤が表示できるように」「地面側で書いたものと色を合わせる」
確認: 「白のこと。空では白が水色になってよい」
地面の色は変更せず、8×1画素ごとに空側のパレットと色番号を選ぶ方式を採用。

PC: このフォルダーの play_pc_25mhz.cmd を実行（専用 Mesen、25MHz）。
このランチャーは現在のワークスペース内の .tmp/nesfx-audio-repo を参照する。
通常版 Mesen に ROM を単独で渡しても動作しない。pc/MesenCore.dll に今回の専用コアを保存。
runtime_sky がない場合は、既存 runtime_mode7 の UI と付属ライブラリから作成する。
旧 r002 のランチャー、ROM、Mesen コアは変更していない。

N8 Pro: sdcard/GSU-RACING-V005-R003 をフォルダーごと SD にコピー。
本体の電源を入れ直してメニューから GSU_MMC5Racing3D_v005_N8Pro_r003.nes を起動。
同じフォルダーの新しい gsu.rbf が必要。旧版の ROM/RBF と混ぜない。
黒いままなら一度本体 RESET。メニューへ戻るには電源を入れ直す。
実機動作は未確認。この変更は従来の実機黒画面の原因を直すものではない。

パレット（全組の0番は NES の共通背景色・白のまま）
P0: 白・赤・緑・灰色   $30 $16 $1A $00
P1: 白・赤・緑・水色   $30 $16 $1A $21
P2: 白・赤・灰色・水色 $30 $16 $00 $21
P3: 白・灰色・緑・水色 $30 $00 $1A $21
地面は P0。空の透明部分は水色、FX は赤・緑・灰色を優先。
空の8画素すべてを FX が覆えば P0、空＋赤＋灰色は P2、空＋緑＋灰色は P3。
同じ8×1に水色・赤・緑・灰色の全4色が必要な場合だけ、灰色を水色に近似する。
FX の0番は引き続き透明。白を不透明に描く機能は追加しない。

負荷と検証
- GSU命令、ポリゴン、地面テクスチャ、音、物理は r002 と同じ。
- 合成の追加クロック、メモリアクセス、追加RAMはゼロ。既存1クロック内で色を選択。
- FPGA: 6,076 / 6,272 LE（旧版6,054、+22）、25MHz内部タイミング成立。
- setup最小余裕6.246ns、hold最小余裕0.103ns。外部バスのタイミング保証は未完了。
- C++で65,536通りのFX色配置を全検査。旧合成とDSP投影の既存検査も通過。
- RTLで同じ65,536通り、透明描画、4視点、並行DMAを検証（786,432画素）。
- 実ROMの6502初期化/NMIバスをRTLへ再生し、GSU・DSP・画像DMAを確認。
- Mesenで家/木18場面＋FX非表示1場面、933,888画素を独立参照と照合。
- 旧版と地面/HUD757,248画素、GSU描画画像とクロック数が一致。
- 空側21,047画素で本来の灰色を復元。4色が衝突するブロックは検証場面合計11個。
- M7R5 のPC ROMだけ新合成を使用。M7R4 の旧ROMの表示も検証済み。

操作: A加速、Bブレーキ/ドリフト、左右操舵、SELECT視点、上ポリゴン表示切替、下GRIP/DRIFT、START走行リセット。
verification/ に検証記録、screenshots/ に変更前後、source.zip にソースを保存。
PCとFPGAではGSUの待ち時間モデルが異なるため、25MHz同士でも実行時間が一致する保証はない。
'''
    (dest/'README.txt').write_text(text,encoding='utf-8-sig')
    with zipfile.ZipFile(dest/'source.zip','w',zipfile.ZIP_DEFLATED) as z:
        for folder in [HERE,lab.LAB,lab.ROOT/'tools/python/py65']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'MMC5Racing/'+f.relative_to(lab.ROOT).as_posix())
        z.write(lab.ROOT/'tools/python/py65-LICENSE.txt','MMC5Racing/tools/python/py65-LICENSE.txt')
        for folder in [project/'src',project/'tools']:
            for f in sorted(folder.rglob('*')):
                if f.is_file() and '__pycache__' not in f.parts and f.suffix!='.pyc':z.write(f,'nes_superfx/'+f.relative_to(project).as_posix())
        z.write(project/'LICENSE','nes_superfx/LICENSE')
    archive=dest/'N8Pro_Racing_v005_r003_test.zip'
    manifest={'version':'v005_N8Pro_r003','pc_rom_sha256':digest(rom),'rom_sha256':digest(hardware),
              'rbf_sha256':bitstream['sha256'],'core_sha256':digest(core.read_bytes()),'rtl_sources':current,
              'hardware_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=lab.ROOT,text=True).strip(),
              'emulator_source_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=project,text=True).strip(),
              'gsu_clock_hz':25000000,'hardware_tested':False,'timing_signoff':False,
              'files':{f.relative_to(dest).as_posix():digest(f.read_bytes()) for f in sorted(dest.rglob('*')) if f.is_file() and f.name not in ['manifest.json',archive.name]}}
    (dest/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
        for f in sorted(dest.rglob('*')):
            if f.is_file() and f!=archive:z.write(f,f.relative_to(dest).as_posix())
    print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'rom_sha256':manifest['rom_sha256']}))

if __name__=='__main__':main()
