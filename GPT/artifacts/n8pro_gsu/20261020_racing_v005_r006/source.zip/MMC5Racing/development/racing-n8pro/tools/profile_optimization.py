"""比較で選んだ場面について、命令モデル上の残りの処理内訳を保存する。"""
import argparse
import json
import re
import struct
import subprocess
from pathlib import Path
from optimize_rom import OUT, digest


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--emulator-project',type=Path,required=True)
    args=parser.parse_args()
    project=args.emulator_project.resolve()
    comparison=json.loads((OUT/'comparison/verification.json').read_text())
    rom=(OUT/'GSU_MMC5Racing3D_v005_opt_r002.nes').read_bytes()
    assert comparison['rom_sha256']==digest(rom)
    labels={name:int(a,16) for a,name in re.findall(r'al ([0-9A-Fa-f]+) \.([^\s]+)',(OUT/'optimized/gsu.lbl').read_text())}
    names=['render_entry','mul8','transform','faces','clip_plane','project_model_polygon',
           'raster_polygon','edge_span','edge_rows','fill_spans','divide','tree_transform','plane_cull','car_camera']
    data=bytearray(40960)
    data[32768:]=rom[8208:16400]
    data[0x8004:0x8006]=b'\x00\x40'
    rows=[]
    for case in comparison['initial']+comparison['worst']:
        struct.pack_into('<11h',data,0x8008,*case['pose'])
        (OUT/'profile.bin').write_bytes(data)
        clocks=int(subprocess.check_output([project/'build/racing/v003/racing_profile.exe',OUT/'profile.bin',OUT/'profile'],text=True))
        counts=struct.unpack('<65536Q',(OUT/'profile.clocks').read_bytes())
        parts={name:sum(counts[labels[name]:labels[names[i+1]] if i+1<len(names) else 0xa000]) for i,name in enumerate(names)}
        parts['initial_pipeline']=sum(counts[:0x9000])+sum(counts[0xa000:])
        assert sum(parts.values())==clocks
        assert clocks==case['after_clocks']
        rows.append(dict(name=case['name'],clocks=clocks,parts=parts))
    report=dict(rom_sha256=digest(rom),scope='Native instruction-model clocks grouped by code address; helper time is separate, not inclusive call time',rows=rows)
    (OUT/'profile.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(rows[-1],indent=2))


if __name__=='__main__':
    main()
