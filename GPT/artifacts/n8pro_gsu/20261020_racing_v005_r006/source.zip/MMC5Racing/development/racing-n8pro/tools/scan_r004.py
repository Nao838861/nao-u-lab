"""増量した実配置を全周・接近で走査し、同じ命令の高速/通常RAM画像を比較する。"""
import argparse,json,struct,subprocess,sys
from pathlib import Path
from iterate_r004 import OUT
from optimize_rom import digest

def main():
    p=argparse.ArgumentParser();p.add_argument('--project',type=Path,required=True);p.add_argument('--variant',choices=['normal','balanced','dense'],required=True)
    p.add_argument('--probe',type=Path);p.add_argument('--folder',type=Path);a=p.parse_args()
    sys.path.insert(0,str(a.project/'tools'))
    import verify_racing_scenery as scenery
    import mmc5_state
    from build_ground import VIEWS
    folder=a.folder or OUT/a.variant;meta=json.loads((folder/'rom-manifest.json').read_text());scenery.TREES=meta['trees'];scenery.HOUSES=meta['houses']
    rows=scenery.cases();rom=(folder/'game.nes').read_bytes();probe=a.probe or a.project/'build/r004-core-calibrated/racing_profile.exe'
    out=folder/'scan';out.mkdir(exist_ok=True);data=bytearray(40960)
    for i,row in enumerate(rows):
        pose=mmc5_state.pose(bytes(row['state'])+bytes(2),VIEWS[row['view']]);row['pose']=list(pose)
        data[:32768]=bytes(32768);data[32768:]=rom[8208:16400];data[0x8004:0x8006]=b'\x00\x40';struct.pack_into('<11h',data,0x8008,*pose)
        (out/'input.bin').write_bytes(data)
        row['model_clocks']=int(subprocess.check_output([probe,out/'input.bin',out/'fast','fast'],text=True));row['model_ms']=row['model_clocks']/25000
        subprocess.check_output([probe,out/'input.bin',out/'slow'],text=True)
        assert (out/'fast.frame').read_bytes()==(out/'slow.frame').read_bytes(),('fast RAM mismatch',row['name'])
        if (i+1)%128==0:print(f'{a.variant} {i+1}/{len(rows)}',flush=True)
    selected=[]
    for view in range(4):
        for prefix in ['route','object']:
            selected.append(max([r for r in rows if r['view']==view and r['name'].startswith(prefix)],key=lambda r:r['model_clocks']))
    poses=[dict(name=r['name'],pose=r['pose']) for r in selected]
    report={'status':'pass','rom_sha256':digest(rom),'probe_sha256':digest(probe.read_bytes()),'identical_frames':len(rows),'model_clock_hz':25000000,'route_max_model_ms':max(r['model_ms'] for r in rows if r['name'].startswith('route')),
            'max_model_ms':max(r['model_ms'] for r in rows),'selected':selected,'all':rows,'hardware_tested':False,'scope':'Conservative Mesen instruction model; use RTL clocks for FPGA'}
    (folder/'scan.json').write_text(json.dumps(report,indent=2)+'\n');(folder/'poses.json').write_text(json.dumps(poses,indent=2)+'\n')
    (folder/'selected.json').write_text(json.dumps(selected,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['all','selected']}))

if __name__=='__main__':main()
