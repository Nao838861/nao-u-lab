"""演算境界値とDSPのbusy/reset/不正コマンドを旧回路と毎クロック比較する。"""
import argparse,hashlib,json,math,random,struct,subprocess
from pathlib import Path
from area_r005 import baseline,REVISION,lab
from equivalence_r005 import pair

def run(out,src,name,source,modules):
    reference=baseline();files=[]
    for module in modules:
        paths,_=pair((src/(module+'.vhd')).read_text(),(reference/(module+'.vhd')).read_text(),out);files.extend(paths)
    tb=out/(name+'.vhd');tb.write_text(source);ghdl=lab.ghdl_path()
    lab.run([ghdl,'-a','--std=08',*files,tb],cwd=out)
    r=subprocess.run([ghdl,'-r','--std=08',name,'--assert-level=error','--ieee-asserts=disable-at-0'],cwd=out,capture_output=True,text=True)
    (out/(name+'.log')).write_text(r.stdout+r.stderr);print(r.stdout[-2000:]);r.check_returncode();assert 'ALL STRESS TESTS PASSED' in r.stdout

def math_test(out,src,specialized=False):
    rng=random.Random(51019);limit=2**47;mask=2**48-1;values=[-limit,-limit+1,-65536,-1,0,1,65535,limit-1]
    rows=[(a,b,d) for a in values for b in values for d in [0,1]]
    rows += [(rng.randrange(-limit,limit),rng.randrange(-limit,limit),rng.randrange(2)) for _ in range(2048)]
    if specialized:
        narrow='RIGHT_OPERAND_BITS' in (src/'serial_math.vhd').read_text()
        bits=18 if narrow else 48;bound=2**(bits-1)
        rows=[(a,b,d) for a in values for d in [0,1] for b in ([-bound,-1,0,1,bound-1] if d==0 else [1,32768,65536,131072])]
        rows += [(rng.randrange(-limit,limit),rng.randrange(1,131073) if d else rng.randrange(-bound,bound),d) for d in [0,1] for _ in range(1024)]
    def expected(a,b,d):
        if not d:return a*b&mask
        q=abs(a)//abs(b) if b else mask
        return (-q if (a<0)!=(b<0) else q)&mask
    vector='math-specialized.hex' if specialized else 'math.hex'
    (out/vector).write_text(''.join(f'{d:X} {a&mask:012X} {b&mask:012X} {expected(a,b,d):012X}\n' for a,b,d in rows))
    source='''library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;use std.textio.all;use std.env.all;
entity tb_math_stress is end;architecture test of tb_math_stress is
signal clk,reset,start,divide,done:std_logic:='0';signal a,b,q:signed(47 downto 0):=(others=>'0');
begin clk<=not clk after 20 ns;
dut:entity work.serial_math port map(clk,reset,start,divide,a,b,q,done);
process
 file f:text open read_mode is "math.hex";variable l:line;variable mode:std_logic_vector(3 downto 0);variable av,bv,want:std_logic_vector(47 downto 0);variable trials:natural:=0;
begin
 reset<='1';wait for 80 ns;wait until falling_edge(clk);reset<='0';
 while not endfile(f) loop
  readline(f,l);hread(l,mode);hread(l,av);hread(l,bv);hread(l,want);
  a<=signed(av);b<=signed(bv);divide<=mode(0);start<='1';wait until falling_edge(clk);start<='0';
  for i in 1 to 48 loop
   if i=7 then start<='1';a<=not a;b<=not b;elsif i=8 then start<='0';end if;
   wait until falling_edge(clk);wait for 2 ps;
   if i<48 then assert done='0' report "Early math completion" severity failure;end if;
  end loop;
  assert done='1' and std_logic_vector(q)=want report "Arithmetic boundary mismatch " & integer'image(trials) severity failure;
  wait until falling_edge(clk);wait for 2 ps;assert done='0' severity failure;trials:=trials+1;
 end loop;
 report "ALL STRESS TESTS PASSED math " & integer'image(trials);stop;wait;
end process;end;'''
    name='tb_math_stress'
    if specialized:
        source=source.replace('tb_math_stress','tb_math_specialized').replace('"math.hex"','"math-specialized.hex"')
        generic='generic map(POSITIVE_DIVISOR=>true'+(',RIGHT_OPERAND_BITS=>18' if narrow else '')+')'
        source=source.replace('entity work.serial_math port map','entity work.serial_math '+generic+' port map');name='tb_math_specialized'
    run(out,src,name,source,['serial_math']);return len(rows)

def dsp_test(out,src):
    rng=random.Random(191005);cameras=[]
    for i in range(24):
        angle=rng.random()*math.tau;pc,ps=[(256,13),(253,36),(245,76),(187,174),(0,256),(256,0)][i%6]
        cameras.append([rng.randrange(-32768,32768),rng.randrange(-32768,32768),[1,320,1536,4608,16384][i%5],round(math.cos(angle)*256),round(math.sin(angle)*256),pc,ps])
    invalid=[]
    for index,value in [(2,-32768),(2,0),(2,16385),(3,0),(3,32767),(5,-1),(5,257),(6,-1),(6,257)]:
        camera=[0,0,320,256,0,256,13];camera[index]=value;invalid.append(camera)
    cameras+=invalid
    (out/'stress-cameras.hex').write_text(''.join(f'{b:02X}\n' for c in cameras for b in struct.pack('<7h',*c)))
    source='''library ieee;use ieee.std_logic_1164.all;use ieee.numeric_std.all;use ieee.std_logic_textio.all;use std.textio.all;use std.env.all;
entity tb_dsp_stress is end;architecture test of tb_dsp_stress is
signal clk,reset,wr,commit,cb,busy,ready,active,err,front,hide:std_logic:='0';
signal a:unsigned(4 downto 0):=(others=>'0');signal di,q:std_logic_vector(7 downto 0):=(others=>'0');signal ra:unsigned(10 downto 0):=(others=>'0');signal rq:std_logic_vector(31 downto 0);
signal lfsr:unsigned(15 downto 0):=x"ACE1";
begin clk<=not clk after 20 ns;
dut:entity work.mode7_dsp port map(clk,reset,a,di,wr,commit,cb,q,busy,ready,active,err,front,hide,ra,rq);
process(clk) begin if rising_edge(clk) then
 lfsr<=lfsr(14 downto 0)&(lfsr(15) xor lfsr(13) xor lfsr(12) xor lfsr(10));ra<=resize(lfsr mod 1536,11);
end if;end process;
process
 file f:text open read_mode is "stress-cameras.hex";variable l:line;variable value:std_logic_vector(7 downto 0);variable target:natural;
 procedure write_reg(addr,v:natural) is begin
  wait until falling_edge(clk);a<=to_unsigned(addr,5);di<=std_logic_vector(to_unsigned(v mod 256,8));wr<='1';wait until falling_edge(clk);wr<='0';
 end;
 procedure reset_dsp is begin reset<='1';wait for 80 ns;wait until falling_edge(clk);reset<='0';end;
begin
 reset_dsp;
 for trial in 0 to CASES-1 loop
  for i in 0 to 13 loop readline(f,l);hread(l,value);write_reg(i,to_integer(unsigned(value)));end loop;
  target:=1;if front='1' then target:=0;end if;
  write_reg(14,target);write_reg(18,trial);write_reg(19,255-trial);write_reg(22,trial mod 2);
  write_reg(16,1);
  if trial<24 then
   -- Registers remain writable while the captured camera is rendering.
   for i in 0 to 13 loop write_reg(i,trial*17+i*29);end loop;
   write_reg(16,1); -- duplicate START while busy
   commit<='1';cb<=front;wait until falling_edge(clk);commit<='0';
   if trial mod 8=7 then
    reset_dsp;assert busy='0' and ready='0' and active='0' severity failure;
   else
    if ready/='1' then wait until ready='1' for 12 ms;end if;
    assert ready='1' and err='1' report "Stress completion" severity failure;
    wait for 70 us;write_reg(16,1); -- START while ready
    cb<=front;commit<='1';wait until falling_edge(clk);commit<='0';wait for 80 ns;assert ready='1' severity failure;
    if target=1 then cb<='1';else cb<='0';end if;
    commit<='1';wait until falling_edge(clk);commit<='0';wait for 80 ns;
    assert ready='0' and active='1' report "Stress commit" severity failure;
   end if;
  else
   wait for 1 us;assert busy='0' and ready='0' and err='1' report "Invalid camera accepted" severity failure;
  end if;
 end loop;
 reset_dsp;write_reg(14,2);write_reg(16,1);wait for 80 ns;assert busy='0' and err='1' severity failure;
 report "ALL STRESS TESTS PASSED DSP";stop;wait;
end process;end;'''.replace('CASES',str(len(cameras)))
    run(out,src,'tb_dsp_stress',source,['serial_math','mode7_dsp']);return len(cameras)

def main():
    p=argparse.ArgumentParser();p.add_argument('--variant',type=Path,required=True);p.add_argument('--out',type=Path,required=True);a=p.parse_args()
    out=a.out.resolve();out.mkdir(parents=True,exist_ok=True);src=a.variant.resolve()/'src'
    n=math_test(out,src);special=math_test(out,src,True) if 'POSITIVE_DIVISOR' in (src/'serial_math.vhd').read_text() else 0;c=dsp_test(out,src)
    report=dict(status='pass',reference_commit=REVISION,arithmetic_cases=n,specialized_arithmetic_cases=special,dsp_cameras=c,cycle_equivalence='pass',
                busy_start=True,ready_start=True,live_register_writes=True,invalid_camera=True,wrong_commit=True,mid_frame_reset=True,
                sources={f.name:hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(src.glob('*.vhd'))},hardware_tested=False)
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))

if __name__=='__main__':main()
