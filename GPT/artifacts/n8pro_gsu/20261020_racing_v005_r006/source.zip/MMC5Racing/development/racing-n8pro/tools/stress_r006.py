"""配布版とは別に20景物の負荷を測る。旧・新GSUは同じメッシュと配置を使う。"""
import argparse, hashlib, json, struct, subprocess
from pathlib import Path
from build import HERE, lab
from optimize_r006 import ROOT, REVISION


def main():
    p=argparse.ArgumentParser()
    for name in ['base','fixture','project','cc65','cases']:
        p.add_argument('--'+name,type=Path,required=True)
    a=p.parse_args();out=ROOT/'stress-20';out.mkdir(parents=True,exist_ok=True)
    base=a.base.read_bytes();fixture=a.fixture.read_bytes()
    sha=lambda b:hashlib.sha256(b).hexdigest()
    assert sha(base)=='d5b6016be1127c47ba2d654d09befcb1be61f8c3a6cd532a63cb76c9051fd725'
    assert sha(fixture)=='6d107849212255baf59babac8f0165e3a5b56c9bb63ad3b6c195757af4f38b69'
    for start,end in [(0x100,0x400),(0xc00,0xd00)]:
        assert base[8208+start:8208+end]==fixture[8208+start:8208+end]
    roms={}
    for name in ['r005','r006']:
        folder=out/name;folder.mkdir(exist_ok=True)
        for file in ['gsu.s','scenery.inc','planes.inc','gsu.cfg']:
            data=subprocess.check_output(['git','show',REVISION+':development/racing-n8pro/gsu/'+file],cwd=lab.ROOT) if name=='r005' else (HERE/'gsu'/file).read_bytes()
            (folder/file).write_bytes(data)
        s=(folder/'gsu.s').read_text();(folder/'gsu.s').write_text('SCENERY_TREES=16\nSCENERY_HOUSES=4\n'+s)
        subprocess.run([a.cc65/'ca65.exe','-g','-I',a.project/'.cache/casfx','-I',folder,folder/'gsu.s','-o',folder/'gsu.o'],check=True)
        subprocess.run([a.cc65/'ld65.exe','-C',folder/'gsu.cfg',folder/'gsu.o','-o',folder/'gsu.bin'],check=True)
        rom=bytearray(base);code=(folder/'gsu.bin').read_bytes();assert len(code)==4096
        for bank in [1,2]:
            pos=16+bank*8192
            rom[pos+0x100:pos+0x1000]=fixture[pos+0x100:pos+0x1000]
            rom[pos+4096:pos+8192]=code
        roms[name]=rom;(out/(name+'.nes')).write_bytes(rom)
    rows=json.loads(a.cases.read_text())['all'];probe=a.project/'build/r004-core-calibrated/racing_profile.exe'
    memory=bytearray(40960);results=[]
    for i,row in enumerate(rows):
        samples=[]
        for name,rom in roms.items():
            memory[:32768]=bytes(32768);memory[32768:]=rom[8208:16400];memory[0x8004:0x8006]=b'\x00\x40'
            struct.pack_into('<11h',memory,0x8008,*row['pose']);(out/'input.bin').write_bytes(memory)
            clocks=int(subprocess.check_output([probe,out/'input.bin',out/name,'fast'],text=True))
            samples.append((clocks,(out/(name+'.frame')).read_bytes()))
        assert samples[0][1]==samples[1][1],row['name']
        results.append(dict(row,before=samples[0][0],after=samples[1][0]))
        if (i+1)%128==0:print(i+1,len(rows),flush=True)
    selected=sorted(results,key=lambda r:-r['after'])[:8]
    (out/'selected.json').write_text(json.dumps(selected,indent=2)+'\n')
    report=dict(status='pass',trees=16,houses=4,identical_frames=len(rows),base_sha256=sha(base),fixture_sha256=sha(fixture),
                r005_sha256=sha(roms['r005']),rom_sha256=sha(roms['r006']),probe_sha256=sha(probe.read_bytes()),
                saving_percent=100*(1-sum(r['after'] for r in results)/sum(r['before'] for r in results)),
                max_before_ms=max(r['before'] for r in results)/25000,max_after_ms=max(r['after'] for r in results)/25000,
                scope='20-scenery stress fixture, not the 13-scenery release; native model, not whole-system fps',all=results)
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='all'}))


if __name__=='__main__':main()
