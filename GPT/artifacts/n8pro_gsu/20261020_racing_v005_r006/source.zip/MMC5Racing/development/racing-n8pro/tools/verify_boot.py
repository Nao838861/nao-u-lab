"""実 v005 の 6502 初期化/NMI を実行し、その外部バス操作を最上位 RTL に再生する。

命令フェッチを一部省く機能検証。CPU/PPU 全体のサイクル精密な実機再現ではない。
"""
import argparse,hashlib,json,struct,subprocess,sys
from pathlib import Path
HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE.parent/'superfx-lab/tools'))
import lab
from build import source_hashes
sys.path.insert(0,str(lab.ROOT/'tools/python'))
from py65.devices.mpu6502 import MPU

class Bus:
    def __init__(self,rom):
        self.prg=rom[16:16+1048576];self.wram=bytearray(131072);self.ram=bytearray(2048);self.fx=bytearray(40960)
        self.reg={};self.banks=[0,0x80,0x80,0xfe,0x80];self.window=0;self.page=4;self.started=False;self.nmi=False;self.trace=[]
    def __getitem__(self,a):
        if a<8192:return self.ram[a&2047]
        if a==0x2002:return 128
        if a==0x4ff3:v=self.window
        elif 0x5113<=a<=0x5117:v=self.banks[a-0x5113]
        elif a in [0x5205,0x5206]:v=((self.reg.get(0x5205,0)*self.reg.get(0x5206,0))>>(8*(a-0x5205)))&255
        elif a==0x4fef:self.trace.append((2,a,0));return 2
        elif 0x6000<=a<0x8000 and self.window:v=self.fx[self.page*8192+(a&8191)]
        elif a>=0x6000:
            slot=(a>>13)-3;b=self.banks[slot]
            v=self.prg[(b&127)*8192+(a&8191)] if slot and (b&128 or slot==4) else self.wram[(b&15)*8192+(a&8191)]
        else:return 0
        # Main wrapper ROM fetches are already byte-identical to v005. Keep
        # data copies and original physics/audio fetches to exercise banking.
        if a<0xe000 or a>=0xfffa:self.trace.append((0,a,v))
        return v
    def __setitem__(self,a,v):
        v&=255
        if a<8192:self.ram[a&2047]=v;return
        if a==0x2000:self.nmi=bool(v&128)
        if a<0x4800:return
        self.trace.append((1,a,v))
        if 0x5113<=a<=0x5117:self.banks[a-0x5113]=v
        elif a==0x4ff3:self.window=v&1
        elif a==0x4fe1:self.page=v
        elif a==0x4ff0 and v==0xa5:self.window=0;self.page=4
        elif 0x6000<=a<0x8000 and self.window:self.fx[self.page*8192+(a&8191)]=v
        elif a>=0x6000:
            slot=(a>>13)-3;b=self.banks[slot]
            if not slot or (not b&128 and slot!=4):self.wram[(b&15)*8192+(a&8191)]=v
        elif a==0x481f:self.started=True
        else:self.reg[a]=v

def main():
    p=argparse.ArgumentParser();p.add_argument('--emulator-project',type=Path,required=True)
    p.add_argument('--rom',type=Path);p.add_argument('--out',type=Path)
    a=p.parse_args();project=a.emulator_project.resolve()
    out=(a.out or lab.ROOT/'build/racing-n8pro/boot-test').resolve();out.mkdir(parents=True,exist_ok=True)
    rom=(a.rom or project/'releases/GSU_MMC5Racing3D_v005.nes').read_bytes();bus=Bus(rom);cpu=MPU(memory=bus,pc=None);next_nmi=30000
    for steps in range(3000000):
        if bus.nmi and cpu.processorCycles>=next_nmi:cpu.nmi();next_nmi=cpu.processorCycles+30000
        cpu.step()
        if bus.started:break
    assert bus.started,hex(cpu.pc)
    print(f'6502 boot reached GO: {steps} instructions, {len(bus.trace)} external transactions',flush=True)
    (out/'trace.txt').write_text(''.join(f'{op} {addr:04X} {data:02X}\n' for op,addr,data in bus.trace))
    (out/'prg.hex').write_text(''.join(f'{b:02X}\n' for b in bus.prg))
    (out/'input.bin').write_bytes(bus.fx)
    subprocess.run([project/'build/racing/v003/racing_profile.exe',out/'input.bin',out/'native'],check=True,capture_output=True)
    (out/'expected.hex').write_text(''.join(f'{v:02X}\n' for v in (out/'native.frame').read_bytes()))
    template=(lab.LAB/'sim/tb_host_rom.vhd').read_text();header=template[:template.index('  process\n    type mem_t')]
    header=header.replace('tb_host_rom','tb_racing_boot').replace('n8pro_top','racing_top').replace('0 to 32767','0 to 1048575')
    header=header.replace('unsigned(prg_a(14 downto 0))','unsigned(prg_a(19 downto 0))')
    header=header.replace('sram_ce, sram_we, chr_we : std_logic;','sram_ce, sram_we, sram_oe, chr_we, chr_oe : std_logic;\n  signal chr_d : std_logic_vector(7 downto 0);\n  type ram_t is array(0 to 131071) of std_logic_vector(7 downto 0);\n  signal sram : ram_t := (others=>x"00");\n  type chr_t is array(0 to 262143) of std_logic_vector(7 downto 0);\n  signal chrram : chr_t := (others=>x"00");')
    header=header.replace('prg_d <= rom','prg_d <= rom').replace("else (others=>'Z');\n  board", "else sram(to_integer(unsigned(prg_a(16 downto 0)))) when sram_ce='1' and sram_oe='0' else (others=>'Z');\n  chr_d <= chrram(to_integer(unsigned(chr_a(17 downto 0)))) after 70 ns when chr_oe='0' else (others=>'Z');\n  process(sram_we) begin if rising_edge(sram_we) then sram(to_integer(unsigned(prg_a(16 downto 0))))<=prg_d;end if;end process;\n  process(chr_we) begin if rising_edge(chr_we) then chrram(to_integer(unsigned(chr_a(17 downto 0))))<=chr_d;end if;end process;\n  board")
    header=header.replace('chr_d=>x"00"','chr_d=>chr_d').replace('chr_oe=>open','chr_oe=>chr_oe').replace('sram_oe=>open','sram_oe=>sram_oe')
    source=header+'''  process
    file f:text open read_mode is "trace.txt";file expected:text open read_mode is "expected.hex";
    variable l:line;variable op:natural;variable a:std_logic_vector(15 downto 0);variable d,v:std_logic_vector(7 downto 0);
    variable count:natural:=0;variable done:boolean;
    procedure cycle(addr:natural;data:std_logic_vector(7 downto 0);writing:boolean;variable q:out std_logic_vector(7 downto 0)) is
    begin
      m2<='0';full_addr<=addr;drive_data<=data;if writing then rw<='0';else rw<='1';end if;
      wait for 210 ns;m2<='1';wait for 300 ns;q:=cpu_d;wait for 50 ns;m2<='0';wait for 1 ns;
    end;
  begin
    wait for 1 us;
    while not endfile(f) loop
      readline(f,l);read(l,op);hread(l,a);hread(l,d);
      if op=2 then
        done:=false;
        for i in 0 to 4000 loop cycle(to_integer(unsigned(a)),x"00",false,v);if v(0)='0' then done:=true;exit;end if;end loop;
        assert done report "fill timeout" severity failure;
      else
        cycle(to_integer(unsigned(a)),d,op=1,v);
        if op=0 then assert v=d report "CPU read mismatch " & to_hstring(a) & " expected " & to_hstring(d) & " got " & to_hstring(v) & " transaction " & integer'image(count) severity failure;end if;
      end if;
      count:=count+1;
    end loop;
    report "BOOT TRACE PASSED " & integer'image(count);
    done:=false;
    for i in 0 to 200000 loop cycle(16#4830#,x"00",false,v);if v(5)='0' then done:=true;exit;end if;end loop;
    assert done report "GSU timeout" severity failure;
    done:=false;
    for i in 0 to 20000 loop cycle(16#4FB0#,x"00",false,v);if v(1)='1' then done:=true;exit;end if;end loop;
    assert done and v(2)='0' report "DSP/copy timeout" severity failure;
    for i in 0 to 16383 loop readline(expected,l);hread(l,d);assert chrram(16#24000#+i)=d report "external frame mismatch " & integer'image(i) & " got " & to_hstring(chrram(16#24000#+i)) & " expected " & to_hstring(d) severity failure;end loop;
    cycle(16#4FE2#,x"01",true,v);cycle(16#4FB0#,x"00",false,v);
    assert v=x"08" report "DSP/front commit failed" severity failure;
    cycle(16#4FE2#,x"00",false,v);assert v=x"01" severity failure;
    report "ALL BOOT AND EXTERNAL FRAME TESTS PASSED";stop;wait;
  end process;
end;'''
    (out/'tb_boot.vhd').write_text(source);ghdl=lab.ghdl_path()
    sources=[lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',*[HERE/'rtl'/s for s in ['serial_math.vhd','mode7_dsp.vhd','racing_gsu.vhd','racing_display.vhd','racing_top.vhd']],out/'tb_boot.vhd']
    lab.run([ghdl,'-a','--std=08',*sources],cwd=out)
    with (out/'simulation.log').open('w') as log:
        r=subprocess.run([ghdl,'-r','--std=08','tb_racing_boot','--assert-level=error','--ieee-asserts=disable-at-0'],cwd=out,stdout=log,stderr=subprocess.STDOUT)
    print((out/'simulation.log').read_text());r.check_returncode()
    assert 'ALL BOOT AND EXTERNAL FRAME TESTS PASSED' in (out/'simulation.log').read_text()
    (out/'verification.json').write_text(json.dumps({'status':'pass','sources':source_hashes(),'instructions':steps+1,'transactions':len(bus.trace),'frame_bytes':16384,'source_rom_sha256':hashlib.sha256(rom).hexdigest(),'hardware_tested':False,'scope':'functional boot/NMI external bus trace, GSU, DSP and framebuffer DMA; not cycle-exact 6502/PPU emulation'},indent=2)+'\n')

if __name__=='__main__':main()
