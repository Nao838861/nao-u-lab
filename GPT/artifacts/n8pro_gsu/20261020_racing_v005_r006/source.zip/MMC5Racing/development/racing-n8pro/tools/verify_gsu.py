"""v005 の実 GSU プログラムを圧縮描画 RAM 上で実行して全画素を比較する。"""
import argparse, hashlib, json, re, struct, subprocess, sys
from pathlib import Path

HERE=Path(__file__).resolve().parents[1]
LAB=HERE.parent/'superfx-lab'
sys.path.insert(0,str(LAB/'tools'))
import lab
from build import source_hashes

def main():
    p=argparse.ArgumentParser();p.add_argument('--emulator-project',type=Path,required=True)
    p.add_argument('--cases',type=int,default=4)
    p.add_argument('--rom',type=Path)
    p.add_argument('--out',type=Path)
    p.add_argument('--poses',type=Path,help='JSON array of named camera poses')
    p.add_argument('--poll-limit',type=int,default=250000,help='Increase only for intentionally overloaded stress scenes')
    a=p.parse_args();project=a.emulator_project.resolve()
    out=(a.out or lab.ROOT/'build/racing-n8pro/gsu-test').resolve();out.mkdir(parents=True,exist_ok=True)
    rom=(a.rom or project/'releases/GSU_MMC5Racing3D_v005.nes').read_bytes()
    if not a.rom:assert hashlib.sha256(rom).hexdigest()=='cb62bb356af4c86632ea061c7f1132b36f6d0502ff8de4bdf8a804802aa41a75'
    assert len(rom)==2105360 and rom[:4]==b'NES\x1a'
    poses=json.loads(a.poses.read_text()) if a.poses else None
    if poses:a.cases=len(poses)
    probe=project/'build/racing/v003/racing_profile.exe'
    inputs=bytearray();expected=bytearray();clocks=[]
    for case in range(a.cases):
        data=bytearray((project/f'build/racing/v005/initial-test/snapshot{case%4}.bin').read_bytes())
        data[:32768]=bytes(32768);data[32768:]=rom[8208:16400]
        snapshot=(project/f'build/racing/v005/initial-test/snapshot{case%4}.bin').read_bytes()
        data[0x8000:0x801e]=snapshot[0x8000:0x801e]
        data[0x8004:0x8006]=b'\x00\x40'
        if poses:struct.pack_into('<11h',data,0x8008,*poses[case]['pose'])
        (out/'input.bin').write_bytes(data)
        clocks.append(int(subprocess.check_output([probe,out/'input.bin',out/'native'],text=True)))
        frame=(out/'native.frame').read_bytes()
        assert len(frame)==16384
        inputs+=data[32768:];expected+=frame
    for name,data in [('input.hex',inputs),('expected.hex',expected)]:
        (out/name).write_text(''.join(f'{b:02X}\n' for b in data))
    header=(LAB/'sim/tb_nes_gsu.vhd').read_text().split('  begin\n    for i in prog')[0]
    header=header.replace('tb_nes_gsu','tb_racing_gsu').replace('  signal selected, irq_n : std_logic;', '''
  signal selected, irq_n, running, done_frame, reset_o, front : std_logic;
  signal mode : std_logic_vector(2 downto 0);
  signal copy_a : unsigned(13 downto 0) := (others=>'0');
  signal copy_q : std_logic_vector(7 downto 0);''')
    header=header.replace('dut : entity work.nes_gsu port map(clk,a,di,rw,m2,dout,selected,irq_n);',
        'dut : entity work.racing_gsu port map(clk,a,di,rw,m2,dout,selected,irq_n,running,done_frame,reset_o,front,mode,copy_a,copy_q);')
    header=header.replace('"program.hex"','"input.hex"').replace('    variable ln : line;',
        '    file expected : text open read_mode is "expected.hex";\n    variable ln : line;')
    header=header.replace('    variable done : boolean;', '    variable done : boolean;\n    variable measured_ticks : natural;')
    header+='''  begin
    wait for 1 us;
    for trial in 0 to CASES-1 loop
      wr(16#4FF0#,16#A5#);wait for 1 us;
      wr(16#4FE1#,4);wr(16#4FF3#,1);
      for i in 0 to 8191 loop
        readline(hex,ln);hread(ln,v);wr(16#6000#+i,to_integer(unsigned(v)));
      end loop;
      wr(16#4834#,16#70#);wr(16#4839#,1);wr(16#4837#,16#A0#);
      wr(16#483A#,16#18#);wr(16#4838#,16#10#);
      wr(16#4FE8#,0);wr(16#4FE9#,16#40#);wr(16#4FEA#,0);wr(16#4FEB#,16#40#);
      wr(16#4FEC#,0);wr(16#4FED#,0);wr(16#4FEE#,1);
      wait for 700 us;
      wr(16#481E#,0);wr(16#481F#,16#90#);
      done:=false;
      for poll in 0 to POLL_LIMIT loop
        bus_cycle(16#4830#,0,false,v);
        if v(5)='0' then done:=true;exit;end if;
      end loop;
      assert done report "GSU timeout" severity failure;
      report "GSU finished case " & integer'image(trial);
      measured_ticks:=0;
      for b in 0 to 3 loop
        bus_cycle(16#4FD0#+b,0,false,v);
        measured_ticks:=measured_ticks+to_integer(unsigned(v))*(256**b);
      end loop;
      report "GSU_TICKS " & integer'image(trial) & " " & integer'image(measured_ticks);
      for i in 0 to 16383 loop
        copy_a<=to_unsigned(i,14);wait for 100 ns;
        readline(expected,ln);hread(ln,v);
        assert copy_q=v report "frame mismatch at " & integer'image(i) & " expected " & to_hstring(v) & " got " & to_hstring(copy_q) severity failure;
      end loop;
      report "RACING FRAME PASS " & integer'image(trial);
    end loop;
    report "ALL RACING FRAMES PASSED";stop;wait;
  end process;
end;
'''.replace('CASES',str(a.cases)).replace('POLL_LIMIT',str(a.poll_limit))
    (out/'tb_racing_gsu.vhd').write_text(header)
    ghdl=lab.ghdl_path()
    lab.run([ghdl,'-a','--std=08',LAB/'rtl/dpram_difclk.vhd',LAB/'vendor/GSU_PKG.vhd',LAB/'vendor/GSU.vhd',HERE/'rtl/racing_gsu.vhd',out/'tb_racing_gsu.vhd'],cwd=out)
    with (out/'simulation.log').open('w') as log:
        result=subprocess.run([ghdl,'-r','--std=08','tb_racing_gsu','--assert-level=error','--ieee-asserts=disable-at-0','--stop-time=2sec'],cwd=out,stdout=log,stderr=subprocess.STDOUT)
    print((out/'simulation.log').read_text());result.check_returncode()
    assert 'ALL RACING FRAMES PASSED' in (out/'simulation.log').read_text()
    ticks=[int(value) for _,value in re.findall(r'GSU_TICKS (\d+) (\d+)',(out/'simulation.log').read_text())]
    assert len(ticks)==a.cases and all(ticks)
    report={'status':'pass','sources':source_hashes(),'rom_sha256':hashlib.sha256(rom).hexdigest(),'cases':a.cases,'bytes_compared':len(expected),'native_50mhz_clocks':clocks,
        'rtl_clock_hz':25000000,'rtl_clocks':ticks,'rtl_ms':[round(t/25000,5) for t in ticks],
        'poses':poses,'test_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        'poll_limit':a.poll_limit,
        'scope':'GSU execution and compressed back RAM only; no PPU, external memory or hardware validation'}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')

if __name__=='__main__':main()
