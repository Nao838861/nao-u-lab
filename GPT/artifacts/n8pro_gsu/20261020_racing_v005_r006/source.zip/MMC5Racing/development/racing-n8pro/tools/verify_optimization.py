"""旧版と最適化版の全画素を比較し、コース全周・接近・描画反復を計測する。"""
import argparse
import json
import struct
import subprocess
import sys
from pathlib import Path
from optimize_rom import OUT, SOURCE_HASH, assemble, digest, patch_rom


def prepare_rtl_inputs(original, report):
    poses=[{'name':r['name'],'pose':r['pose']} for r in report['initial']+report['worst']]
    (OUT/'poses.json').write_text(json.dumps(poses,indent=2)+'\n')
    (OUT/'stress-poses.json').write_text(json.dumps([poses[-1]],indent=2)+'\n')
    for repeat in [2,4]:
        for name in ['baseline','optimized']:
            folder=OUT/f'stress-{repeat}-{name}'
            (folder/'stress.nes').write_bytes(patch_rom(original,(folder/'gsu.bin').read_bytes()))


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--emulator-project', type=Path, required=True)
    parser.add_argument('--cc65-bin', type=Path, required=True)
    args = parser.parse_args()
    project = args.emulator_project.resolve()
    sys.path.insert(0, str(project/'tools'))
    from verify_racing_scenery import cases
    from build_ground import VIEWS
    import mmc5_state
    original = (project/'releases/GSU_MMC5Racing3D_v005.nes').read_bytes()
    assert digest(original) == SOURCE_HASH
    optimized = (OUT/'GSU_MMC5Racing3D_v005_opt_r002.nes').read_bytes()
    probe = project/'build/racing/v003/racing_profile.exe'
    out = OUT/'comparison'
    out.mkdir(exist_ok=True)
    data = bytearray(40960)
    data[32768:] = original[8208:16400]
    # Always render into the non-displayed bank, matching the hardware test.
    data[0x8004:0x8006] = b'\x00\x40'
    optimized_code = optimized[12304:16400]
    baseline_code = original[12304:16400]
    rows = cases()
    for view in range(4):
        snap = (project/f'build/racing/v005/initial-test/snapshot{view}.bin').read_bytes()
        rows.insert(view, dict(name=f'initial-{view}', view=view, pose=list(struct.unpack_from('<11h', snap, 0x8008))))
    def run(code, tag):
        data[0x9000:] = code
        (out/'input.bin').write_bytes(data)
        clocks = int(subprocess.check_output([probe, out/'input.bin', out/tag], text=True))
        return clocks, (out/(tag+'.frame')).read_bytes()
    results = []
    for i, row in enumerate(rows):
        pose = row.get('pose') or mmc5_state.pose(bytes(row['state'])+bytes(2), VIEWS[row['view']])
        struct.pack_into('<11h', data, 0x8008, *pose)
        before, expected = run(baseline_code, 'baseline')
        after, actual = run(optimized_code, 'optimized')
        assert actual == expected, ('framebuffer mismatch', row['name'])
        results.append(dict(row, pose=list(pose), before_clocks=before, after_clocks=after,
                            savings_percent=round((1-after/before)*100, 3)))
        if (i+1) % 128 == 0:
            print(f'Compared {i+1}/{len(rows)}', flush=True)
    # Repeated complete scenery passes increase polygons/overdraw while retaining
    # the exact reference image. This is a synthetic stress test, not new scenery.
    stresses = []
    selected = [max((r for r in results if r['view']==v), key=lambda r:r['before_clocks']) for v in range(4)]
    for repeat in [2, 4]:
        codes = [assemble(project, args.cc65_bin.resolve(), OUT/f'stress-{repeat}-{name}', baseline=base, repeats=repeat)
                 for name, base in [('baseline', True), ('optimized', False)]]
        for row in selected:
            struct.pack_into('<11h', data, 0x8008, *row['pose'])
            before, expected = run(codes[0], 'baseline')
            after, actual = run(codes[1], 'optimized')
            assert actual == expected, ('stress framebuffer mismatch', repeat, row['name'])
            stresses.append(dict(row, repeats=repeat, before_clocks=before, after_clocks=after,
                                 savings_percent=round((1-after/before)*100, 3)))
    report = dict(status='pass', source_rom_sha256=SOURCE_HASH, rom_sha256=digest(optimized),
                  probe_sha256=digest(probe.read_bytes()), model_clock_hz=50000000,
                  scope='Native Mesen instruction model, not FPGA timing or measured hardware FPS',
                  identical_frames=len(results)+len(stresses), framebuffer_bytes=16384,
                  aggregate_savings_percent=round((1-sum(r['after_clocks'] for r in results)/sum(r['before_clocks'] for r in results))*100, 3),
                  min_savings_percent=min(r['savings_percent'] for r in results),
                  initial=results[:4], worst=selected, stress=stresses, all=results)
    (out/'verification.json').write_text(json.dumps(report, indent=2)+'\n')
    prepare_rtl_inputs(original, report)
    print(json.dumps({k:v for k,v in report.items() if k not in ['all','initial','worst','stress']}, indent=2))


if __name__ == '__main__':
    main()
