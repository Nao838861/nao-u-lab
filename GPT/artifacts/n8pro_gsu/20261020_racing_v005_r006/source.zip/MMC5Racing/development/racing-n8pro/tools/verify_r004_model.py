"""RTL実測に対するMesen時間モデルの余裕を、同じROM・姿勢で記録する。"""
import argparse,hashlib,json,struct,subprocess
from pathlib import Path

def main():
    p=argparse.ArgumentParser();p.add_argument('--rom',type=Path,required=True)
    p.add_argument('--rtl',type=Path,required=True);p.add_argument('--probe',type=Path,required=True)
    p.add_argument('--out',type=Path,required=True);a=p.parse_args();a.out.mkdir(parents=True,exist_ok=True)
    rom=a.rom.read_bytes();report=json.loads(a.rtl.read_text());digest=lambda b:hashlib.sha256(b).hexdigest()
    assert report['status']=='pass' and report['rom_sha256']==digest(rom)
    rows=[];data=bytearray(40960);data[32768:]=rom[8208:16400];data[0x8004:0x8006]=b'\x00\x40'
    for pose,rtl in zip(report['poses'],report['rtl_clocks']):
        data[:32768]=bytes(32768);struct.pack_into('<11h',data,0x8008,*pose['pose'])
        inp=a.out/'input.bin';inp.write_bytes(data)
        model=int(subprocess.check_output([a.probe,inp,a.out/'model','fast'],text=True))
        rows.append(dict(name=pose['name'],rtl_clocks=rtl,model_clocks=model,model_margin_percent=100*(model/rtl-1)))
    result=dict(status='pass' if all(r['model_clocks']>=r['rtl_clocks'] for r in rows) else 'optimistic',
                rom_sha256=digest(rom),probe_sha256=digest(a.probe.read_bytes()),cases=rows,
                scope='Selected poses only; not a general cycle-accuracy guarantee or hardware timing signoff')
    (a.out/'verification.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
    assert result['status']=='pass'

if __name__=='__main__':main()
