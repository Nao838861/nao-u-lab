# ファミコン用 GSU マッパー実験環境

EverDrive N8 Pro の FPGA に SuperFX 系 GSU の命令コアを載せ、ファミコンの CPU から制御する試作です。**2026年10月17日、Quartus Prime Lite 24.1で合成・配置配線が成功し、gsu.rbfを生成しました。内部クロックのタイミング条件は合格。外部CPU/PPU/PSRAMバスのタイミングと実機動作は未確認です。まだ「N8 ProでSuperFX2が動いた」とは結論していません。**

今回の測定はEP4CE6F17C8で3,036／6,272 LE、RAM 69,632／276,480 bit、9bit乗算器4／30。内部setup最小余裕6.851ns、hold最小余裕0.184ns。外部入力57・外部出力53ポートには遅延制約がなく、実機の速度保証には使いません。詳細は [生成・検証記録](results/verification_20261017.json)。

GSU診断のRTL試験に加え、初期ワイヤーフレーム立方体ROMのGSUコードをRTLで64姿勢実行し、512頂点と133,120バイトの描画RAM／座標を参照計算と照合しました。立方体のPPU表示・実機確認は未実施です。面塗り版・3D走行版の追加回路はこのRBFには含みません。

現段階は命令キャッシュから小さなプログラムを走らせる起動試験です。SuperFX2の全メモリー構成やクロック互換性、ゲーム用の画面供給回路は未実装です。現行MMC5RacingのROM・フレーム契約は変更しません。

実機テスト用カートリッジは、ユーザー指定の **EverDrive N8 Pro** に確定しました。本体の種類は未確認です。

エミュレーター開発を別スレッドで先行する場合は [引き継ぎ資料](EMULATOR_HANDOFF.md) を入口にしてください。現行ABI、診断ROMの期待値、選択方法、実機との検証範囲の違いをまとめています。

## N8 と N8 Pro の判定

| 対象 | 確認した根拠 | 現在の判定 |
|---|---|---|
| N8 Pro | メーカー公開のマッパーソース、EP4CE6F17C8用のピン配置、OS 2.15以降の同一フォルダーRBF読み込み、USB起動手順 | GSUを組み込む開発経路がある。本環境の第一対象。動作可否の確定にはQuartusのFitと実機試験が必要 |
| 旧N8 | メーカー公開の開発サンプルはCyclone II EP2C5T144C8用 | 独自マッパーの開発経路はあるが、GSUの収まり・ボード接続は未検証。本環境のRBFは使用不可 |

N8 Pro用のメーカーQSFはEP4CE6を指定します。このデバイスの規模は6,272 LE、270 Kbitの内蔵RAMです。GSUのレジスター選択回路などの費用は合成結果で確かめる必要があり、ソースの行数やRAM容量だけでは実装可能とは言えません。

既存N8に物理的なSuperFX2 ICを追加する改造は今回の設計に含みません。ここではGSUをFPGA内の回路として再実装します。通常のNES ROMをSDへコピーするだけではGSUは追加されません。

## 作成したもの

- MiSTer SNESの既存GSUコアを固定revisionで収録。r004の内蔵RAM専用拡張は [vendor/SOURCES.md](vendor/SOURCES.md) に記録（この診断回路では無効）。
- NES CPU用のレジスター／512バイト命令キャッシュ窓、8 KiBの揮発RAM、ソフトリセット。
- N8 ProのNROM相当PRG/CHR接続とGSU窓を持つトップ回路。ピン配置はメーカー公開QSFから生成。
- 6502がGSUへ命令列をアップロードし、加算・乗算・RAM書き込み・PLOTの結果を比較する40,976バイトのテストROM。
- GHDLによるコア試験、テストROMを実行する簡易6502モデルとボードRTLの接続試験、Mesenでのマッパー不在試験。
- Quartusプロジェクト生成、RBF生成、SD用フォルダー作成、メーカーUSBツールによる起動コマンド。

## このPCで確認した結果

2026年10月13日に、`python development/superfx-lab/tools/lab.py check` が成功しました。

| 試験 | 結果 |
|---|---|
| 同じROMから抽出したGSU命令列を実行 | 成功 |
| `$1234 + $0102 = $1336`、`7 × 9 = 63` | 成功 |
| RAMへの16ビット書き込み | 成功 |
| 色3で8ピクセルをPLOTし、RPIXでflush、2bppの2バイトがともにFF | 成功 |
| リセット・キャッシュ再アップロード、非同期M2の異なる位相4回 | 成功 |
| 加算の16ビット桁あふれ、符号付き `-7 × 9 = -63` | 成功 |
| 簡易6502モデルで実ROMを実行し、N8 ProトップRTL経由で緑背景・結果0へ到達 | 成功 |
| 同モデルでID不一致を注入し、赤背景・結果1へ到達 | 成功 |
| 通常のMesenで独自マッパーなしのROMを起動 | 赤背景・結果1を確認 |
| Quartus合成・Fit・TimeQuest | `quartus_sh`が見つからず未実施 |
| 実機 | N8 Proとの接続・SDでの起動とも未確認。未実施 |

簡易6502モデルは本ROMが使う命令だけを扱い、PPUのvblank状態を固定しています。サイクル精密なファミコンエミュレーターではありません。通常のMesenはこのGSUマッパーを実装していないため、成功経路の確認には使えません。

検証時ROMのSHA256は `591424840eba9fc62f7e7d28f2abb90b672f6e074bf5b1ec5baf7e52ab18e837` です。生成物はリポジトリの `build/superfx-lab/` に置きます。

固定した検証記録は [results/verification.json](results/verification.json)、通常のMesenでの不在表示は [画面](results/missing-mapper.png) です。

N8 Pro指定後の導入準備とGHDL 5.1.1での再試験は [2026年10月14日の記録](results/verification_20261014.json) を参照してください。

## 再現手順

MMC5Racingのルートで実行します。Python 3.10以降とcc65の`ca65`・`ld65`を使います。既存の同梱ツールまたはPATHから検索します。

```powershell
# メーカーのピン配置・USBツールを固定revisionで取得
python development/superfx-lab/tools/lab.py fetch

# Windows用GHDL 5.1.1をbuild配下へ展開。ZIPのSHA256を照合する
python development/superfx-lab/tools/lab.py install-ghdl

# ROM生成、RTL試験、ROMとボードの接続試験、Quartusプロジェクト生成
python development/superfx-lab/tools/lab.py check

# オプション：Mesenで「GSU不在」の画面を確認する
python development/superfx-lab/tools/lab.py mesen-negative --mesen D:\HomeBrew\Mesen\Mesen.exe
```

GHDLを別途導入済みなら、`check --ghdl <ghdl.exeのパス>`を使えます。GHDLの自動展開先はこの実験のbuild配下で、システムへのインストールやPATHの変更は行いません。

GHDL 6.0.0では、ROMとボードの接続試験中に一度 `NULL access dereferenced` が発生しました。再実行は成功しましたが、再現用の取得版を5.1.1へ固定し、同じ接続試験を10回連続で通しました。原因の確定や、5.1.1で同種の問題が起きないことの保証まではしていません。以前に用意した6.0.0のディレクトリは保存したままです。

## RBFを生成する

このPCではQuartus Prime Lite 24.1とCyclone IVデータを `C:\altera_lite\24.1std` に導入済みです。以下は未導入環境向けの手順です。[公式配布ページ](https://www.altera.com/downloads/fpga-development-tools/quartus-prime-lite-edition-design-software-version-24-1-windows)から、次の2ファイルを同じフォルダーへ保存します。約2.4 GBのダウンロードです。Programmer単体では合成できないため、Quartus本体を取得します。

- `QuartusLiteSetup-24.1std.0.1077-windows.exe`
- `cyclone-24.1std.0.1077.qdz`

既定の保存先は `build/superfx-deps/quartus-downloads/` です。別のフォルダーなら `-DownloadDirectory` で指定できます。公式ページがログインを要求するため、認証前のHTTP取得だけでは準備できません。ブラウザーでの取得と利用規約の確認をユーザー側で行う手順です。

```powershell
# 公式掲載SHA1と照合する。既定動作ではインストーラーを実行しない
powershell -NoProfile -ExecutionPolicy Bypass -File development/superfx-lab/tools/setup_quartus.ps1

# 規約を確認・同意した場合に、ユーザーが明示して導入する
powershell -NoProfile -ExecutionPolicy Bypass -File development/superfx-lab/tools/setup_quartus.ps1 -Install -AcceptEula

# ツールとシリアルポート登録を確認する。N8 Proを操作しない
python development/superfx-lab/tools/lab.py doctor

# 新規導入先を自動検出して合成・配置配線・RBF生成を行う
python development/superfx-lab/tools/lab.py quartus
```

既定の導入先は `%LOCALAPPDATA%/N8ProTools/24.1` です。導入スクリプトは、2ファイルのハッシュ照合を終え、`-Install`と`-AcceptEula`の両方が明示された場合にだけ実行します。導入時のSHA256もbuild配下のmanifestへ保存します。システムのPATHを変更せず、USB/JTAGの操作も行いません。

Quartusを別の場所へ導入済みなら、実行ファイルを直接指定できます。

```powershell
python development/superfx-lab/tools/lab.py quartus --quartus-sh C:\intelFPGA_lite\24.1std\quartus\bin64\quartus_sh.exe
```

生成先は `build/superfx-lab/quartus/gsu.qpf` と `output_files/gsu.rbf` です。`quartus.log`、Fitレポート、TimeQuestを確認してください。LE／RAM／乗算器がデバイスに収まり、内部クロックのsetup/holdを満たすことが最初の判定です。外部バスの制約は初期段階なので、CPU/PPU/PSRAMの非制約経路が残ることを無視して実機のタイミング保証に広げないでください。

`package`は、合成成功時のソースとRBFのハッシュが一致する時だけ動きます。RBF未生成の環境では明示的なエラーで止まります。

`doctor`のシリアルポート一覧はWindowsの登録情報です。Bluetooth仮想ポートや古い登録が含まれ得るため、N8 Proの接続確認には代用しません。SD経由の実機テストにはCOMポートは必要ありません。

### 初期立方体のRTL照合

エミュレーター側プロジェクトで `python tools/build_cube.py` を実行した後、こちらのルートから次を実行します。

```powershell
python development/superfx-lab/tools/verify_cube_rtl.py --emulator-project <nes_superfxフォルダー>
```

配布済み立方体ROMのSHA256を固定し、ROMに含まれるコード・モデル・回転行列をRTLへ渡します。結果は `build/superfx-lab/cube-rtl/`。描画RAMと投影座標の照合であり、PPUや実機の成功とは区別します。

## N8 Proで実機テストする

1. N8 ProのOSを2.15以降にする。NES/Famicomの電源を切った状態でSDを扱う。
2. 上のRTL試験とQuartusビルドを完了する。
3. `python development/superfx-lab/tools/lab.py package`を実行する。
4. `build/superfx-lab/sdcard/GSU-LAB/`をSDへコピーする。この専用フォルダーにはテストROMと`gsu.rbf`を一組だけ置く。
5. 実機でROMを選択する。スタンドアロン回路なのでメニュー復帰やセーブステートを実装していない。読み込み直後に開始しなければ本体RESETを押す。メニューへ戻るには電源を入れ直す。
6. 緑背景の `GSU SELF TEST` と `0` を成功とする。赤背景の場合は下表で原因を切り分ける。
7. 本体型番、N8 Pro基板rev、OS版、ROM/RBFのSHA256、電源投入／RESETそれぞれの結果を記録する。同じROMの通常エミュレーター結果で実機成功を代用しない。

| 画面の番号 | 意味 |
|---|---|
| 0 | 加算、乗算、RAM書き込み、PLOTの比較がすべて一致 |
| 1 | カスタムマッパーのID／ABIを検出できない |
| 2 | GSUのバージョンレジスターが一致しない |
| 3 | GSUのGOが時間内に解除されない |
| 4 | 演算結果またはRAM書き込み結果が不一致 |
| 5 | PLOTの2bpp出力が不一致 |

USBを接続し、N8 Proのメニューが起動した状態なら、メーカーの`edlink run --file ... --fpga ...`を呼び出す次のコマンドも使えます。

```powershell
python development/superfx-lab/tools/lab.py upload
```

このマッパーはメーカーのメニュー／USB通信回路を含まないため、起動後の連続USB操作やメニュー復帰は保証しません。次の転送は電源を入れ直してメニューへ戻してから行います。

## MMC5Racingに適用する際の判断

現在のレース描画の制限は、6502の計算だけでなく、NT／ExRAMへの転送量と表示を閉じている期間にあります。GSUが計算を高速化しても、PPU転送を同じままにすれば縦の表示範囲が必ず広がるわけではありません。

次段階では、GSUの描画先をPPUが直接読める二重バッファーとして構成する案を検討します。GSUの2bpp出力とNESのビットプレーン配置をアドレス変換し、フレームが完成した時だけ表示側バンクを切り替えます。MMC5互換回路の併設はFitを測った後に判断します。具体的な配置と費用は [設計](DESIGN.md) に記載します。

## 参照元とライセンス

- [Krikzz N8 Pro開発ソース](https://github.com/krikzz/edn8-pro-pub)：ピン配置、RBF読み込み、USB起動の根拠。固定revision `317f8caf8d2b917a260e94ec14d5edbbbfced8ba`。
- [旧N8開発サンプル](https://krikzz.com/pub/support/everdrive-n8/original-series/development/)：`fpga-mapper-sample.zip`のQSFでCyclone II EP2C5を確認。
- [MiSTer SNES GSUソース](https://github.com/MiSTer-devel/SNES_MiSTer/tree/23026830ff8108fda0f32c0616296845f586b8ce/rtl/chip/GSU)：GSU本体・命令表。収録ファイルの出自は [vendor/SOURCES.md](vendor/SOURCES.md) を参照。
- [minimal_nrom](https://github.com/domgetter/minimal_nrom)：スタンドアロン回路の参考。最終ピン配置はメーカーQSFを使用。
- [Intel Cyclone IV Handbook](https://cdrdv2-public.intel.com/653974/cyclone4-handbook.pdf)：EP4CE6のリソース表。

本ディレクトリの新規コードはGPL-3.0-or-later、収録GSUを含む全体はGPL version 3として扱います。既存MMC5Racing全体のライセンスを変更しません。メーカーのUSBツールはGit管理に複製せず、必要時にメーカーのリポジトリから取得します。
