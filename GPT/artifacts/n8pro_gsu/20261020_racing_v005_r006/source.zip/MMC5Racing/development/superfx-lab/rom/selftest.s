; SPDX-License-Identifier: GPL-3.0-or-later
.setcpu "6502"
.macpack longbranch
.export gsu_program,gsu_program_end
.segment "HEADER"
.byte "NES",$1a,2,1,1,0 ; mapper 0 base, vertical mirroring, custom RBF required
.res 8,0
.segment "ZEROPAGE"
result: .res 1
limit: .res 2
.segment "CODE"
reset:
  sei
  cld
  ldx #$ff
  txs
  inx
  stx $2000
  stx $2001
  stx $4010
  lda #$40
  sta $4017
  lda #0
  sta $4015
  bit $2002
@v1: bit $2002
  bpl @v1
@v2: bit $2002
  bpl @v2
  lda #1
  sta result ; mapper missing
  lda $5ff1
  cmp #$53
  jne show_result
  lda $5ff2
  cmp #1
  jne show_result
  lda #$a5
  sta $5ff0
  ldx #0
@delay: dex
  bne @delay
  lda #2
  sta result ; GSU version/register failure
  lda $503b
  cmp #4
  jne show_result
  lda #0
  sta $5034 ; PBR, invalidates cache: MUST precede upload
  sta $5039 ; conservative speed (12.5 MHz)
  sta $5038 ; screen base 0
  sta $6000
  sta $6001
  sta $6200
  sta $6201
  lda #$80
  sta $5037 ; mask GSU interrupt
  lda #$18
  sta $503a ; ROM + RAM access, 2bpp, 128-line screen
  ldx #0
@upload:
  lda gsu_program,x
  sta $5100,x
  inx
  cpx #64
  bne @upload
  lda #0
  sta $501e
  sta limit
  sta limit+1
  sta $501f ; R15 high starts GSU
  nop
  nop
@poll:
  inc limit
  bne :+
  inc limit+1
  beq @timeout
: lda $5030
  and #$20
  bne @poll
  ; Return RAM ownership on a subsequent host access after STOP.
  lda $5030
  lda #4
  sta result ; arithmetic / store mismatch
  lda $500a ; R5: 7 * 9
  cmp #63
  bne show_result
  lda $500b
  bne show_result
  lda $6200 ; R2 was $1336 before PLOT used it as Y
  cmp #$36
  bne show_result
  lda $6201
  cmp #$13
  bne show_result
  lda #5
  sta result ; PLOT mismatch, first row two planes are FF
  lda $6000
  cmp #$ff
  bne show_result
  lda $6001
  cmp #$ff
  bne show_result
  lda #0
  sta result
  jmp show_result
@timeout:
  lda #3
  sta result
show_result:
  ; Forced blank, fixed CHR ROM. Diagnostic output does not depend on GSU.
  bit $2002
  lda #$20
  sta $2006
  lda #0
  sta $2006
  ldy #4
  ldx #0
@clear:
  lda #0
  sta $2007
  inx
  bne @clear
  dey
  bne @clear
  lda #$21
  sta $2006
  lda #$48
  sta $2006
  ldx #0
@title:
  lda title,x
  beq @status
  sta $2007
  inx
  bne @title
@status:
  lda #$21
  sta $2006
  lda #$88
  sta $2006
  lda result
  clc
  adc #$30
  sta $2007
  lda #$3f
  sta $2006
  lda #0
  sta $2006
  lda result
  beq @pass
  lda #$16 ; red for failure
  bne @palette
@pass:
  lda #$1a ; green for pass
@palette:
  sta $2007
  lda #$30
  sta $2007
  lda #$30
  sta $2007
  sta $2007
  lda #0
  sta $2000
  sta $2005
  sta $2005
  lda #$0a
  sta $2001
@idle: jmp @idle
nmi: rti
irq: rti
.segment "RODATA"
title: .byte "GSU SELF TEST",0
.include "program.inc"
.segment "VECTORS"
.addr nmi,reset,irq
.segment "CHR"
.incbin "font.chr"
