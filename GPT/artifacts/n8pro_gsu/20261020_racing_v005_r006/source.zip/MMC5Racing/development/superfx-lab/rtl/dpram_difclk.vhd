-- SPDX-License-Identifier: GPL-3.0-or-later
-- Portable replacement for the vendor-specific cache RAM primitive.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity dpram_difclk is
  generic (aw_a : positive := 9; dw_a : positive := 8;
           aw_b : positive := 9; dw_b : positive := 8);
  port (clock0, clock1 : in std_logic;
        address_a : in std_logic_vector(aw_a-1 downto 0);
        address_b : in std_logic_vector(aw_b-1 downto 0);
        data_a : in std_logic_vector(dw_a-1 downto 0);
        data_b : in std_logic_vector(dw_b-1 downto 0);
        wren_a, wren_b : in std_logic;
        q_a : out std_logic_vector(dw_a-1 downto 0);
        q_b : out std_logic_vector(dw_b-1 downto 0));
end;
architecture rtl of dpram_difclk is
  type mem_t is array (0 to 2**aw_b-1) of std_logic_vector(dw_b-1 downto 0);
  signal mem : mem_t;
  attribute ramstyle : string;
  attribute ramstyle of mem : signal is "M9K";
begin
  assert aw_a = aw_b and dw_a = dw_b severity failure;
  -- GSU port A is strictly read-only. Keeping one writer also permits
  -- portable simulation without shared variables or vendor libraries.
  assert wren_a /= '1' report "GSU cache port A must be read-only" severity failure;
  process(clock0) begin
    if rising_edge(clock0) then q_a <= mem(to_integer(unsigned(address_a))); end if;
  end process;
  process(clock1) begin
    if rising_edge(clock1) then
      if wren_b = '1' then mem(to_integer(unsigned(address_b))) <= data_b; end if;
      q_b <= mem(to_integer(unsigned(address_b)));
    end if;
  end process;
end;
