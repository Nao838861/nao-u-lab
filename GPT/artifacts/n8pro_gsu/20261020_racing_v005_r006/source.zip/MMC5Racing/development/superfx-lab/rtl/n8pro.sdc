create_clock -name clk50 -period 20.000 [get_ports {clk50}]
create_generated_clock -name clk25 -source [get_ports {clk50}] -divide_by 2 [get_registers {*clk25*}]
derive_clock_uncertainty
# M2 is sampled by clk25. Only the first synchronizer is asynchronous.
set_false_path -from [get_ports {m2}] -to [get_registers {*sync_m2[0]*}]
# First-stage lab constraints. CPU/PPU and PSRAM paths need board timing
# measurements before any claim of hardware validation or maximum clock.
# Do not blanket false-path the complete CPU/PPU buses.
