-- SPDX-License-Identifier: GPL-3.0-or-later
-- N8 Pro only: physical pin names follow domgetter/minimal_nrom.
library ieee;
use ieee.std_logic_1164.all;
entity n8pro_top is
  port (
    cpu_d : inout std_logic_vector(7 downto 0);
    cpu_a : in std_logic_vector(14 downto 0);
    cpu_romsel, cpu_rw, m2 : in std_logic;
    cpu_irq, cpu_dir, cpu_ex : out std_logic;
    ppu_d : out std_logic_vector(7 downto 0);
    ppu_a : in std_logic_vector(13 downto 0);
    ppu_rd, ppu_wr, ppu_a13n : in std_logic;
    ppu_ciram_ce, ppu_ciram_a10, ppu_dir, ppu_ex : out std_logic;
    prg_d : in std_logic_vector(7 downto 0);
    prg_a : out std_logic_vector(21 downto 0);
    prg_ce, prg_oe, prg_we, prg_ub, prg_lb : out std_logic;
    chr_d : in std_logic_vector(7 downto 0);
    chr_a : out std_logic_vector(21 downto 0);
    chr_ce, chr_oe, chr_we, chr_ub, chr_lb : out std_logic;
    sram_ce, sram_oe, sram_we, mcu_miso : out std_logic;
    mcu_mosi, mcu_clk, mcu_ss, clk50, fds_sw, mcu_busy : in std_logic;
    led, pwm, fifo_rxf, boot_on : out std_logic;
    gpio : inout std_logic_vector(3 downto 0);
    exp : inout std_logic_vector(9 downto 0);
    xio : out std_logic_vector(2 downto 0);
    rx : in std_logic; tx : out std_logic);
end;
architecture rtl of n8pro_top is
  signal clk25 : std_logic := '0';
  signal gsu_do : std_logic_vector(7 downto 0);
  signal gsu_sel, gsu_irq_n, drive_cpu, rom_read : std_logic;
begin
  process(clk50) begin
    if rising_edge(clk50) then clk25 <= not clk25; end if;
  end process;
  lab : entity work.nes_gsu port map (
    clk => clk25, cpu_a => not cpu_romsel & cpu_a, cpu_di => cpu_d,
    cpu_rw => cpu_rw, m2 => m2, cpu_do => gsu_do,
    selected => gsu_sel, running_irq_n => gsu_irq_n);
  rom_read <= not cpu_romsel and cpu_rw;
  drive_cpu <= m2 and cpu_rw and (not cpu_romsel or gsu_sel);
  cpu_dir <= drive_cpu;
  cpu_d <= prg_d when drive_cpu = '1' and rom_read = '1' else
           gsu_do when drive_cpu = '1' else (others => 'Z');
  -- Both PSRAM buses are read-only in this first-stage bring-up.
  prg_a <= "0000000" & cpu_a;
  prg_ce <= not rom_read; prg_oe <= not rom_read; prg_we <= '1';
  prg_lb <= '0'; prg_ub <= '1';
  chr_a <= "000000000" & ppu_a(12 downto 0);
  chr_ce <= ppu_a(13); chr_oe <= ppu_rd; chr_we <= '1';
  chr_lb <= '0'; chr_ub <= '1';
  ppu_d <= chr_d;
  ppu_dir <= not ppu_rd and not ppu_a(13);
  ppu_ciram_ce <= not ppu_a(13); ppu_ciram_a10 <= ppu_a(10);
  -- Never assert cartridge IRQ; software polls SFR instead.
  cpu_irq <= '1'; cpu_ex <= '0'; ppu_ex <= '0';
  sram_ce <= '0'; sram_oe <= '1'; sram_we <= '1';
  boot_on <= '0'; fifo_rxf <= '1'; pwm <= '0'; led <= not gsu_irq_n;
  mcu_miso <= 'Z'; tx <= 'Z';
  gpio <= (others => 'Z'); exp <= (others => 'Z'); xio <= (others => 'Z');
end;
