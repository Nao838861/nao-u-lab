-- SPDX-License-Identifier: GPL-3.0-or-later
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
entity nes_gsu is
  port (clk : in std_logic; -- 25 MHz board clock, GSU default execution 12.5 MHz
        cpu_a : in std_logic_vector(15 downto 0);
        cpu_di : in std_logic_vector(7 downto 0);
        cpu_rw, m2 : in std_logic;
        cpu_do : out std_logic_vector(7 downto 0);
        selected : out std_logic;
        running_irq_n : out std_logic);
end;
architecture rtl of nes_gsu is
  signal sync_m2 : std_logic_vector(1 downto 0) := "00";
  signal phase : integer range 0 to 7 := 0;
  signal strobe : std_logic;
  signal sel, reg_sel, ram_sel : std_logic;
  signal gsu_addr : std_logic_vector(23 downto 0);
  signal gsu_do, ram_di, ram_do : std_logic_vector(7 downto 0);
  signal ram_a : std_logic_vector(16 downto 0);
  signal ram_ce_n, ram_we_n : std_logic;
  signal rd_n, wr_n, reset_n : std_logic;
  signal reset_count : integer range 0 to 15 := 15;
  signal rom_a : std_logic_vector(20 downto 0);
  type ram_t is array (0 to 8191) of std_logic_vector(7 downto 0);
  signal ram : ram_t;
  attribute ramstyle : string;
  attribute ramstyle of ram : signal is "M9K";
begin
  reg_sel <= '1' when cpu_a >= x"5000" and cpu_a <= x"52FF" else '0';
  ram_sel <= '1' when cpu_a >= x"6000" and cpu_a <= x"7FFF" else '0';
  sel <= reg_sel or ram_sel;
  selected <= '1' when sel = '1' or (cpu_a >= x"5FF0" and cpu_a <= x"5FF2") else '0';
  -- The 6502 sees GSU registers/cache shifted by $2000. WRAM stays $6000.
  gsu_addr <= x"003" & cpu_a(11 downto 0) when reg_sel = '1' else
              x"00" & cpu_a when ram_sel = '1' else x"FFFFFF";
  cpu_do <= x"53" when cpu_a = x"5FF1" else
            x"01" when cpu_a = x"5FF2" else
            "0000000" & reset_n when cpu_a = x"5FF0" else gsu_do;
  -- One MMIO transaction per M2 high pulse, after address/data have settled.
  -- At 25 MHz, the pulse is about 160 ns after the physical M2 rising edge.
  strobe <= '1' when sync_m2(1) = '1' and phase = 2 else '0';
  rd_n <= not (sel and strobe and cpu_rw);
  wr_n <= not (sel and strobe and not cpu_rw);
  reset_n <= '1' when reset_count = 0 else '0';
  process(clk) begin
    if rising_edge(clk) then
      sync_m2 <= sync_m2(0) & m2;
      if sync_m2(1) = '0' then phase <= 0;
      elsif phase < 7 then phase <= phase + 1; end if;
      if strobe = '1' and cpu_rw = '0' and cpu_a = x"5FF0" and cpu_di = x"A5" then
        reset_count <= 15;
      elsif reset_count > 0 then reset_count <= reset_count - 1; end if;
      ram_di <= ram(to_integer(unsigned(ram_a(12 downto 0))));
      if ram_ce_n = '0' and ram_we_n = '0' and reset_n = '1' then
        ram(to_integer(unsigned(ram_a(12 downto 0)))) <= ram_do;
      end if;
    end if;
  end process;
  core : entity work.GSU port map (
    CLK => clk, RST_N => reset_n, ENABLE => '1', ADDR => gsu_addr,
    DI => cpu_di, DO => gsu_do, RD_N => rd_n, WR_N => wr_n,
    SYSCLKF_CE => strobe, SYSCLKR_CE => strobe,
    TURBO => '0', FASTROM => '0', IRQ_N => running_irq_n,
    ROM_A => rom_a, ROM_DI => x"00", ROM_RD_N => open,
    RAM_A => ram_a, RAM_DI => ram_di, RAM_DO => ram_do,
    RAM_WE_N => ram_we_n, RAM_CE_N => ram_ce_n,
    SS_BUSY => '0', SS_WR => '0', SS_DO => open,
    DBG_IN_CACHE => open, DBG_MC => open, DBG_GO_CNT => open);
end;
