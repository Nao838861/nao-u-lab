-- 通常の NROM エミュレーターで GSU 不在を正しく表示する検査。
local out=assert(os.getenv('GSU_LAB_QA'))
local frame=0
emu.addEventCallback(function()
  frame=frame+1
  if frame==120 then
    local result=emu.read(0,emu.memType.nesMemory)
    local f=assert(io.open(out..'/result.json','w'))
    f:write('{"result_code":'..result..',"gsu_emulated":false}\n');f:close()
    local image=assert(io.open(out..'/missing-mapper.png','wb'))
    image:write(emu.takeScreenshot());image:close()
    if result==1 then emu.stop(0) else emu.stop(1) end
  end
end,emu.eventType.endFrame)
