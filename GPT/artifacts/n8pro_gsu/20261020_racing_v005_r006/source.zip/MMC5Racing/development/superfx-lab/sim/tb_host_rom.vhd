-- SPDX-License-Identifier: GPL-3.0-or-later
-- Functional subset of 6502 sufficient to execute the actual diagnostic ROM.
-- Bus cycles are explicit; PPU status is stubbed. This is not a console emulator.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use std.env.all;
entity tb_host_rom is generic(mapper_present : boolean := true); end;
architecture test of tb_host_rom is
  type rom_t is array(0 to 32767) of std_logic_vector(7 downto 0);
  impure function load_rom return rom_t is
    file f : text open read_mode is "prg.hex";
    variable l : line; variable r : rom_t;
  begin
    for i in r'range loop readline(f,l); hread(l,r(i)); end loop;
    return r;
  end;
  constant rom : rom_t := load_rom;
  signal clk50 : std_logic := '0';
  signal cpu_a : std_logic_vector(14 downto 0) := (others=>'0');
  signal full_addr : natural range 0 to 65535 := 0;
  signal cpu_d, drive_data, prg_d : std_logic_vector(7 downto 0);
  signal rw, m2, ce, dir : std_logic := '1';
  signal prg_a, chr_a : std_logic_vector(21 downto 0);
  signal prg_ce, prg_oe, prg_we, sram_ce, sram_we, chr_we : std_logic;
  signal gpio : std_logic_vector(3 downto 0);
  signal exp : std_logic_vector(9 downto 0);
begin
  clk50 <= not clk50 after 10 ns;
  cpu_a <= std_logic_vector(to_unsigned(full_addr mod 32768,15));
  ce <= '0' when full_addr >= 32768 and m2 = '1' else '1';
  cpu_d <= drive_data when rw = '0' else (others=>'Z');
  prg_d <= rom(to_integer(unsigned(prg_a(14 downto 0)))) when prg_ce='0' and prg_oe='0' else (others=>'Z');
  board : entity work.n8pro_top port map (
    clk50=>clk50, cpu_a=>cpu_a, cpu_d=>cpu_d, cpu_rw=>rw, m2=>m2, cpu_romsel=>ce,
    cpu_dir=>dir, cpu_irq=>open, cpu_ex=>open,
    ppu_d=>open, ppu_a=>(others=>'0'), ppu_rd=>'1', ppu_wr=>'1', ppu_a13n=>'1',
    ppu_ciram_ce=>open, ppu_ciram_a10=>open, ppu_dir=>open, ppu_ex=>open,
    prg_d=>prg_d, prg_a=>prg_a, prg_ce=>prg_ce, prg_oe=>prg_oe, prg_we=>prg_we,
    prg_ub=>open, prg_lb=>open, chr_d=>x"00", chr_a=>chr_a,
    chr_ce=>open, chr_oe=>open, chr_we=>chr_we, chr_ub=>open, chr_lb=>open,
    sram_ce=>sram_ce, sram_oe=>open, sram_we=>sram_we,
    mcu_miso=>open, mcu_mosi=>'0', mcu_clk=>'0', mcu_ss=>'1', fds_sw=>'0', mcu_busy=>'0',
    led=>open, pwm=>open, fifo_rxf=>open, boot_on=>open,
    gpio=>gpio, exp=>exp, xio=>open, rx=>'0', tx=>open);
  process
    type mem_t is array(0 to 2047) of natural range 0 to 255;
    variable mem : mem_t := (others=>0);
    variable pc : natural := 16#8000#;
    variable acc,x,y,op,lo,hi,adr,value : natural := 0;
    variable n,z,c : boolean := false;
    variable ppu_addr, ppu_first, tile_result, backdrop : natural := 0;
    variable latch : boolean := false;
    variable finished : boolean := false;
    procedure flags(v : natural) is
    begin z:=v=0; n:=v>=128; end;
    procedure bus_cycle(address : natural; write_bus : boolean; data : natural;
                        variable result : out natural) is
    begin
      m2<='0'; full_addr<=address;
      if write_bus then rw<='0'; else rw<='1'; end if;
      drive_data<=std_logic_vector(to_unsigned(data,8));
      wait for 210 ns; m2<='1'; wait for 300 ns;
      assert prg_we='1' and chr_we='1' and sram_we='1' and sram_ce='0'
        report "External memory must remain write-disabled" severity failure;
      if write_bus then
        assert dir='0' report "CPU level shifter must not drive during writes" severity failure;
        if address < 8192 then mem(address mod 2048):=data;
        elsif address=16#2006# then
          if not latch then ppu_first:=data; latch:=true;
          else ppu_addr:=ppu_first*256+data; latch:=false; end if;
        elsif address=16#2007# then
          if ppu_addr=16#2188# then tile_result:=data; end if;
          if ppu_addr=16#3F00# then backdrop:=data; end if;
          ppu_addr:=(ppu_addr+1) mod 16384;
        elsif address=16#2001# and data=16#0A# then finished:=true;
        end if;
        result:=0;
      elsif address < 8192 then result:=mem(address mod 2048);
      elsif address=16#2002# then result:=128; latch:=false;
      elsif address >= 32768 or (address>=16#5000# and address<=16#7FFF#) then
        assert dir='1' report "Cartridge read must enable CPU level shifter" severity failure;
        assert not is_x(cpu_d) report "Undefined cartridge data" severity failure;
        result:=to_integer(unsigned(cpu_d));
        if not mapper_present and address=16#5FF1# then result:=0; end if;
      else result:=0; end if;
      wait for 50 ns; m2<='0'; wait for 1 ns;
    end;
    procedure rd(address : natural; variable v : out natural) is
    begin bus_cycle(address,false,0,v); end;
    procedure wr(address,data : natural) is
      variable ignore : natural;
    begin bus_cycle(address,true,data,ignore); end;
    procedure fetch(variable v : out natural) is
    begin rd(pc,v); pc:=(pc+1) mod 65536; end;
    procedure abs_address(variable a : out natural) is
      variable l,h : natural;
    begin fetch(l); fetch(h); a:=l+h*256; end;
    procedure branch(take : boolean) is
      variable offset : natural;
    begin
      fetch(offset);
      if take then
        if offset>=128 then pc:=(pc+offset+65536-256) mod 65536;
        else pc:=(pc+offset) mod 65536; end if;
        wait for 561 ns;
      end if;
    end;
  begin
    wait for 1 us;
    rd(16#FFFC#,lo); rd(16#FFFD#,hi); pc:=lo+256*hi;
    for instruction in 0 to 50000 loop
      fetch(op);
      case op is
        when 16#78# | 16#D8# | 16#9A# | 16#EA# => wait for 561 ns;
        when 16#A2# => fetch(x); flags(x);
        when 16#A0# => fetch(y); flags(y);
        when 16#A9# => fetch(acc); flags(acc);
        when 16#A5# => fetch(adr); rd(adr,acc); flags(acc);
        when 16#AD# => abs_address(adr); rd(adr,acc); flags(acc);
        when 16#BD# => abs_address(adr); rd((adr+x) mod 65536,acc); flags(acc);
        when 16#8D# => abs_address(adr); wr(adr,acc);
        when 16#9D# => abs_address(adr); wait for 561 ns; wr((adr+x) mod 65536,acc);
        when 16#85# => fetch(adr); wr(adr,acc);
        when 16#8E# => abs_address(adr); wr(adr,x);
        when 16#E8# => x:=(x+1) mod 256; flags(x); wait for 561 ns;
        when 16#CA# => x:=(x+255) mod 256; flags(x); wait for 561 ns;
        when 16#88# => y:=(y+255) mod 256; flags(y); wait for 561 ns;
        when 16#2C# => abs_address(adr); rd(adr,value); n:=value>=128; z:=(to_unsigned(value,8) and to_unsigned(acc,8))=0;
        when 16#10# => branch(not n);
        when 16#D0# => branch(not z);
        when 16#F0# => branch(z);
        when 16#C9# => fetch(value); c:=acc>=value; flags((acc+256-value) mod 256);
        when 16#E0# => fetch(value); c:=x>=value; flags((x+256-value) mod 256);
        when 16#29# => fetch(value); acc:=to_integer(to_unsigned(acc,8) and to_unsigned(value,8)); flags(acc);
        when 16#4C# => abs_address(adr); pc:=adr;
        when 16#E6# => fetch(adr); rd(adr,value); wr(adr,value); value:=(value+1) mod 256; wr(adr,value); flags(value);
        when 16#18# => c:=false; wait for 561 ns;
        when 16#69# => fetch(value); value:=value+acc; if c then value:=value+1; end if; c:=value>255; acc:=value mod 256; flags(acc);
        when others => assert false report "Unexpected 6502 opcode " & integer'image(op) severity failure;
      end case;
      if finished then
        if mapper_present then
          assert tile_result=16#30# and backdrop=16#1A# report "ROM failed to show green result 0" severity failure;
        else
          assert tile_result=16#31# and backdrop=16#16# report "ROM failed to detect missing mapper" severity failure;
        end if;
        report "HOST ROM PASS mapper_present=" & boolean'image(mapper_present);
        stop; wait;
      end if;
    end loop;
    assert false report "6502 instruction limit" severity failure;
    wait;
  end process;
end;
