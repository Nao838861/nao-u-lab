-- SPDX-License-Identifier: GPL-3.0-or-later
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use std.env.all;
entity tb_nes_gsu is end;
architecture test of tb_nes_gsu is
  signal clk : std_logic := '0';
  signal a : std_logic_vector(15 downto 0) := x"0000";
  signal di, dout : std_logic_vector(7 downto 0) := x"00";
  signal rw : std_logic := '1';
  signal m2 : std_logic := '0';
  signal selected, irq_n : std_logic;
begin
  clk <= not clk after 20 ns;
  dut : entity work.nes_gsu port map(clk,a,di,rw,m2,dout,selected,irq_n);
  process
    file hex : text open read_mode is "program.hex";
    variable ln : line;
    type bytes_t is array(0 to 63) of std_logic_vector(7 downto 0);
    variable prog : bytes_t;
    variable v : std_logic_vector(7 downto 0);
    variable done : boolean;
    procedure bus_cycle(addr : natural; data : natural; write_bus : boolean;
                        variable value : out std_logic_vector(7 downto 0)) is
    begin
      m2 <= '0'; a <= std_logic_vector(to_unsigned(addr,16));
      di <= std_logic_vector(to_unsigned(data,8));
      if write_bus then rw <= '0'; else rw <= '1'; end if;
      wait for 210 ns;
      m2 <= '1'; wait for 300 ns;
      value := dout;
      wait for 50 ns; m2 <= '0'; wait for 1 ns;
    end;
    procedure wr(addr,data : natural) is
      variable ignored : std_logic_vector(7 downto 0);
    begin bus_cycle(addr,data,true,ignored); end;
    procedure expect(addr,data : natural) is
      variable value : std_logic_vector(7 downto 0);
    begin
      bus_cycle(addr,0,false,value);
      assert value = std_logic_vector(to_unsigned(data,8))
        report "address " & integer'image(addr) & " expected " & integer'image(data) & " got " & to_hstring(value) severity failure;
    end;
  begin
    for i in prog'range loop readline(hex,ln); hread(ln,prog(i)); end loop;
    wait for 1 us;
    expect(16#5FF1#,16#53#); expect(16#5FF2#,1);
    -- Four asynchronous phases (561 ns host cycle versus 40 ns FPGA).
    -- Reload/reset each trial so cache validity and GO are not inherited.
    for trial in 0 to 3 loop
      wr(16#5FF0#,16#A5#); wait for 1 us;
      expect(16#503B#,4);
      wr(16#5034#,0); wr(16#5039#,0); wr(16#5038#,0);
      wr(16#5037#,16#80#); wr(16#503A#,16#18#);
      for i in 0 to 15 loop wr(16#6000#+i,0); end loop;
      wr(16#6200#,0); wr(16#6201#,0);
      for i in prog'range loop wr(16#5100#+i,to_integer(unsigned(prog(i)))); end loop;
      -- Read-back the synchronously clocked cache port.
      expect(16#5101#,16#34#);
      wr(16#501E#,0); wr(16#501F#,0);
      done := false;
      for poll in 0 to 1023 loop
        bus_cycle(16#5030#,0,false,v);
        if v(5) = '0' then done := true; exit; end if;
      end loop;
      assert done report "GSU GO timeout" severity failure;
      -- Reading again releases WRAM ownership after STOP.
      bus_cycle(16#5030#,0,false,v);
      expect(16#500A#,63); expect(16#500B#,0);
      expect(16#6200#,16#36#); expect(16#6201#,16#13#);
      expect(16#6000#,255); expect(16#6001#,255);
      for i in 2 to 15 loop expect(16#6000#+i,0); end loop;
      assert irq_n = '1' report "masked IRQ should stay inactive" severity failure;
      report "GSU ADD/MULT/STW/PLOT/reset/cache PASS trial " & integer'image(trial);
      wait for 7 ns;
    end loop;
    -- Explicitly exercise signed multiplication and 16-bit addition wrap.
    wr(16#5FF0#,16#A5#); wait for 1 us;
    wr(16#5034#,0); wr(16#503A#,16#18#);
    prog(1):=x"FF"; prog(2):=x"FF"; -- $FFFF + $0102 = $0101
    prog(10):=x"F9"; prog(11):=x"FF"; -- signed -7 * 9 = -63
    for i in prog'range loop wr(16#5100#+i,to_integer(unsigned(prog(i)))); end loop;
    wr(16#501E#,0); wr(16#501F#,0);
    done := false;
    for poll in 0 to 1023 loop
      bus_cycle(16#5030#,0,false,v);
      if v(5) = '0' then done := true; exit; end if;
    end loop;
    assert done report "signed test timeout" severity failure;
    bus_cycle(16#5030#,0,false,v);
    expect(16#500A#,16#C1#); expect(16#500B#,16#FF#);
    expect(16#6200#,1); expect(16#6201#,1);
    report "ALL TESTS PASSED";
    stop;
    wait;
  end process;
end;
