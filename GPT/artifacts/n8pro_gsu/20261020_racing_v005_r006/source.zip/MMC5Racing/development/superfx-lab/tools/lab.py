"""GSU 実験環境。依存取得、ROM、RTL simulation、Quartus、SD 配布を分離。"""
from __future__ import annotations
import argparse
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
import re
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile

LAB = Path(__file__).resolve().parents[1]
ROOT = LAB.parents[1]
BUILD = ROOT / 'build' / 'superfx-lab'
DEPS = ROOT / 'build' / 'superfx-deps'
SOURCES = {
    'edn8-pro-pub': ('https://github.com/krikzz/edn8-pro-pub.git', '317f8caf8d2b917a260e94ec14d5edbbbfced8ba'),
}

def run(args, cwd=None, **kwargs):
    return subprocess.run([str(a) for a in args], cwd=cwd or ROOT, check=True, **kwargs)

def executable(name, extra=()):
    for p in [shutil.which(name), *extra]:
        if p and Path(p).is_file():
            return str(Path(p).resolve())
    raise SystemExit(f'{name} が見つかりません。PATH または対応オプションで指定してください。')

def fetch():
    DEPS.mkdir(parents=True, exist_ok=True)
    for name, (url, rev) in SOURCES.items():
        dest = DEPS / name
        if not dest.exists():
            run(['git', 'clone', '--no-checkout', url, dest])
            run(['git', 'checkout', '--detach', rev], cwd=dest)
        status = run(['git', 'status', '--porcelain'], cwd=dest, capture_output=True, text=True).stdout
        if status.strip():
            raise SystemExit(f'依存に未保存の変更があります: {dest}')
        run(['git', 'fetch', 'origin', rev], cwd=dest)
        run(['git', 'checkout', '--detach', rev], cwd=dest)

def ghdl_path(arg=None):
    if arg:
        if not Path(arg).is_file(): raise SystemExit(f'GHDL executable not found: {arg}')
        return str(Path(arg).resolve())
    pinned = DEPS / 'ghdl-5.1.1/bin/ghdl.exe'
    if pinned.is_file(): return str(pinned.resolve())
    return executable('ghdl')

def quartus_candidates(arg=None):
    candidates = [arg, shutil.which('quartus_sh')]
    local = os.environ.get('LOCALAPPDATA')
    if local:
        candidates.append(Path(local)/'N8ProTools/24.1/quartus/bin64/quartus_sh.exe')
    for drive in ['C:/', 'D:/']:
        candidates.extend(Path(drive).glob('intelFPGA*/*/quartus/bin64/quartus_sh.exe'))
        candidates.extend(Path(drive).glob('altera/*/quartus/bin64/quartus_sh.exe'))
        candidates.extend(Path(drive).glob('altera_lite/*/quartus/bin64/quartus_sh.exe'))
    return list(dict.fromkeys(str(Path(p).resolve()) for p in candidates if p and Path(p).is_file()))

def doctor(arg=None):
    BUILD.mkdir(parents=True, exist_ok=True)
    tools = {}
    for name, paths in [('ca65', [ROOT/'tools/ca65/ca65.exe', ROOT/'tools/ca65']),
                         ('ld65', [ROOT/'tools/ld65/ld65.exe', ROOT/'tools/ld65']),
                         ('ghdl', [DEPS/'ghdl-5.1.1/bin/ghdl.exe'])]:
        try: tools[name] = ghdl_path() if name == 'ghdl' else executable(name, paths)
        except SystemExit: tools[name] = None
    ports = []
    if os.name == 'nt':
        import winreg
        try:
            with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'HARDWARE\DEVICEMAP\SERIALCOMM') as key:
                for i in range(winreg.QueryInfoKey(key)[1]):
                    ports.append(winreg.EnumValue(key, i)[1])
        except FileNotFoundError: pass
    catalog = json.loads((LAB/'tools/quartus_downloads.json').read_text())
    downloads = DEPS/'quartus-downloads'
    report = {
        'target': 'EverDrive N8 Pro', 'fpga': 'EP4CE6F17C8',
        'tools': tools, 'quartus_candidates': quartus_candidates(arg),
        'registered_serial_ports': sorted(set(ports)),
        'serial_ports_note': 'Registry entries may be stale or virtual. They do not identify an N8 Pro or establish a live connection; SD-only testing needs no COM port.',
        'official_quartus_page': catalog['official_page'],
        'download_directory': str(downloads),
        'download_files': [{'name': item['name'], 'present': (downloads/item['name']).is_file(),
                            'published_sha1': item['sha1']} for item in catalog['files']],
        'rom_present': (BUILD/'gsu-selftest.nes').is_file(),
        'rbf_present': (BUILD/'quartus/output_files/gsu.rbf').is_file(),
        'hardware_tested': False,
    }
    (BUILD/'environment.json').write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))

def install_ghdl():
    DEPS.mkdir(parents=True, exist_ok=True)
    url = 'https://github.com/ghdl/ghdl/releases/download/v5.1.1/ghdl-mcode-5.1.1-mingw64.zip'
    archive = DEPS / 'ghdl-5.1.1.zip'
    urllib.request.urlretrieve(url, archive)
    digest = hashlib.sha256(archive.read_bytes()).hexdigest()
    if digest != '6010047f5341d0e3d66b63166157004a75a49c1ed9a0b6c58725e1f913363b7c':
        raise SystemExit('GHDL ZIP の SHA256 が固定値と一致しません')
    with zipfile.ZipFile(archive) as z:
        # All members must stay in this dedicated extraction directory.
        target = (DEPS / 'ghdl-5.1.1').resolve()
        for item in z.infolist():
            if not (target / item.filename).resolve().is_relative_to(target):
                raise SystemExit('不正な ZIP パス')
        z.extractall(target)
    print(json.dumps({'url': url, 'sha256': digest}))

def rom():
    BUILD.mkdir(parents=True, exist_ok=True)
    glyphs = {
        'G': [14,17,16,23,17,17,14], 'S': [15,16,16,14,1,1,30],
        'U': [17,17,17,17,17,17,14], 'E': [31,16,16,30,16,16,31],
        'L': [16,16,16,16,16,16,31], 'F': [31,16,16,30,16,16,16],
        'T': [31,4,4,4,4,4,4], '0': [14,17,19,21,25,17,14],
        '1': [4,12,4,4,4,4,14], '2': [14,17,1,2,4,8,31],
        '3': [30,1,1,14,1,1,30], '4': [2,6,10,18,31,2,2],
        '5': [31,16,16,30,1,1,30],
    }
    font = bytearray(8192)
    for ch, rows in glyphs.items():
        font[ord(ch)*16:ord(ch)*16+7] = bytes(x << 2 for x in rows)
    (BUILD / 'font.chr').write_bytes(font)
    ca = executable('ca65', [ROOT / 'tools/ca65/ca65.exe', ROOT / 'tools/ca65'])
    ld = executable('ld65', [ROOT / 'tools/ld65/ld65.exe', ROOT / 'tools/ld65'])
    run([ca, LAB / 'rom/selftest.s', '-o', BUILD / 'selftest.o', '-I', LAB / 'rom', '--bin-include-dir', BUILD])
    run([ld, '-C', LAB / 'rom/nrom.cfg', BUILD / 'selftest.o', '-o', BUILD / 'gsu-selftest.nes', '-Ln', BUILD / 'selftest.lbl'])
    data = (BUILD / 'gsu-selftest.nes').read_bytes()
    assert len(data) == 16 + 32768 + 8192 and data[:4] == b'NES\x1a'
    labels = dict((name, int(addr, 16)) for addr, name in re.findall(r'^al ([0-9A-Fa-f]+) \.(\w+)$', (BUILD / 'selftest.lbl').read_text(), re.M))
    program = data[16+labels['gsu_program']-0x8000:16+labels['gsu_program_end']-0x8000]
    assert len(program) == 64
    (BUILD / 'program.hex').write_text(''.join(f'{b:02X}\n' for b in program))
    (BUILD / 'prg.hex').write_text(''.join(f'{b:02X}\n' for b in data[16:16+32768]))
    (BUILD / 'rom-manifest.json').write_text(json.dumps({'sha256': hashlib.sha256(data).hexdigest(), 'bytes': len(data), 'mapper_header': 0, 'requires_custom_rbf': True, 'inputs': rom_input_hashes()}, indent=2) + '\n')
    print(f'ROM: {BUILD / "gsu-selftest.nes"}')

def simulate(arg=None):
    BUILD.mkdir(parents=True, exist_ok=True)
    rom()
    ghdl = ghdl_path(arg)
    sources = [LAB / 'rtl/dpram_difclk.vhd', LAB / 'vendor/GSU_PKG.vhd',
               LAB / 'vendor/GSU.vhd', LAB / 'rtl/nes_gsu.vhd', LAB / 'rtl/n8pro_top.vhd',
               LAB / 'sim/tb_nes_gsu.vhd', LAB / 'sim/tb_host_rom.vhd']
    run([ghdl, '-a', '--std=08', *sources], cwd=BUILD)
    logs = []
    for entity, generics, marker in [('tb_nes_gsu', [], 'ALL TESTS PASSED'),
            ('tb_host_rom', [], 'HOST ROM PASS'),
            ('tb_host_rom', ['-gmapper_present=false'], 'HOST ROM PASS')]:
        result = subprocess.run([ghdl, '-r', '--std=08', entity, *generics, '--assert-level=error',
                      '--ieee-asserts=disable-at-0', '--stop-time=30ms'], cwd=BUILD, capture_output=True, text=True)
        logs.append(result.stdout + result.stderr)
        (BUILD / 'simulation.log').write_text('\n'.join(logs), encoding='utf-8')
        print(result.stdout)
        result.check_returncode()
        if marker not in result.stdout:
            raise SystemExit('シミュレーションの完了マーカーがありません')
    (BUILD / 'simulation-report.json').write_text(json.dumps({
        'tested_at_jst': datetime.now(timezone(timedelta(hours=9))).isoformat(),
        'ghdl': run([ghdl, '--version'], capture_output=True, text=True).stdout.splitlines()[0],
        'rom_sha256': hashlib.sha256((BUILD/'gsu-selftest.nes').read_bytes()).hexdigest(),
        'cases': {'gsu_arithmetic_store_plot_reset_cache': 'pass',
                  'host_rom_via_board_rtl': 'pass', 'host_rom_missing_id_fault': 'pass'},
        'sources': source_hashes(),
        'harness': hashes(sorted((LAB/'sim').glob('*')) + [Path(__file__).resolve()]),
        'quartus_fitted': False, 'hardware_tested': False}, indent=2) + '\n')

def prepare():
    base = DEPS / 'edn8-pro-pub'
    if not base.exists():
        raise SystemExit('先に fetch を実行してください')
    actual = run(['git', 'rev-parse', 'HEAD'], cwd=base, capture_output=True, text=True).stdout.strip()
    if actual != SOURCES['edn8-pro-pub'][1]:
        raise SystemExit('pin map の依存 revision が不一致です')
    project = BUILD / 'quartus'
    project.mkdir(parents=True, exist_ok=True)
    # Reuse only physical pin/electrical assignments, not the sample logic.
    lines = (base / 'fpga/000/top.qsf').read_text().splitlines()
    aliases = {'cpu_dat':'cpu_d', 'cpu_addr':'cpu_a', 'cpu_ce':'cpu_romsel',
               'ppu_dat':'ppu_d', 'ppu_addr':'ppu_a', 'ppu_oe':'ppu_rd', 'ppu_we':'ppu_wr',
               'prg_dat':'prg_d', 'prg_addr':'prg_a', 'chr_dat':'chr_d', 'chr_addr':'chr_a',
               'srm_ce':'sram_ce', 'srm_oe':'sram_oe', 'srm_we':'sram_we',
               'spi_miso':'mcu_miso', 'spi_mosi':'mcu_mosi', 'spi_clk':'mcu_clk',
               'spi_ss':'mcu_ss', 'clk':'clk50', 'exp_io':'exp'}
    assignments = []
    for line in lines:
        if line.startswith('set_location_assignment'):
            prefix, port = line.rsplit(' -to ',1)
            match = re.fullmatch(r'(\w+)(\[\d+\])?', port)
            if not match:
                raise SystemExit(f'未知の pin assignment: {line}')
            name, index = match.groups()
            assignments.append(prefix + ' -to ' + aliases.get(name,name) + (index or ''))
    sources = [LAB / 'rtl/dpram_difclk.vhd', LAB / 'vendor/GSU_PKG.vhd', LAB / 'vendor/GSU.vhd', LAB / 'rtl/nes_gsu.vhd', LAB / 'rtl/n8pro_top.vhd']
    settings = ['set_global_assignment -name FAMILY "Cyclone IV E"', 'set_global_assignment -name DEVICE EP4CE6F17C8',
                'set_global_assignment -name TOP_LEVEL_ENTITY n8pro_top', 'set_global_assignment -name PROJECT_OUTPUT_DIRECTORY output_files',
                'set_global_assignment -name VHDL_INPUT_VERSION VHDL_2008', 'set_global_assignment -name GENERATE_RBF_FILE ON',
                'set_global_assignment -name STRATIX_DEVICE_IO_STANDARD "3.3-V LVCMOS"',
                'set_global_assignment -name USE_CONFIGURATION_DEVICE OFF',
                # N8 Pro routes these configuration pins to cartridge signals.
                # Preserve the manufacturer's post-configuration GPIO settings.
                'set_global_assignment -name CYCLONEII_RESERVE_NCEO_AFTER_CONFIGURATION "USE AS REGULAR IO"',
                'set_global_assignment -name RESERVE_FLASH_NCE_AFTER_CONFIGURATION "USE AS REGULAR IO"',
                'set_global_assignment -name RESERVE_DATA1_AFTER_CONFIGURATION "USE AS REGULAR IO"',
                'set_global_assignment -name NUM_PARALLEL_PROCESSORS 8',
                'set_global_assignment -name RESERVE_ALL_UNUSED_PINS "AS INPUT TRI-STATED"']
    settings += [f'set_global_assignment -name VHDL_FILE "{p.as_posix()}"' for p in sources]
    settings += [f'set_global_assignment -name SDC_FILE "{(LAB / "rtl/n8pro.sdc").as_posix()}"']
    (project / 'gsu.qsf').write_text('\n'.join(settings + assignments) + '\n')
    (project / 'gsu.qpf').write_text('PROJECT_REVISION = "gsu"\n')
    print(f'Quartus project: {project / "gsu.qpf"}')
    return project

def quartus(arg=None):
    project = prepare()
    q = executable('quartus_sh', quartus_candidates(arg))
    with (BUILD / 'quartus.log').open('w', encoding='utf-8') as log:
        run([q, '--flow', 'compile', 'gsu'], cwd=project, stdout=log, stderr=subprocess.STDOUT)
    rbf = project / 'output_files/gsu.rbf'
    if not rbf.is_file():
        raise SystemExit('Quartus は RBF を生成していません')
    (BUILD / 'bitstream-manifest.json').write_text(json.dumps({
        'inputs': input_hashes(), 'rbf_sha256': hashlib.sha256(rbf.read_bytes()).hexdigest(),
        'hardware_tested': False, 'timing_signoff': False}, indent=2) + '\n')
    print(f'RBF: {rbf}。TimeQuest の setup/hold と非制約経路の確認が必要です。')

def package():
    rbf = BUILD / 'quartus/output_files/gsu.rbf'
    if not rbf.is_file():
        raise SystemExit('RBF 未生成。ROM 単体では GSU は動きません。先に quartus を実行してください。')
    meta = json.loads((BUILD / 'bitstream-manifest.json').read_text())
    if meta['inputs'] != input_hashes() or meta['rbf_sha256'] != hashlib.sha256(rbf.read_bytes()).hexdigest():
        raise SystemExit('ソースまたは RBF が合成時から変わっています。quartus を再実行してください。')
    rom_meta = json.loads((BUILD / 'rom-manifest.json').read_text())
    if rom_meta['inputs'] != rom_input_hashes() or rom_meta['sha256'] != hashlib.sha256((BUILD/'gsu-selftest.nes').read_bytes()).hexdigest():
        raise SystemExit('ROM または ROMソースが生成時から変わっています。rom を再実行してください。')
    dest = BUILD / 'sdcard/GSU-LAB'
    dest.mkdir(parents=True, exist_ok=True)
    for src, name in [(BUILD / 'gsu-selftest.nes', 'gsu-selftest.nes'), (rbf, 'gsu.rbf')]:
        shutil.copy2(src, dest / name)
    shutil.copy2(BUILD / 'bitstream-manifest.json', dest / 'bitstream-manifest.json')
    (dest / 'manifest.json').write_text(json.dumps({p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in dest.iterdir() if p.suffix in ('.nes', '.rbf')}, indent=2) + '\n')
    print(dest)

def hashes(paths):
    return {str(p.relative_to(ROOT)).replace('\\','/'): hashlib.sha256(p.read_bytes()).hexdigest() for p in paths}

def source_hashes():
    paths = sorted(p for folder in ['rtl','vendor','rom'] for p in (LAB/folder).rglob('*') if p.is_file())
    return hashes(paths)

def rom_input_hashes():
    return hashes(sorted((LAB/'rom').glob('*')) + [Path(__file__).resolve()])

def input_hashes():
    return source_hashes() | hashes([BUILD/'quartus/gsu.qsf', BUILD/'quartus/gsu.qpf'])

def upload():
    package()
    tool = DEPS / 'edn8-pro-pub/edlink.exe'
    if not tool.is_file():
        raise SystemExit('edlink.exe がありません。fetch を実行してください。')
    dest = BUILD / 'sdcard/GSU-LAB'
    run([tool, 'run', '--file', dest/'gsu-selftest.nes', '--fpga', dest/'gsu.rbf'])

def mesen(arg):
    rom()
    exe = Path(executable('Mesen', [arg]))
    out = BUILD / 'mesen-missing-mapper'
    out.mkdir(parents=True, exist_ok=True)
    portable = Path(tempfile.mkdtemp(prefix='emulator-', dir=out))
    for p in exe.parent.iterdir():
        if p.is_file() and p.suffix.lower() in ('.exe','.dll'):
            shutil.copy2(p, portable/p.name)
    (portable/'settings.json').write_text('{}')
    env = os.environ.copy(); env['GSU_LAB_QA'] = str(out)
    startup = subprocess.STARTUPINFO(); startup.dwFlags |= subprocess.STARTF_USESHOWWINDOW; startup.wShowWindow = 0
    result = subprocess.run([portable/exe.name, '--testRunner', '--timeout=20',
        '--debug.scriptWindow.allowIoOsAccess=true', BUILD/'gsu-selftest.nes', LAB/'sim/missing_mapper.lua'],
        cwd=portable, env=env, startupinfo=startup, capture_output=True, timeout=30)
    (out/'runner.log').write_bytes(result.stdout+result.stderr)
    result.check_returncode()
    evidence = json.loads((out/'result.json').read_text())
    assert evidence['result_code'] == 1
    print(evidence)

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('command', choices=['fetch', 'install-ghdl', 'rom', 'sim', 'prepare-quartus', 'quartus', 'package', 'upload', 'mesen-negative', 'doctor', 'check'])
    p.add_argument('--ghdl')
    p.add_argument('--quartus-sh')
    p.add_argument('--mesen')
    a = p.parse_args()
    if a.command == 'fetch': fetch()
    elif a.command == 'install-ghdl': install_ghdl()
    elif a.command == 'rom': rom()
    elif a.command == 'sim': simulate(a.ghdl)
    elif a.command == 'prepare-quartus': prepare()
    elif a.command == 'quartus': quartus(a.quartus_sh)
    elif a.command == 'package': package()
    elif a.command == 'upload': upload()
    elif a.command == 'mesen-negative': mesen(a.mesen)
    elif a.command == 'doctor': doctor(a.quartus_sh)
    elif a.command == 'check': simulate(a.ghdl); prepare()

if __name__ == '__main__':
    main()
