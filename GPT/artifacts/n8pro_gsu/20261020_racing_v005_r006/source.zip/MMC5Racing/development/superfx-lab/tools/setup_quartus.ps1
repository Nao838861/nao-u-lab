# Quartus Lite と Cyclone IV サポートを検証して導入する。
# SPDX-License-Identifier: GPL-3.0-or-later
[CmdletBinding()]
param(
    [string]$DownloadDirectory,
    [string]$InstallDirectory = (Join-Path $env:LOCALAPPDATA 'N8ProTools\24.1'),
    [switch]$Install,
    [switch]$AcceptEula
)
$ErrorActionPreference = 'Stop'
$repoRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\..'))
$buildDirectory = Join-Path $repoRoot 'build\superfx-lab'
if (-not $DownloadDirectory) {
    $DownloadDirectory = Join-Path $repoRoot 'build\superfx-deps\quartus-downloads'
}
$catalog = Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'quartus_downloads.json') | ConvertFrom-Json
$verifiedFiles = @()
foreach ($item in $catalog.files) {
    $filePath = Join-Path $DownloadDirectory $item.name
    if (-not (Test-Path -LiteralPath $filePath -PathType Leaf)) {
        throw "Missing $($item.name). Download the two listed files from $($catalog.official_page) into $DownloadDirectory"
    }
    $digest = (Get-FileHash -LiteralPath $filePath -Algorithm SHA1).Hash.ToLowerInvariant()
    if ($digest -ne $item.sha1) {
        throw "SHA1 mismatch: $($item.name). The installer will not run."
    }
    $verifiedFiles += [ordered]@{
        name = $item.name
        sha1 = $digest
        sha256 = (Get-FileHash -LiteralPath $filePath -Algorithm SHA256).Hash.ToLowerInvariant()
        bytes = (Get-Item -LiteralPath $filePath).Length
    }
}
New-Item -ItemType Directory -Force -Path $buildDirectory | Out-Null
[ordered]@{
    edition = $catalog.edition
    version = $catalog.version
    source = $catalog.official_page
    install_directory = $InstallDirectory
    files = $verifiedFiles
    installed = $false
} | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -LiteralPath (Join-Path $buildDirectory 'quartus-setup-manifest.json')
if (-not $Install) {
    Write-Output 'Both files match the hashes published by Altera. Verification only; installer not launched.'
    Write-Output 'Read the installer license, then explicitly pass -Install -AcceptEula to install.'
    return
}
if (-not $AcceptEula) {
    throw 'Installation requires accepting the vendor EULA. Review it in the official installer; pass -AcceptEula only if you agree.'
}
# This script deliberately needs a user-supplied agreement flag; verification
# and lab.py check never accept a license or launch an installer.
$installerPath = Join-Path $DownloadDirectory $catalog.files[0].name
$setupArguments = '--mode unattended --unattendedmodeui none --installdir "' + $InstallDirectory + '" --accept_eula 1'
$setupProcess = Start-Process -FilePath $installerPath -ArgumentList $setupArguments -WindowStyle Hidden -Wait -PassThru
if ($setupProcess.ExitCode -ne 0) {
    throw "Quartus installer failed with exit code $($setupProcess.ExitCode)"
}
$quartusPath = Join-Path $InstallDirectory 'quartus\bin64\quartus_sh.exe'
if (-not (Test-Path -LiteralPath $quartusPath -PathType Leaf)) {
    throw "Installer finished but quartus_sh.exe was not found at $quartusPath"
}
& $quartusPath --version
if ($LASTEXITCODE -ne 0) { throw 'quartus_sh --version failed.' }
$manifestPath = Join-Path $buildDirectory 'quartus-setup-manifest.json'
$installedManifest = Get-Content -Raw -Encoding UTF8 -LiteralPath $manifestPath | ConvertFrom-Json
$installedManifest.installed = $true
$installedManifest | ConvertTo-Json -Depth 5 | Set-Content -Encoding UTF8 -LiteralPath $manifestPath
Write-Output "Quartus ready: $quartusPath"
