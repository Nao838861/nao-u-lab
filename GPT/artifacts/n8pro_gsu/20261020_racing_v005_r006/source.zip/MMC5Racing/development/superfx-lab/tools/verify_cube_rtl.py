"""初期立方体の実GSUコードをRTLで64姿勢実行し、頂点と全描画RAMを照合する。"""
import argparse, hashlib, importlib.util, json, struct
from pathlib import Path
import lab


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--emulator-project',type=Path,required=True)
    args=parser.parse_args()
    project=args.emulator_project.resolve()
    spec=importlib.util.spec_from_file_location('cube_reference',project/'tools/build_cube.py')
    reference=importlib.util.module_from_spec(spec);spec.loader.exec_module(reference)
    built=project/'build/cube_v001'
    rom=(project/'releases/GSU_Cube_v001.nes').read_bytes()
    assert hashlib.sha256(rom).hexdigest()=='df9b339c4a98d8fde994d8d119e544609ae56bc27b34729f8e0a6152686d55ac'
    code=(built/'gsu.bin').read_bytes()
    assert len(code)<=512 and code in rom
    out=lab.BUILD/'cube-rtl';out.mkdir(parents=True,exist_ok=True)
    def hexfile(name,data):
        (out/name).write_text(''.join(f'{v:02X}\n' for v in data))
    hexfile('program.hex',code.ljust(512,b'\0'))
    for name in ['model','edges','matrices']:
        data=(built/f'{name}.bin').read_bytes()
        # Matrices are interleaved with labels in source but contiguous in ROM.
        assert data in rom
        hexfile(name+'.hex',data)
    expected=bytearray()
    for phase in range(64):
        xy,pixels=reference.expected_bitmap(phase)
        ram=bytearray(2048)
        for y,row in enumerate(pixels):
            for x,color in enumerate(row):
                at=(x//8)*256+(y//8)*16+(y%8)*2
                ram[at]|=(color&1)<<(7-x%8)
                ram[at+1]|=((color>>1)&1)<<(7-x%8)
        expected+=ram+b''.join(struct.pack('<HH',*v) for v in xy)
    hexfile('expected.hex',expected)
    original=(lab.LAB/'sim/tb_nes_gsu.vhd').read_text()
    source=original[:original.index('  begin\n    for i in prog')]
    source=source.replace('tb_nes_gsu','tb_cube').replace('0 to 63','0 to 511')
    source=source.replace('    variable ln : line;', '''    file model : text open read_mode is "model.hex";
    file edges : text open read_mode is "edges.hex";
    file matrices : text open read_mode is "matrices.hex";
    file expected : text open read_mode is "expected.hex";
    variable ln : line;''')
    source+='''  begin
    for i in prog'range loop readline(hex,ln); hread(ln,prog(i)); end loop;
    wait for 1 us;
    wr(16#5FF0#,16#A5#); wait for 1 us;
    wr(16#5034#,0); wr(16#5039#,0); wr(16#5038#,0);
    wr(16#5037#,16#80#); wr(16#503A#,16#18#);
    for i in prog'range loop wr(16#5100#+i,to_integer(unsigned(prog(i)))); end loop;
    for i in 0 to 47 loop
      readline(model,ln); hread(ln,v); wr(16#7000#+i,to_integer(unsigned(v)));
    end loop;
    for i in 0 to 71 loop
      readline(edges,ln); hread(ln,v); wr(16#7300#+i,to_integer(unsigned(v)));
    end loop;
    for phase in 0 to 63 loop
      for i in 0 to 11 loop
        readline(matrices,ln); hread(ln,v); wr(16#7200#+i,to_integer(unsigned(v)));
      end loop;
      wr(16#501E#,0); wr(16#501F#,0);
      done:=false;
      for poll in 0 to 65535 loop
        bus_cycle(16#5030#,0,false,v);
        if v(5)='0' then done:=true; exit; end if;
      end loop;
      assert done report "cube GO timeout" severity failure;
      bus_cycle(16#5030#,0,false,v);
      for i in 0 to 2047 loop
        readline(expected,ln); hread(ln,v); expect(16#6000#+i,to_integer(unsigned(v)));
      end loop;
      for i in 0 to 31 loop
        readline(expected,ln); hread(ln,v); expect(16#7100#+i,to_integer(unsigned(v)));
      end loop;
      report "CUBE RTL PASS phase " & integer'image(phase);
    end loop;
    report "ALL CUBE PHASES PASSED";
    stop; wait;
  end process;
end;
'''
    (out/'tb_cube.vhd').write_text(source)
    ghdl=lab.ghdl_path()
    sources=[lab.LAB/'rtl/dpram_difclk.vhd',lab.LAB/'vendor/GSU_PKG.vhd',lab.LAB/'vendor/GSU.vhd',lab.LAB/'rtl/nes_gsu.vhd',out/'tb_cube.vhd']
    lab.run([ghdl,'-a','--std=08',*sources],cwd=out)
    result=lab.run([ghdl,'-r','--std=08','tb_cube','--assert-level=error','--ieee-asserts=disable-at-0','--stop-time=3sec'],cwd=out,capture_output=True,text=True)
    (out/'simulation.log').write_text(result.stdout+result.stderr)
    assert 'ALL CUBE PHASES PASSED' in result.stdout
    report={'status':'pass','phases':64,'vertices_checked':512,'ram_bytes_checked':len(expected),
            'rom_sha256':hashlib.sha256(rom).hexdigest(),'sources':lab.source_hashes(),
            'scope':'GSU code, CPU bus transactions and RAM; PPU and physical hardware not tested'}
    (out/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k!='sources'}))


if __name__=='__main__':main()
