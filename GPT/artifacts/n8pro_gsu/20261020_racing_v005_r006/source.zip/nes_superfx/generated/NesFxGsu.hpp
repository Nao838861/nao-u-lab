// Generated from pinned Mesen2; GPL-3.0-or-later. See sources.lock.json.
#pragma once
#include <cstdint>
#include <cstring>
#include <algorithm>
namespace nesfx {
struct Bus {
    virtual ~Bus() = default;
    virtual uint8_t GsuRead(uint32_t) = 0;
    virtual void GsuWrite(uint32_t, uint8_t) = 0;
    virtual uint8_t MemoryClockScale() const { return 1; }
    virtual bool FastInternalRam() const { return false; }
};
enum class MemoryOperationType { Read, Write, ExecOpCode, ExecOperand };
#pragma once

struct GsuFlags
{
	bool Zero;
	bool Carry;
	bool Sign;
	bool Overflow;
	bool Running;
	bool RomReadPending;
	bool Alt1;
	bool Alt2;
	bool ImmLow;
	bool ImmHigh;
	bool Prefix;
	bool Irq;
	
	uint8_t GetFlagsLow()
	{
		return (
			(Zero << 1) |
			(Carry << 2) |
			(Sign << 3) |
			(Overflow << 4) |
			(Running << 5) |
			(RomReadPending << 6)
		);
	}

	uint8_t GetFlagsHigh()
	{
		return (
			(Alt1 << 0) |
			(Alt2 << 1) |
			(ImmLow << 2) |
			(ImmHigh << 3) |
			(Prefix << 4) |
			(Irq << 7)
		);
	}
};

struct GsuPixelCache
{
	uint8_t X;
	uint8_t Y;
	uint8_t Pixels[8];
	uint8_t ValidBits;
};

struct GsuState
{
	uint64_t CycleCount;

	uint16_t R[16];

	GsuFlags SFR;
	
	uint8_t RegisterLatch;

	uint8_t ProgramBank;
	uint8_t RomBank;
	uint8_t RamBank;

	bool IrqDisabled;
	bool HighSpeedMode;
	bool ClockSelect;
	bool BackupRamEnabled;
	uint8_t ScreenBase;
	
	uint8_t ColorGradient;
	uint8_t PlotBpp;
	uint8_t ScreenHeight;
	bool GsuRamAccess;
	bool GsuRomAccess;

	uint16_t CacheBase;

	bool PlotTransparent;
	bool PlotDither;
	bool ColorHighNibble;
	bool ColorFreezeHigh;
	bool ObjMode;

	uint8_t ColorReg;
	uint8_t SrcReg;
	uint8_t DestReg;
	
	uint8_t RomReadBuffer;
	uint8_t RomDelay;

	uint8_t ProgramReadBuffer;

	uint16_t RamWriteAddress;
	uint8_t RamWriteValue;
	uint8_t RamDelay;

	uint16_t RamAddress;
	
	GsuPixelCache PrimaryCache;
	GsuPixelCache SecondaryCache;
};
class Gsu {
private:
    Bus& _bus;
	GsuState _state;

	uint8_t _cache[512];
	bool _cacheValid[32] = {};
	bool _waitForRomAccess = false;
	bool _waitForRamAccess = false;
	bool _stopped = true;
	bool _r15Changed = false;
	uint32_t _lastOpAddr = 0;

	void Exec();

	void InitProgramCache(uint16_t cacheAddr);

	uint8_t ReadOperand();	
	uint8_t ReadOpCode();
	uint8_t ReadProgramByte(MemoryOperationType opType);

	uint16_t ReadSrcReg();
	void WriteDestReg(uint16_t value);
	void WriteRegister(uint8_t reg, uint16_t value);

	void ResetFlags();
	void InvalidateCache();
	
	void WaitRomOperation();
	void WaitRamOperation();

	void WaitForRomAccess();
	void WaitForRamAccess();
	void UpdateRunningState();

	uint8_t ReadRomBuffer();
	uint8_t ReadRamBuffer(uint16_t addr);
	void WriteRam(uint16_t addr, uint8_t value);
	void Step(uint64_t cycles);

	void STOP();
	void NOP();
	void CACHE();

	void Branch(bool branch);
	
	void BRA();
	void BLT();
	void BGE();
	void BNE();
	void BEQ();
	void BPL();
	void BMI();
	void BCC();
	void BCS();
	void BVC();
	void BVS();
	void JMP(uint8_t reg);

	void TO(uint8_t reg);
	void FROM(uint8_t reg);
	void WITH(uint8_t reg);

	void STORE(uint8_t reg);
	void LOAD(uint8_t reg);

	void LOOP();
	void ALT1();
	void ALT2();
	void ALT3();

	void MERGE();
	void SWAP();

	void PlotRpix();
	void ColorCMode();

	uint16_t GetTileIndex(uint8_t x, uint8_t y);
	uint32_t GetTileAddress(uint8_t x, uint8_t y);

	uint8_t ReadPixel(uint8_t x, uint8_t y);
	bool IsTransparentPixel();
	void DrawPixel(uint8_t x, uint8_t y);
	void FlushPrimaryCache(uint8_t x, uint8_t y);
	void WritePixelCache(GsuPixelCache &cache);

	uint8_t GetColor(uint8_t source);

	void Add(uint8_t reg);
	void SubCompare(uint8_t reg);
	void MULT(uint8_t reg);
	void FMultLMult();

	void AndBitClear(uint8_t reg);
	void SBK();

	void LINK(uint8_t reg);

	void SignExtend();

	void NOT();
	void LSR();
	void ROL();
	void ASR();
	void ROR();

	void LOB();
	void HIB();

	void IbtSmsLms(uint8_t reg);
	void IwtLmSm(uint8_t reg);

	void OrXor(uint8_t reg);
	void INC(uint8_t reg);
	void DEC(uint8_t reg);

	void GetCRamBRomB();
	void GETB();

public:
    explicit Gsu(Bus& bus) : _bus(bus) { Reset(); }
    void Reset();
    uint8_t Read(uint32_t addr);
    uint8_t Peek(uint32_t addr) { Gsu copy = *this; return copy.Read(addr); }
    void Write(uint32_t addr, uint8_t value);
    GsuState& GetState();
    uint32_t DebugGetProgramCounter();
    uint8_t MemoryAccessClocks() const {
        if(_bus.FastInternalRam()) return 3; // Conservative instruction model, including RTL RAM-state overhead.
        return static_cast<uint8_t>((_state.ClockSelect ? 5 : 6) * _bus.MemoryClockScale());
    }
    void RunUntil(uint64_t target) {
        while(!_stopped && _state.CycleCount < target) Exec();
        // Upstream Step narrows its delay decrement to uint8_t. Bound idle chunks.
        while(_state.CycleCount < target) Step(std::min<uint64_t>(target - _state.CycleCount, 255));
    }
    uint8_t ReadGsu(uint32_t addr, MemoryOperationType) { return _bus.GsuRead(addr); }
    void WriteGsu(uint32_t addr, uint8_t value, MemoryOperationType) { _bus.GsuWrite(addr, value); }
    template<class S> void Serialize(S& s) {

	s.Stream(_state.CycleCount, "_state.CycleCount"); s.Stream(_state.RegisterLatch, "_state.RegisterLatch"); s.Stream(_state.ProgramBank, "_state.ProgramBank"); s.Stream(_state.RomBank, "_state.RomBank"); s.Stream(_state.RamBank, "_state.RamBank"); s.Stream(_state.IrqDisabled, "_state.IrqDisabled");
	s.Stream(_state.HighSpeedMode, "_state.HighSpeedMode"); s.Stream(_state.ClockSelect, "_state.ClockSelect"); s.Stream(_state.BackupRamEnabled, "_state.BackupRamEnabled"); s.Stream(_state.ScreenBase, "_state.ScreenBase"); s.Stream(_state.ColorGradient, "_state.ColorGradient"); s.Stream(_state.PlotBpp, "_state.PlotBpp");
	s.Stream(_state.ScreenHeight, "_state.ScreenHeight"); s.Stream(_state.GsuRamAccess, "_state.GsuRamAccess"); s.Stream(_state.GsuRomAccess, "_state.GsuRomAccess"); s.Stream(_state.CacheBase, "_state.CacheBase"); s.Stream(_state.PlotTransparent, "_state.PlotTransparent"); s.Stream(_state.PlotDither, "_state.PlotDither");
	s.Stream(_state.ColorHighNibble, "_state.ColorHighNibble"); s.Stream(_state.ColorFreezeHigh, "_state.ColorFreezeHigh"); s.Stream(_state.ObjMode, "_state.ObjMode"); s.Stream(_state.ColorReg, "_state.ColorReg"); s.Stream(_state.SrcReg, "_state.SrcReg"); s.Stream(_state.DestReg, "_state.DestReg");
	s.Stream(_state.RomReadBuffer, "_state.RomReadBuffer"); s.Stream(_state.RomDelay, "_state.RomDelay"); s.Stream(_state.ProgramReadBuffer, "_state.ProgramReadBuffer"); s.Stream(_state.RamWriteAddress, "_state.RamWriteAddress"); s.Stream(_state.RamWriteValue, "_state.RamWriteValue"); s.Stream(_state.RamDelay, "_state.RamDelay");
	s.Stream(_state.RamAddress, "_state.RamAddress"); s.Stream(_state.PrimaryCache.X, "_state.PrimaryCache.X"); s.Stream(_state.PrimaryCache.Y, "_state.PrimaryCache.Y"); s.Stream(_state.PrimaryCache.ValidBits, "_state.PrimaryCache.ValidBits"); s.Stream(_state.SecondaryCache.X, "_state.SecondaryCache.X");
	s.Stream(_state.SecondaryCache.Y, "_state.SecondaryCache.Y"); s.Stream(_state.SecondaryCache.ValidBits, "_state.SecondaryCache.ValidBits");
	s.Stream(_state.SFR.Alt1, "_state.SFR.Alt1"); s.Stream(_state.SFR.Alt2, "_state.SFR.Alt2"); s.Stream(_state.SFR.Carry, "_state.SFR.Carry"); s.Stream(_state.SFR.ImmHigh, "_state.SFR.ImmHigh"); s.Stream(_state.SFR.ImmLow, "_state.SFR.ImmLow"); s.Stream(_state.SFR.Irq, "_state.SFR.Irq"); s.Stream(_state.SFR.Overflow, "_state.SFR.Overflow");
	s.Stream(_state.SFR.Prefix, "_state.SFR.Prefix"); s.Stream(_state.SFR.RomReadPending, "_state.SFR.RomReadPending"); s.Stream(_state.SFR.Running, "_state.SFR.Running"); s.Stream(_state.SFR.Sign, "_state.SFR.Sign"); s.Stream(_state.SFR.Zero, "_state.SFR.Zero");

	s.StreamArray(_state.R, 16, "_state.R");
	s.StreamArray(_state.PrimaryCache.Pixels, 8, "_state.PrimaryCache.Pixels");
	s.StreamArray(_state.SecondaryCache.Pixels, 8, "_state.SecondaryCache.Pixels");

	s.Stream(_waitForRamAccess, "_waitForRamAccess"); s.Stream(_waitForRomAccess, "_waitForRomAccess"); s.Stream(_stopped, "_stopped");
	s.StreamArray(_cacheValid, 32, "_cacheValid");
	s.StreamArray(_cache, 512, "_cache");
	s.Stream(_r15Changed, "_r15Changed"); s.Stream(_lastOpAddr, "_lastOpAddr");

    }
};
inline void Gsu::Exec()
{
	uint8_t opCode = ReadOpCode();

	switch(opCode) {
		case 0x00: STOP(); break;
		case 0x01: NOP(); break;
		case 0x02: CACHE(); break;
		case 0x03: LSR(); break;
		case 0x04: ROL(); break;
		case 0x05: BRA(); break;
		case 0x06: BGE(); break;
		case 0x07: BLT(); break;
		case 0x08: BNE(); break;
		case 0x09: BEQ(); break;
		case 0x0A: BPL(); break;
		case 0x0B: BMI(); break;
		case 0x0C: BCC(); break;
		case 0x0D: BCS(); break;
		case 0x0E: BVC(); break;
		case 0x0F: BVS(); break;

		case 0x10: case 0x11: case 0x12: case 0x13: case 0x14: case 0x15: case 0x16: case 0x17:
		case 0x18: case 0x19: case 0x1A: case 0x1B: case 0x1C: case 0x1D: case 0x1E: case 0x1F:
			TO(opCode & 0x0F);
			break;

		case 0x20: case 0x21: case 0x22: case 0x23: case 0x24: case 0x25: case 0x26: case 0x27:
		case 0x28: case 0x29: case 0x2A: case 0x2B: case 0x2C: case 0x2D: case 0x2E: case 0x2F:
			WITH(opCode & 0x0F);
			break;

		case 0x30: case 0x31: case 0x32: case 0x33: case 0x34: case 0x35: case 0x36: case 0x37:
		case 0x38: case 0x39: case 0x3A: case 0x3B:
			STORE(opCode & 0x0F);
			break;

		case 0x3C: LOOP(); break;
		case 0x3D: ALT1(); break;
		case 0x3E: ALT2(); break;
		case 0x3F: ALT3(); break;

		case 0x40: case 0x41: case 0x42: case 0x43: case 0x44: case 0x45: case 0x46: case 0x47:
		case 0x48: case 0x49: case 0x4A: case 0x4B:
			LOAD(opCode & 0x0F);
			break;

		case 0x4C: PlotRpix(); break;
		case 0x4D: SWAP(); break;
		case 0x4E: ColorCMode(); break;
		case 0x4F: NOT(); break;

		case 0x50: case 0x51: case 0x52: case 0x53: case 0x54: case 0x55: case 0x56: case 0x57:
		case 0x58: case 0x59: case 0x5A: case 0x5B: case 0x5C: case 0x5D: case 0x5E: case 0x5F:
			Add(opCode & 0x0F);
			break;

		case 0x60: case 0x61: case 0x62: case 0x63: case 0x64: case 0x65: case 0x66: case 0x67:
		case 0x68: case 0x69: case 0x6A: case 0x6B: case 0x6C: case 0x6D: case 0x6E: case 0x6F:
			SubCompare(opCode & 0x0F);
			break;

		case 0x70: MERGE(); break;

		case 0x71: case 0x72: case 0x73: case 0x74: case 0x75: case 0x76: case 0x77:
		case 0x78: case 0x79: case 0x7A: case 0x7B: case 0x7C: case 0x7D: case 0x7E: case 0x7F:
			AndBitClear(opCode & 0x0F);
			break;

		case 0x80: case 0x81: case 0x82: case 0x83: case 0x84: case 0x85: case 0x86: case 0x87:
		case 0x88: case 0x89: case 0x8A: case 0x8B: case 0x8C: case 0x8D: case 0x8E: case 0x8F:
			MULT(opCode & 0x0F);
			break;

		case 0x90: SBK(); break;

		case 0x91: LINK(1); break;
		case 0x92: LINK(2); break;
		case 0x93: LINK(3); break;
		case 0x94: LINK(4); break;

		case 0x95: SignExtend(); break;

		case 0x96: ASR(); break;
		case 0x97: ROR(); break;

		case 0x98: case 0x99: case 0x9A: case 0x9B: case 0x9C: case 0x9D:
			JMP(opCode & 0x0F);
			break;

		case 0x9E: LOB(); break;
		case 0x9F: FMultLMult(); break;

		case 0xA0: case 0xA1: case 0xA2: case 0xA3: case 0xA4: case 0xA5: case 0xA6: case 0xA7:
		case 0xA8: case 0xA9: case 0xAA: case 0xAB: case 0xAC: case 0xAD: case 0xAE: case 0xAF:
			IbtSmsLms(opCode & 0x0F);
			break;

		case 0xB0: case 0xB1: case 0xB2: case 0xB3: case 0xB4: case 0xB5: case 0xB6: case 0xB7:
		case 0xB8: case 0xB9: case 0xBA: case 0xBB: case 0xBC: case 0xBD: case 0xBE: case 0xBF:
			FROM(opCode & 0x0F);
			break;

		case 0xC0: HIB(); break;

		case 0xC1: case 0xC2: case 0xC3: case 0xC4: case 0xC5: case 0xC6: case 0xC7:
		case 0xC8: case 0xC9: case 0xCA: case 0xCB: case 0xCC: case 0xCD: case 0xCE: case 0xCF:
			OrXor(opCode & 0x0F);
			break;

		case 0xD0: case 0xD1: case 0xD2: case 0xD3: case 0xD4: case 0xD5: case 0xD6: case 0xD7:
		case 0xD8: case 0xD9: case 0xDA: case 0xDB: case 0xDC: case 0xDD: case 0xDE:
			INC(opCode & 0x0F);
			break;

		case 0xDF: GetCRamBRomB(); break;

		case 0xE0: case 0xE1: case 0xE2: case 0xE3: case 0xE4: case 0xE5: case 0xE6: case 0xE7:
		case 0xE8: case 0xE9: case 0xEA: case 0xEB: case 0xEC: case 0xED: case 0xEE:
			DEC(opCode & 0x0F);
			break;

		case 0xEF: GETB(); break;

		case 0xF0: case 0xF1: case 0xF2: case 0xF3: case 0xF4: case 0xF5: case 0xF6: case 0xF7:
		case 0xF8: case 0xF9: case 0xFA: case 0xFB: case 0xFC: case 0xFD: case 0xFE: case 0xFF:
			IwtLmSm(opCode & 0x0F);
			break;
	}

	if(_state.SFR.Running) {
	}

	if(!_r15Changed) {
		_state.R[15]++;
	} else {
		_r15Changed = false;
	}
}

inline void Gsu::InitProgramCache(uint16_t cacheAddr)
{
	uint16_t dest = (cacheAddr & 0x01F0);
	
	if(_state.ProgramBank <= 0x5F) {
		WaitRomOperation();
		WaitForRomAccess();
	} else {
		WaitRamOperation();
		WaitForRamAccess();
	}
	
	uint32_t srcBaseAddr = (_state.ProgramBank << 16) + _state.CacheBase + dest;
	for(int i = 0; i < 16; i++) {
		_cache[dest + i] = ReadGsu(srcBaseAddr + i, MemoryOperationType::Read);
	}
	Step((_bus.FastInternalRam() ? 26 : 16 * MemoryAccessClocks()));

	_cacheValid[cacheAddr >> 4] = true;
}

inline uint8_t Gsu::ReadOperand()
{
	uint8_t result = _state.ProgramReadBuffer;
	_state.R[15]++;
	_state.ProgramReadBuffer = ReadProgramByte(MemoryOperationType::ExecOperand);
	return result;
}

inline uint8_t Gsu::ReadOpCode()
{
	uint8_t result = _state.ProgramReadBuffer;
	_state.ProgramReadBuffer = ReadProgramByte(MemoryOperationType::ExecOpCode);
	return result;
}

inline uint8_t Gsu::ReadProgramByte(MemoryOperationType opType)
{
	_lastOpAddr = (_state.ProgramBank << 16) | _state.R[15];
	uint16_t cacheAddr = _state.R[15] - _state.CacheBase;
	if(cacheAddr < 512) {
		if(!_cacheValid[cacheAddr >> 4]) {
			InitProgramCache(cacheAddr & 0xFFF0);
		}
		
		Step(_state.ClockSelect ? 1 : 2);
		return _cache[cacheAddr];
	} else {
		if(_state.ProgramBank <= 0x5F) {
			WaitRomOperation();
			WaitForRomAccess();
		} else {
			WaitRamOperation();
			WaitForRamAccess();
		}
		Step(MemoryAccessClocks());
		return ReadGsu(_lastOpAddr, opType);
	}
}

inline uint16_t Gsu::ReadSrcReg()
{
	return _state.R[_state.SrcReg];
}

inline void Gsu::WriteDestReg(uint16_t value)
{
	WriteRegister(_state.DestReg, value);
}

inline void Gsu::WriteRegister(uint8_t reg, uint16_t value)
{
	_state.R[reg] = value;
	
	if(reg == 14) {
		_state.SFR.RomReadPending = true;
		_state.RomDelay = MemoryAccessClocks();
	} else if(reg == 15) {
		_r15Changed = true;
	}
}

inline void Gsu::ResetFlags()
{
	_state.SFR.Prefix = 0;
	_state.SFR.Alt1 = false;
	_state.SFR.Alt2 = false;

	_state.SrcReg = 0;
	_state.DestReg = 0;
}

inline void Gsu::InvalidateCache()
{
	memset(_cacheValid, 0, sizeof(_cacheValid));
}

inline void Gsu::WaitRomOperation()
{
	if(_state.RomDelay) {
		//Wait for existing RAM operation to complete
		Step(_state.RomDelay);
	}
}

inline void Gsu::WaitRamOperation()
{
	if(_state.RamDelay) {
		//Wait for existing RAM operation to complete
		Step(_state.RamDelay);
	}
}

inline void Gsu::WaitForRomAccess()
{
	if(!_state.GsuRomAccess) {
		_waitForRomAccess = true;
		_stopped = true;
	}
}

inline void Gsu::WaitForRamAccess()
{
	if(!_state.GsuRamAccess) {
		_waitForRamAccess = true;
		_stopped = true;
	}
}

inline void Gsu::UpdateRunningState()
{
	_stopped = !_state.SFR.Running || _waitForRamAccess || _waitForRomAccess;
}

inline uint8_t Gsu::ReadRomBuffer()
{
	WaitRomOperation();
	return _state.RomReadBuffer;
}

inline uint8_t Gsu::ReadRamBuffer(uint16_t addr)
{
	WaitRamOperation();
	WaitForRamAccess();
	return ReadGsu(0x700000 | (_state.RamBank << 16) | addr, MemoryOperationType::Read);
}

inline void Gsu::WriteRam(uint16_t addr, uint8_t value)
{
	WaitRamOperation();

	_state.RamDelay = MemoryAccessClocks();
	_state.RamWriteAddress = addr;
	_state.RamWriteValue = value;
}

inline void Gsu::Step(uint64_t cycles)
{
	_state.CycleCount += cycles;

	if(_state.RomDelay) {
		_state.RomDelay -= std::min<uint8_t>((uint8_t)cycles, _state.RomDelay);
		if(_state.RomDelay == 0) {
			WaitForRomAccess();
			_state.RomReadBuffer = ReadGsu((_state.RomBank << 16) | _state.R[14], MemoryOperationType::Read);
			_state.SFR.RomReadPending = false;
		}
	}

	if(_state.RamDelay) {
		_state.RamDelay -= std::min<uint8_t>((uint8_t)cycles, _state.RamDelay);
		if(_state.RamDelay == 0) {
			WaitForRamAccess();
			WriteGsu(0x700000 | (_state.RamBank << 16) | _state.RamWriteAddress, _state.RamWriteValue, MemoryOperationType::Write);
		}
	}
}

inline void Gsu::Reset()
{
	_state = {};
	_state.ProgramReadBuffer = 0x01; //Run a NOP on first cycle
	
	memset(_cache, 0, sizeof(_cache));
	_r15Changed = false;
	memset(_cacheValid, 0, sizeof(_cacheValid));
	_waitForRomAccess = false;
	_waitForRamAccess = false;
	_stopped = true;
	_lastOpAddr = 0;
}

inline uint8_t Gsu::Read(uint32_t addr)
{
	addr &= 0x33FF;
	if(_state.SFR.Running && addr != 0x3030 && addr != 0x3031 && addr != 0x303B) {
		//"During GSU operation, only SFR, SCMR, and VCR may be accessed."
		return 0;
	}

	switch(addr) {
		case 0x3000: case 0x3002: case 0x3004: case 0x3006: case 0x3008: case 0x300A: case 0x300C:case 0x300E:
		case 0x3010: case 0x3012: case 0x3014: case 0x3016: case 0x3018: case 0x301A: case 0x301C:case 0x301E:
			return (uint8_t)_state.R[(addr >> 1) & 0x0F];

		case 0x3001: case 0x3003: case 0x3005: case 0x3007: case 0x3009: case 0x300B: case 0x300D:case 0x300F:
		case 0x3011: case 0x3013: case 0x3015: case 0x3017: case 0x3019: case 0x301B: case 0x301D:case 0x301F:
			return _state.R[(addr >> 1) & 0x0F] >> 8;

		case 0x3030: return _state.SFR.GetFlagsLow();
		case 0x3031: {
			uint8_t flags = _state.SFR.GetFlagsHigh();
			_state.SFR.Irq = false;
			// IRQ level is SFR.Irq; host observes it.
			return flags;
		}

		case 0x3034: return _state.ProgramBank;
		case 0x3036: return _state.RomBank;
		case 0x303B: return 0x04; //Version (can be 1 or 4?)
		case 0x303C: return _state.RamBank;
		case 0x303E: return (uint8_t)_state.CacheBase;
		case 0x303F: return _state.CacheBase >> 8;
	}
	
	if(addr >= 0x3100 && addr <= 0x32FF) {
		return _cache[(_state.CacheBase + (addr - 0x3100)) & 0x1FF];
	}

	//TODO open bus and proper mirroring?
	return 0;
}

inline void Gsu::Write(uint32_t addr, uint8_t value)
{
	addr &= 0x33FF;
	if(_state.SFR.Running && addr != 0x3030 && addr != 0x303A) {
		//"During GSU operation, only SFR, SCMR, and VCR may be accessed."
		return;
	}

	switch(addr) {
		case 0x3000: case 0x3002: case 0x3004: case 0x3006: case 0x3008: case 0x300A: case 0x300C: case 0x300E:
		case 0x3010: case 0x3012: case 0x3014: case 0x3016: case 0x3018: case 0x301A: case 0x301C: case 0x301E:
			_state.RegisterLatch = value;
			break;

		case 0x3001: case 0x3003: case 0x3005: case 0x3007: case 0x3009: case 0x300B: case 0x300D: case 0x300F:
		case 0x3011: case 0x3013: case 0x3015: case 0x3017: case 0x3019: case 0x301B: case 0x301D: case 0x301F: {
			uint8_t reg = (addr >> 1) & 0x0F;
			_state.R[reg] = (value << 8) | _state.RegisterLatch;
			
			if(reg == 14) {
				_state.SFR.RomReadPending = true;
				_state.RomDelay = MemoryAccessClocks();
			} else if(addr == 0x301F) {
				_state.SFR.Running = true;
				UpdateRunningState();
			}
			break;
		}

		case 0x3030: {
			bool running = _state.SFR.Running;
			_state.SFR.Zero = (value & 0x02) != 0;
			_state.SFR.Carry = (value & 0x04) != 0;
			_state.SFR.Sign = (value & 0x08) != 0;
			_state.SFR.Overflow = (value & 0x10) != 0;
			_state.SFR.Running = (value & 0x20) != 0;

			if(running && !_state.SFR.Running) {
				_state.CacheBase = 0;
				InvalidateCache();
			}
			UpdateRunningState();
			break;
		}

		case 0x3033: _state.BackupRamEnabled = (value & 0x01); break;
		case 0x3034: _state.ProgramBank = (value & 0x7F); InvalidateCache(); break;
		
		case 0x3037:
			_state.HighSpeedMode = (value & 0x20) != 0;
			_state.IrqDisabled = (value & 0x80) != 0;
			break;

		case 0x3038: _state.ScreenBase = value; break;
		case 0x3039: _state.ClockSelect = (value & 0x01); break;

		case 0x303A:
			_state.ColorGradient = (value & 0x03);
			switch(_state.ColorGradient) {
				case 0: _state.PlotBpp = 2; break;
				case 1: _state.PlotBpp = 4; break;
				case 2: _state.PlotBpp = 4; break;
				case 3: _state.PlotBpp = 8; break;
			}
			_state.ScreenHeight = ((value & 0x04) >> 2) | ((value & 0x20) >> 4);
			_state.GsuRamAccess = (value & 0x08) != 0;
			_state.GsuRomAccess = (value & 0x10) != 0;

			if(_state.GsuRamAccess) {
				_waitForRamAccess = false;
			}
			if(_state.GsuRomAccess) {
				_waitForRomAccess = false;
			}
			UpdateRunningState();
			break;
	}

	if(addr >= 0x3100 && addr <= 0x32FF) {
		uint16_t cacheAddr = (_state.CacheBase + (addr - 0x3100)) & 0x1FF;
		_cache[cacheAddr] = value;
		if((cacheAddr & 0x0F) == 0x0F) {
			_cacheValid[cacheAddr >> 4] = true;
		}
	}
}

inline GsuState& Gsu::GetState()
{
	return _state;
}

inline uint32_t Gsu::DebugGetProgramCounter()
{
	return _lastOpAddr;
}

inline void Gsu::STOP()
{
	_state.SFR.Irq = true;
	_state.ProgramReadBuffer = 0x01; //Run a NOP first when the GSU is restarted
	_state.SFR.Running = false;
	ResetFlags();

	UpdateRunningState();
}

inline void Gsu::NOP()
{
	ResetFlags();
}

inline void Gsu::CACHE()
{
	if(_state.CacheBase != (_state.R[15] & 0xFFF0)) {
		_state.CacheBase = _state.R[15] & 0xFFF0;
		InvalidateCache();
	}
	ResetFlags();
}

inline void Gsu::Branch(bool branch)
{
	int8_t offset = (int8_t)ReadOperand();
	if(branch) {
		WriteRegister(15, _state.R[15] + offset);
	}
}

inline void Gsu::BRA()
{
	Branch(true);
}

inline void Gsu::BLT()
{
	Branch(_state.SFR.Sign != _state.SFR.Overflow);
}

inline void Gsu::BGE()
{
	Branch(_state.SFR.Sign == _state.SFR.Overflow);
}

inline void Gsu::BNE()
{
	Branch(!_state.SFR.Zero);
}

inline void Gsu::BEQ()
{
	Branch(_state.SFR.Zero);
}

inline void Gsu::BPL()
{
	Branch(!_state.SFR.Sign);
}

inline void Gsu::BMI()
{
	Branch(_state.SFR.Sign);
}

inline void Gsu::BCC()
{
	Branch(!_state.SFR.Carry);
}

inline void Gsu::BCS()
{
	Branch(_state.SFR.Carry);
}

inline void Gsu::BVC()
{
	Branch(!_state.SFR.Overflow);
}

inline void Gsu::BVS()
{
	Branch(_state.SFR.Overflow);
}

inline void Gsu::JMP(uint8_t reg)
{
	if(_state.SFR.Alt1) {
		//LJMP
		_state.ProgramBank = _state.R[reg] & 0x7F;
		WriteRegister(15, ReadSrcReg());
		
		_state.CacheBase = _state.R[15] & 0xFFF0;
		InvalidateCache();
	} else {
		//JMP
		WriteRegister(15, _state.R[reg]);
	}
	ResetFlags();
}

inline void Gsu::TO(uint8_t reg)
{
	if(_state.SFR.Prefix) {
		//MOVE
		WriteRegister(reg, ReadSrcReg());
		ResetFlags();
	} else {
		//TO
		_state.DestReg = reg;
	}
}

inline void Gsu::FROM(uint8_t reg)
{
	if(_state.SFR.Prefix) {
		//MOVES
		WriteDestReg(_state.R[reg]);
		_state.SFR.Overflow = (_state.R[reg] & 0x80) != 0;
		_state.SFR.Sign = (_state.R[reg] & 0x8000) != 0;
		_state.SFR.Zero = (_state.R[reg] == 0);
		ResetFlags();
	} else {
		//FROM
		_state.SrcReg = reg;
	}
}

inline void Gsu::WITH(uint8_t reg)
{
	_state.SrcReg = reg;
	_state.DestReg = reg;
	_state.SFR.Prefix = true;
}

inline void Gsu::STORE(uint8_t reg)
{
	_state.RamAddress = _state.R[reg];
	WriteRam(_state.RamAddress, (uint8_t)ReadSrcReg());
	if(!_state.SFR.Alt1) {
		WriteRam(_state.RamAddress ^ 0x01, ReadSrcReg() >> 8);
	}
	ResetFlags();
}

inline void Gsu::LOAD(uint8_t reg)
{
	_state.RamAddress = _state.R[reg];
	uint16_t value = ReadRamBuffer(_state.RamAddress);
	if(!_state.SFR.Alt1) {
		value |= ReadRamBuffer(_state.RamAddress ^ 0x01) << 8;
	}
	WriteDestReg(value);
	ResetFlags();
}

inline void Gsu::LOOP()
{
	_state.R[12]--;
	_state.SFR.Zero = (_state.R[12] == 0);
	_state.SFR.Sign = (_state.R[12] & 0x8000) != 0;
	
	//Loop until counter hits zero
	if(!_state.SFR.Zero) {
		WriteRegister(15, _state.R[13]);
	}

	ResetFlags();
}

inline void Gsu::ALT1()
{
	_state.SFR.Prefix = false;
	_state.SFR.Alt1 = true;
}

inline void Gsu::ALT2()
{
	_state.SFR.Prefix = false;
	_state.SFR.Alt2 = true;
}

inline void Gsu::ALT3()
{
	_state.SFR.Prefix = false;
	_state.SFR.Alt1 = true;
	_state.SFR.Alt2 = true;
}

inline void Gsu::MERGE()
{
	uint16_t value = (_state.R[7] & 0xFF00) | (_state.R[8] >> 8);
	WriteDestReg(value);
	_state.SFR.Carry = (value & 0xE0E0) != 0;
	_state.SFR.Overflow = (value & 0xC0C0) != 0;
	_state.SFR.Sign = (value & 0x8080) != 0;
	_state.SFR.Zero = (value & 0xF0F0) != 0;
	ResetFlags();
}

inline void Gsu::SWAP()
{
	uint16_t value = (ReadSrcReg() >> 8) | (ReadSrcReg() << 8);
	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::Add(uint8_t reg)
{
	uint16_t operand;
	if(_state.SFR.Alt2) {
		//Immediate value
		operand = reg;
	} else {
		operand = _state.R[reg];
	}

	uint32_t result = ReadSrcReg() + operand;
	if(_state.SFR.Alt1) {
		//ADC - Add with carry
		result += (uint8_t)_state.SFR.Carry;
	}

	_state.SFR.Carry = (result & 0x10000) != 0;
	_state.SFR.Overflow = ~(ReadSrcReg() ^ operand) & (operand ^ result) & 0x8000;
	_state.SFR.Sign = (result & 0x8000) != 0;
	_state.SFR.Zero = (result & 0xFFFF) == 0;

	WriteDestReg(result);
	ResetFlags();
}

inline void Gsu::SubCompare(uint8_t reg)
{
	uint16_t operand;
	if(_state.SFR.Alt2 && !_state.SFR.Alt1) {
		//Immediate value, SUB #val
		operand = reg;
	} else {
		operand = _state.R[reg];
	}

	int32_t result = ReadSrcReg() - operand;
	if(!_state.SFR.Alt2 && _state.SFR.Alt1) {
		//SBC - SUB with carry
		result -= _state.SFR.Carry ? 0 : 1;
	}

	_state.SFR.Carry = (result >= 0);
	_state.SFR.Overflow = ((ReadSrcReg() ^ operand) & (ReadSrcReg() ^ result) & 0x8000) != 0;
	_state.SFR.Sign = (result & 0x8000) != 0;
	_state.SFR.Zero = (result & 0xFFFF) == 0;

	if(!_state.SFR.Alt2 || !_state.SFR.Alt1) {
		//SUB/SBC, other CMP (and no write occurs for CMP)
		WriteDestReg(result);
	}
	ResetFlags();
}

inline void Gsu::MULT(uint8_t reg)
{
	uint16_t operand;
	if(_state.SFR.Alt2) {
		//Immediate value
		operand = reg;
	} else {
		operand = _state.R[reg];
	}

	uint16_t value;
	if(_state.SFR.Alt1) {
		//UMULT - Unsigned multiply
		value = (uint16_t)((uint8_t)ReadSrcReg() * (uint8_t)operand);
	} else {
		//MULT - Signed multiply
		value = (uint16_t)((int8_t)ReadSrcReg() * (int8_t)operand);
	}
	
	WriteDestReg(value);
	_state.SFR.Sign = (value & 0x8000) != 0;
	_state.SFR.Zero = value == 0;

	ResetFlags();

	if(!_bus.FastInternalRam()) Step(_state.HighSpeedMode ? 1 : 2);
}

inline void Gsu::FMultLMult()
{
	uint32_t multResult = (int16_t)ReadSrcReg() * (int16_t)_state.R[6];

	if(_state.SFR.Alt1) {
		//LMULT - "16x16 signed multiply", LSB in R4, MSB in DREG
		_state.R[4] = multResult;
	}

	uint16_t value = multResult >> 16;
	WriteDestReg(value);

	_state.SFR.Carry = (multResult & 0x8000);
	_state.SFR.Sign = (value & 0x8000);
	_state.SFR.Zero = (value == 0);
	ResetFlags();

	if(!_bus.FastInternalRam()) Step((_state.HighSpeedMode ? 3 : 7) * (_state.ClockSelect ? 1 : 2));
}

inline void Gsu::AndBitClear(uint8_t reg)
{
	uint16_t operand;
	if(_state.SFR.Alt2) {
		//Immediate value
		operand = reg;
	} else {
		operand = _state.R[reg];
	}

	uint16_t value;
	if(_state.SFR.Alt1) {
		//Bit clear
		value = ReadSrcReg() & ~operand;
	} else {
		//AND
		value = ReadSrcReg() & operand;
	}

	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::SBK()
{
	//"Store word data, last RAM address used"
	WriteRam(_state.RamAddress, (uint8_t)ReadSrcReg());
	WriteRam(_state.RamAddress ^ 1, ReadSrcReg() >> 8);
	ResetFlags();
}

inline void Gsu::LINK(uint8_t value)
{
	//"Link Return Address"
	_state.R[11] = _state.R[15] + value;
	ResetFlags();
}

inline void Gsu::SignExtend()
{
	int16_t value = (int8_t)ReadSrcReg();
	WriteDestReg((uint16_t)value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::NOT()
{
	uint16_t value = ~ReadSrcReg();
	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::LSR()
{
	uint16_t src = ReadSrcReg();
	_state.SFR.Carry = (src & 0x01) != 0;
	
	uint16_t dst = src >> 1;
	WriteDestReg(dst);
	_state.SFR.Zero = dst == 0;
	_state.SFR.Sign = (dst & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::ROL()
{
	uint16_t src = ReadSrcReg();

	uint16_t dst = (src << 1) | (uint8_t)_state.SFR.Carry;
	_state.SFR.Carry = (src & 0x8000) != 0;

	WriteDestReg(dst);
	_state.SFR.Zero = dst == 0;
	_state.SFR.Sign = (dst & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::ASR()
{
	uint16_t src = ReadSrcReg();
	_state.SFR.Carry = (src & 0x01) != 0;

	uint16_t dst = (int16_t)src >> 1;
	if(_state.SFR.Alt1) {
		dst += (src + 1) >> 16;
	}

	WriteDestReg(dst);
	_state.SFR.Zero = dst == 0;
	_state.SFR.Sign = (dst & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::ROR()
{
	uint16_t src = ReadSrcReg();
	
	uint16_t dst = (src >> 1) | ((int)_state.SFR.Carry << 15);
	_state.SFR.Carry = (src & 0x01) != 0;

	WriteDestReg(dst);
	_state.SFR.Zero = dst == 0;
	_state.SFR.Sign = (dst & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::LOB()
{
	//"Value of low byte of register"
	uint8_t value = (uint8_t)ReadSrcReg();
	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x80) != 0;
	ResetFlags();
}

inline void Gsu::HIB()
{
	//"Value of high byte of register"
	uint8_t value = (uint8_t)(ReadSrcReg() >> 8);
	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x80) != 0;
	ResetFlags();
}

inline void Gsu::IbtSmsLms(uint8_t reg)
{
	if(_state.SFR.Alt1) {
		//LMS - "Load word data from RAM, short address"
		_state.RamAddress = ReadOperand() << 1;
		uint8_t lsb = ReadRamBuffer(_state.RamAddress);
		uint8_t msb = ReadRamBuffer(_state.RamAddress | 0x01);

		WriteRegister(reg, (msb << 8) | lsb);
	} else if(_state.SFR.Alt2) {
		//SMS - "Store word data to RAM, short address"
		_state.RamAddress = ReadOperand() << 1;
		WriteRam(_state.RamAddress, (uint8_t)_state.R[reg]);
		WriteRam(_state.RamAddress | 0x01, _state.R[reg] >> 8);
	} else {
		//IBT - "Load immediate byte data"
		WriteRegister(reg, (int8_t)ReadOperand());
	}
	ResetFlags();
}

inline void Gsu::IwtLmSm(uint8_t reg)
{
	if(_state.SFR.Alt1) {
		//LM - Load memory
		_state.RamAddress = ReadOperand();
		_state.RamAddress |= ReadOperand() << 8;

		uint8_t lsb = ReadRamBuffer(_state.RamAddress);
		uint8_t msb = ReadRamBuffer(_state.RamAddress ^ 0x01);
		WriteRegister(reg, (msb << 8) | lsb);
	} else if(_state.SFR.Alt2) {
		//SM - Store Memory
		_state.RamAddress = ReadOperand();
		_state.RamAddress |= ReadOperand() << 8;

		WriteRam(_state.RamAddress, (uint8_t)_state.R[reg]);
		WriteRam(_state.RamAddress ^ 0x01, _state.R[reg] >> 8);
	} else {
		//IWT - Load immediate word
		uint8_t lsb = ReadOperand();
		uint8_t msb = ReadOperand();
		WriteRegister(reg, (msb << 8) | lsb);
	}
	ResetFlags();
}

inline void Gsu::OrXor(uint8_t operand)
{
	uint16_t operandValue;
	if(_state.SFR.Alt2) {
		//Immediate value
		operandValue = operand;
	} else {
		//Indirect register value
		operandValue = _state.R[operand];
	}

	uint16_t value;
	if(_state.SFR.Alt1) {
		//XOR
		value = ReadSrcReg() ^ operandValue;
	} else {
		//OR
		value = ReadSrcReg() | operandValue;
	}
	WriteDestReg(value);
	_state.SFR.Zero = value == 0;
	_state.SFR.Sign = (value & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::INC(uint8_t reg)
{
	WriteRegister(reg, _state.R[reg] + 1);
	_state.SFR.Zero = _state.R[reg] == 0;
	_state.SFR.Sign = (_state.R[reg] & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::DEC(uint8_t reg)
{
	WriteRegister(reg, _state.R[reg] - 1);
	_state.SFR.Zero = _state.R[reg] == 0;
	_state.SFR.Sign = (_state.R[reg] & 0x8000) != 0;
	ResetFlags();
}

inline void Gsu::GetCRamBRomB()
{
	if(!_state.SFR.Alt2) {
		//GETC - "Get byte from ROM to color register"
		_state.ColorReg = GetColor(ReadRomBuffer());
	} else if(!_state.SFR.Alt1) {
		//RAMB - "Set RAM data bank"
		WaitRamOperation();
		_state.RamBank = ReadSrcReg() & 0x01;
	} else {
		//ROMB - "Set ROM data bank"
		WaitRomOperation();
		_state.RomBank = ReadSrcReg() & 0x7F;
	}
	ResetFlags();
}

inline void Gsu::GETB()
{
	if(_state.SFR.Alt2 && _state.SFR.Alt1) {
		//GETBS - "Get signed byte from ROM buffer"
		WriteDestReg((int8_t)ReadRomBuffer());
	} else if(_state.SFR.Alt2) {
		//GETBL - "Get low byte from ROM buffer"
		WriteDestReg((ReadSrcReg() & 0xFF00) | ReadRomBuffer());
	} else if(_state.SFR.Alt1) {
		//GETBH - "Get high byte from ROM buffer"
		WriteDestReg((ReadSrcReg() & 0xFF) | (ReadRomBuffer() << 8));
	} else {
		//GETB - "Get byte from ROM buffer"
		WriteDestReg(ReadRomBuffer());
	}
	ResetFlags();
}

inline void Gsu::PlotRpix()
{
	if(_state.SFR.Alt1) {
		//RPIX - "Read pixel color"
		uint8_t value = ReadPixel((uint8_t)_state.R[1], (uint8_t)_state.R[2]);
		_state.SFR.Zero = (value == 0);
		_state.SFR.Sign = (value & 0x8000);
		WriteDestReg(value);
	} else {
		//PLOT
		DrawPixel((uint8_t)_state.R[1], (uint8_t)_state.R[2]);
		_state.R[1]++;
	}
	ResetFlags();
}

inline void Gsu::ColorCMode()
{
	if(_state.SFR.Alt1) {
		//CMODE - "Set plot mode"
		uint8_t value = (uint8_t)ReadSrcReg();
		_state.PlotTransparent = (value & 0x01) != 0;
		_state.PlotDither = (value & 0x02) != 0;
		_state.ColorHighNibble = (value & 0x04) != 0;
		_state.ColorFreezeHigh = (value & 0x08) != 0;
		_state.ObjMode = (value & 0x10) != 0;
	} else {
		//COLOR - "Set plot color"
		_state.ColorReg = GetColor((uint8_t)ReadSrcReg());
	}
	ResetFlags();
}

inline uint16_t Gsu::GetTileIndex(uint8_t x, uint8_t y)
{
	switch(_state.ObjMode ? 3 : _state.ScreenHeight) {
		default:
		case 0: return ((x & 0xF8) << 1) + ((y & 0xF8) >> 3); break;
		case 1: return ((x & 0xF8) << 1) + ((x & 0xF8) >> 1) + ((y & 0xF8) >> 3); break;
		case 2: return ((x & 0xF8) << 1) + ((x & 0xF8) << 0) + ((y & 0xF8) >> 3); break;
		case 3: return ((y & 0x80) << 2) + ((x & 0x80) << 1) + ((y & 0x78) << 1) + ((x & 0x78) >> 3); break;
	}
}

inline uint32_t Gsu::GetTileAddress(uint8_t x, uint8_t y)
{
	uint16_t tileIndex = GetTileIndex(x, y);
	return (0x700000 | (_state.ScreenBase << 10)) + (tileIndex * (_state.PlotBpp << 3)) + ((y & 0x07) * 2);
}

inline uint8_t Gsu::ReadPixel(uint8_t x, uint8_t y)
{
	WritePixelCache(_state.SecondaryCache);
	WritePixelCache(_state.PrimaryCache);

	uint32_t tileAddress = GetTileAddress(x, y);
	
	x = (x & 7) ^ 7;

	uint8_t data = 0;
	for(int i = 0; i < _state.PlotBpp; i++) {
		//Select which byte to read/write based on the current bit (0/1, 16/17, 32/33, 48/49)
		uint8_t byteOffset = ((i >> 1) << 4) + (i & 0x01);
		data |= ((ReadGsu(tileAddress + byteOffset, MemoryOperationType::Read) >> x) & 1) << i;
		Step(MemoryAccessClocks());
	}

	return data;
}

inline bool Gsu::IsTransparentPixel()
{
	uint8_t color = _state.ColorFreezeHigh ? (_state.ColorReg & 0x0F) : _state.ColorReg;

	switch(_state.PlotBpp) {
		default:
		case 2: return (color & 0x03) == 0;
		case 4: return (color & 0x0F) == 0;
		case 8: return color == 0;
	}
}

inline void Gsu::DrawPixel(uint8_t x, uint8_t y)
{
	if(!_state.PlotTransparent && IsTransparentPixel()) {
		return;
	}

	uint8_t color = _state.ColorReg;
	if(_state.PlotDither && _state.PlotBpp != 8) {
		if((x ^ y) & 0x01) {
			color >>= 4;
		}
		color &= 0x0F;
	}

	if(_state.PrimaryCache.X != (x & 0xF8) || _state.PrimaryCache.Y != y) {
		FlushPrimaryCache(x, y);
	}

	uint8_t xOffset = (x & 7) ^ 7;
	_state.PrimaryCache.Pixels[xOffset] = color;
	_state.PrimaryCache.ValidBits |= (1 << xOffset);
	if(_state.PrimaryCache.ValidBits == 0xFF) {
		FlushPrimaryCache(x, y);
	}
}

inline void Gsu::FlushPrimaryCache(uint8_t x, uint8_t y)
{
	WritePixelCache(_state.SecondaryCache);
	_state.SecondaryCache = _state.PrimaryCache;
	_state.PrimaryCache.ValidBits = 0;
	_state.PrimaryCache.X = x & 0xF8;
	_state.PrimaryCache.Y = y;
}

inline void Gsu::WritePixelCache(GsuPixelCache &cache)
{
	if(cache.ValidBits == 0) {
		return;
	}

	uint32_t tileAddress = GetTileAddress(cache.X, cache.Y);

	for(int i = 0; i < _state.PlotBpp; i++) {
		uint8_t value = 0;
		for(int x = 0; x < 8; x++) {
			value |= ((cache.Pixels[x] >> i) & 0x01) << x;
		}

		//Select which byte to read/write based on the current bit (0/1, 16/17, 32/33, 48/49)
		uint8_t byte = ((i >> 1) << 4) + (i & 0x01);

		if(cache.ValidBits != 0xFF) {
			//Read the pixels in memory before to merge them before writing the cache's content to memory
			Step(MemoryAccessClocks());
			value &= cache.ValidBits;
			value |= ReadGsu(tileAddress + byte, MemoryOperationType::Read) & ~cache.ValidBits;
		}

		Step(MemoryAccessClocks());
		WaitForRamAccess();
		WriteGsu(tileAddress + byte, value, MemoryOperationType::Write);
	}

	cache.ValidBits = 0;
}

inline uint8_t Gsu::GetColor(uint8_t value)
{
	if(_state.ColorHighNibble) {
		return (_state.ColorReg & 0xF0) | (value >> 4);
	}
	if(_state.ColorFreezeHigh) {
		return (_state.ColorReg & 0xF0) | (value & 0x0F);
	}

	return value;
}
}
