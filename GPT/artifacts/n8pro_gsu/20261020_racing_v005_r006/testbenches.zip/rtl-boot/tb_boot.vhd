-- SPDX-License-Identifier: GPL-3.0-or-later
-- Functional subset of 6502 sufficient to execute the actual diagnostic ROM.
-- Bus cycles are explicit; PPU status is stubbed. This is not a console emulator.
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use std.env.all;
entity tb_racing_boot is generic(mapper_present : boolean := true); end;
architecture test of tb_racing_boot is
  type rom_t is array(0 to 1048575) of std_logic_vector(7 downto 0);
  impure function load_rom return rom_t is
    file f : text open read_mode is "prg.hex";
    variable l : line; variable r : rom_t;
  begin
    for i in r'range loop readline(f,l); hread(l,r(i)); end loop;
    return r;
  end;
  constant rom : rom_t := load_rom;
  signal clk50 : std_logic := '0';
  signal cpu_a : std_logic_vector(14 downto 0) := (others=>'0');
  signal full_addr : natural range 0 to 65535 := 0;
  signal cpu_d, drive_data, prg_d : std_logic_vector(7 downto 0);
  signal rw, m2, ce, dir : std_logic := '1';
  signal prg_a, chr_a : std_logic_vector(21 downto 0);
  signal prg_ce, prg_oe, prg_we, sram_ce, sram_we, sram_oe, chr_we, chr_oe : std_logic;
  signal chr_d : std_logic_vector(7 downto 0);
  type ram_t is array(0 to 131071) of std_logic_vector(7 downto 0);
  signal sram : ram_t := (others=>x"00");
  type chr_t is array(0 to 262143) of std_logic_vector(7 downto 0);
  signal chrram : chr_t := (others=>x"00");
  signal gpio : std_logic_vector(3 downto 0);
  signal exp : std_logic_vector(9 downto 0);
begin
  clk50 <= not clk50 after 10 ns;
  cpu_a <= std_logic_vector(to_unsigned(full_addr mod 32768,15));
  ce <= '0' when full_addr >= 32768 and m2 = '1' else '1';
  cpu_d <= drive_data when rw = '0' else (others=>'Z');
  prg_d <= rom(to_integer(unsigned(prg_a(19 downto 0)))) when prg_ce='0' and prg_oe='0' else sram(to_integer(unsigned(prg_a(16 downto 0)))) when sram_ce='1' and sram_oe='0' else (others=>'Z');
  chr_d <= chrram(to_integer(unsigned(chr_a(17 downto 0)))) after 70 ns when chr_oe='0' else (others=>'Z');
  process(sram_we) begin if rising_edge(sram_we) then sram(to_integer(unsigned(prg_a(16 downto 0))))<=prg_d;end if;end process;
  process(chr_we) begin if rising_edge(chr_we) then chrram(to_integer(unsigned(chr_a(17 downto 0))))<=chr_d;end if;end process;
  board : entity work.racing_top port map (
    clk50=>clk50, cpu_a=>cpu_a, cpu_d=>cpu_d, cpu_rw=>rw, m2=>m2, cpu_romsel=>ce,
    cpu_dir=>dir, cpu_irq=>open, cpu_ex=>open,
    ppu_d=>open, ppu_a=>(others=>'0'), ppu_rd=>'1', ppu_wr=>'1', ppu_a13n=>'1',
    ppu_ciram_ce=>open, ppu_ciram_a10=>open, ppu_dir=>open, ppu_ex=>open,
    prg_d=>prg_d, prg_a=>prg_a, prg_ce=>prg_ce, prg_oe=>prg_oe, prg_we=>prg_we,
    prg_ub=>open, prg_lb=>open, chr_d=>chr_d, chr_a=>chr_a,
    chr_ce=>open, chr_oe=>chr_oe, chr_we=>chr_we, chr_ub=>open, chr_lb=>open,
    sram_ce=>sram_ce, sram_oe=>sram_oe, sram_we=>sram_we,
    mcu_miso=>open, mcu_mosi=>'0', mcu_clk=>'0', mcu_ss=>'1', fds_sw=>'0', mcu_busy=>'0',
    led=>open, pwm=>open, fifo_rxf=>open, boot_on=>open,
    gpio=>gpio, exp=>exp, xio=>open, rx=>'0', tx=>open);
  process
    file f:text open read_mode is "trace.txt";file expected:text open read_mode is "expected.hex";
    variable l:line;variable op:natural;variable a:std_logic_vector(15 downto 0);variable d,v:std_logic_vector(7 downto 0);
    variable count:natural:=0;variable done:boolean;
    procedure cycle(addr:natural;data:std_logic_vector(7 downto 0);writing:boolean;variable q:out std_logic_vector(7 downto 0)) is
    begin
      m2<='0';full_addr<=addr;drive_data<=data;if writing then rw<='0';else rw<='1';end if;
      wait for 210 ns;m2<='1';wait for 300 ns;q:=cpu_d;wait for 50 ns;m2<='0';wait for 1 ns;
    end;
  begin
    wait for 1 us;
    while not endfile(f) loop
      readline(f,l);read(l,op);hread(l,a);hread(l,d);
      if op=2 then
        done:=false;
        for i in 0 to 4000 loop cycle(to_integer(unsigned(a)),x"00",false,v);if v(0)='0' then done:=true;exit;end if;end loop;
        assert done report "fill timeout" severity failure;
      else
        cycle(to_integer(unsigned(a)),d,op=1,v);
        if op=0 then assert v=d report "CPU read mismatch " & to_hstring(a) & " expected " & to_hstring(d) & " got " & to_hstring(v) & " transaction " & integer'image(count) severity failure;end if;
      end if;
      count:=count+1;
    end loop;
    report "BOOT TRACE PASSED " & integer'image(count);
    done:=false;
    for i in 0 to 200000 loop cycle(16#4830#,x"00",false,v);if v(5)='0' then done:=true;exit;end if;end loop;
    assert done report "GSU timeout" severity failure;
    done:=false;
    for i in 0 to 20000 loop cycle(16#4FB0#,x"00",false,v);if v(1)='1' then done:=true;exit;end if;end loop;
    assert done and v(2)='0' report "DSP/copy timeout" severity failure;
    for i in 0 to 16383 loop readline(expected,l);hread(l,d);assert chrram(16#24000#+i)=d report "external frame mismatch " & integer'image(i) & " got " & to_hstring(chrram(16#24000#+i)) & " expected " & to_hstring(d) severity failure;end loop;
    cycle(16#4FE2#,x"01",true,v);cycle(16#4FB0#,x"00",false,v);
    assert v=x"08" report "DSP/front commit failed" severity failure;
    cycle(16#4FE2#,x"00",false,v);assert v=x"01" severity failure;
    report "ALL BOOT AND EXTERNAL FRAME TESTS PASSED";stop;wait;
  end process;
end;