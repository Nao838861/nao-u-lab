-- SPDX-License-Identifier: GPL-3.0-or-later
library ieee;
use ieee.std_logic_1164.all;
use ieee.numeric_std.all;
use ieee.std_logic_textio.all;
use std.textio.all;
use std.env.all;
entity tb_racing_gsu is end;
architecture test of tb_racing_gsu is
  signal clk : std_logic := '0';
  signal a : std_logic_vector(15 downto 0) := x"0000";
  signal di, dout : std_logic_vector(7 downto 0) := x"00";
  signal rw : std_logic := '1';
  signal m2 : std_logic := '0';

  signal selected, irq_n, running, done_frame, reset_o, front : std_logic;
  signal mode : std_logic_vector(2 downto 0);
  signal copy_a : unsigned(13 downto 0) := (others=>'0');
  signal copy_q : std_logic_vector(7 downto 0);
begin
  clk <= not clk after 20 ns;
  dut : entity work.racing_gsu port map(clk,a,di,rw,m2,dout,selected,irq_n,running,done_frame,reset_o,front,mode,copy_a,copy_q);
  process
    file hex : text open read_mode is "input.hex";
    file expected : text open read_mode is "expected.hex";
    variable ln : line;
    type bytes_t is array(0 to 63) of std_logic_vector(7 downto 0);
    variable prog : bytes_t;
    variable v : std_logic_vector(7 downto 0);
    variable done : boolean;
    variable measured_ticks : natural;
    procedure bus_cycle(addr : natural; data : natural; write_bus : boolean;
                        variable value : out std_logic_vector(7 downto 0)) is
    begin
      m2 <= '0'; a <= std_logic_vector(to_unsigned(addr,16));
      di <= std_logic_vector(to_unsigned(data,8));
      if write_bus then rw <= '0'; else rw <= '1'; end if;
      wait for 210 ns;
      m2 <= '1'; wait for 300 ns;
      value := dout;
      wait for 50 ns; m2 <= '0'; wait for 1 ns;
    end;
    procedure wr(addr,data : natural) is
      variable ignored : std_logic_vector(7 downto 0);
    begin bus_cycle(addr,data,true,ignored); end;
    procedure expect(addr,data : natural) is
      variable value : std_logic_vector(7 downto 0);
    begin
      bus_cycle(addr,0,false,value);
      assert value = std_logic_vector(to_unsigned(data,8))
        report "address " & integer'image(addr) & " expected " & integer'image(data) & " got " & to_hstring(value) severity failure;
    end;
  begin
    wait for 1 us;
    for trial in 0 to 8-1 loop
      wr(16#4FF0#,16#A5#);wait for 1 us;
      wr(16#4FE1#,4);wr(16#4FF3#,1);
      for i in 0 to 8191 loop
        readline(hex,ln);hread(ln,v);wr(16#6000#+i,to_integer(unsigned(v)));
      end loop;
      wr(16#4834#,16#70#);wr(16#4839#,1);wr(16#4837#,16#A0#);
      wr(16#483A#,16#18#);wr(16#4838#,16#10#);
      wr(16#4FE8#,0);wr(16#4FE9#,16#40#);wr(16#4FEA#,0);wr(16#4FEB#,16#40#);
      wr(16#4FEC#,0);wr(16#4FED#,0);wr(16#4FEE#,1);
      wait for 700 us;
      wr(16#481E#,0);wr(16#481F#,16#90#);
      done:=false;
      for poll in 0 to 250000 loop
        bus_cycle(16#4830#,0,false,v);
        if v(5)='0' then done:=true;exit;end if;
      end loop;
      assert done report "GSU timeout" severity failure;
      report "GSU finished case " & integer'image(trial);
      measured_ticks:=0;
      for b in 0 to 3 loop
        bus_cycle(16#4FD0#+b,0,false,v);
        measured_ticks:=measured_ticks+to_integer(unsigned(v))*(256**b);
      end loop;
      report "GSU_TICKS " & integer'image(trial) & " " & integer'image(measured_ticks);
      for i in 0 to 16383 loop
        copy_a<=to_unsigned(i,14);wait for 100 ns;
        readline(expected,ln);hread(ln,v);
        assert copy_q=v report "frame mismatch at " & integer'image(i) & " expected " & to_hstring(v) & " got " & to_hstring(copy_q) severity failure;
      end loop;
      report "RACING FRAME PASS " & integer'image(trial);
    end loop;
    report "ALL RACING FRAMES PASSED";stop;wait;
  end process;
end;
