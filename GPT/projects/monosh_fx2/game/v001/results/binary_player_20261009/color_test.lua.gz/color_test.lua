local labels = {["LoadAudioData"]=34429,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=5837684,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=34035,["Tad_GetSong"]=34139,["Tad_GlobalVolumesPersist"]=34167,["Tad_GlobalVolumesResetOnSongStart"]=34161,["Tad_Init"]=33651,["Tad_IsLoaderActive"]=34193,["Tad_IsSfxPlaying"]=34207,["Tad_IsSongLoaded"]=34201,["Tad_IsSongPlaying"]=34213,["Tad_LoadSong"]=34094,["Tad_LoadSongIfChanged"]=34127,["Tad_Loader_Bin"]=5837568,["Tad_Loader_SIZE"]=116,["Tad_Process"]=33778,["Tad_QueueCommand"]=34051,["Tad_QueueCommandOverride"]=34056,["Tad_QueuePannedSoundEffect"]=34073,["Tad_QueueSoundEffect"]=34083,["Tad_ReloadCommonAudioData"]=34143,["Tad_SetTransferSize"]=34173,["Tad_SongsStartImmediately"]=34149,["Tad_SongsStartPaused"]=34155,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=1,["Tad_sfxQueue_sfx"]=0,["__BSS_LOAD__"]=59022,["__BSS_RUN__"]=59022,["__BSS_SIZE__"]=5749,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65154,["__COLORBSS_LOAD__"]=1908,["__COLORBSS_RUN__"]=1908,["__COLORBSS_SIZE__"]=1788,["__COLORRODATA_LOAD__"]=36635,["__COLORRODATA_RUN__"]=1024,["__COLORRODATA_SIZE__"]=884,["__DATA_LOAD__"]=4376195,["__DATA_RUN__"]=59011,["__DATA_SIZE__"]=11,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50819,["__STARTUP__"]=1,["_abs"]=64785,["_boss_age"]=59637,["_boss_attribute_cache"]=59472,["_boss_attribute_cache_count"]=59634,["_boss_attribute_z_cache"]=59616,["_boss_dda_phase"]=59855,["_boss_dda_x"]=59861,["_boss_dda_y"]=59867,["_boss_death_parts"]=59639,["_boss_death_timer"]=59638,["_boss_fire_gap"]=59648,["_boss_fire_round"]=59645,["_boss_fire_shots"]=59647,["_boss_fire_state"]=59644,["_boss_fire_volley"]=59646,["_boss_history_x"]=59088,["_boss_history_y"]=59216,["_boss_history_z"]=59344,["_boss_last_vblank"]=59024,["_boss_motion_steps"]=59643,["_boss_part_active"]=59052,["_boss_part_bottom"]=59034,["_boss_part_fall_fraction"]=59079,["_boss_part_fall_velocity"]=59070,["_boss_part_timer"]=59061,["_boss_part_x"]=59025,["_boss_part_z"]=59043,["_boss_path_half"]=59642,["_boss_player_bottom"]=59651,["_boss_player_x"]=59649,["_boss_render_camera_delta"]=59635,["_boss_restart_timer"]=59640,["_boss_z_phase"]=59641,["_death_accel_fraction"]=59889,["_death_timer"]=59887,["_death_vy"]=59886,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_audio_events"]=5648,["_fx_boss_hits"]=61867,["_fx_boss_project"]=61672,["_fx_build_ground"]=13121,["_fx_build_packet"]=23596,["_fx_buttons"]=62055,["_fx_draw"]=60131,["_fx_draw_count"]=60771,["_fx_em0_geometry"]=58895,["_fx_enemy_collisions"]=58362,["_fx_enemy_em1_update"]=59771,["_fx_enemy_em1_update_reference"]=7583,["_fx_enemy_fire_em1"]=7521,["_fx_enemy_remove"]=7510,["_fx_enemy_render"]=57732,["_fx_enemy_render_bullets"]=58011,["_fx_far_d_acc"]=62067,["_fx_far_u_acc"]=62065,["_fx_fire_actions"]=62058,["_fx_frame"]=60675,["_fx_ground_c1ptr"]=63823,["_fx_ground_c3ptr"]=63825,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62074,["_fx_ground_color3"]=62524,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63789,["_fx_ground_far_xptr"]=63819,["_fx_ground_far_y"]=63829,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63827,["_fx_ground_horizontal"]=62974,["_fx_ground_hptr"]=63784,["_fx_ground_native"]=13206,["_fx_ground_palette_record"]=63787,["_fx_ground_phase"]=62054,["_fx_ground_vptr"]=63821,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63786,["_fx_init"]=11689,["_fx_input"]=62057,["_fx_open_size"]=62937,["_fx_packet"]=60774,["_fx_packet_count"]=60772,["_fx_present"]=12402,["_fx_read_input"]=12166,["_fx_send_ground"]=12198,["_fx_sky_color"]=39095,["_fx_stage_contact"]=57048,["_fx_stage_render"]=56349,["_fx_stage_update"]=57379,["_fx_submit"]=62725,["_fx_toggle_color"]=23922,["_ground_irq_vblank_count"]=62062,["_history_head"]=59636,["_hit_pending"]=62069,["_intro_timer"]=59890,["_legacy_enemy_fire_boss_at"]=6115,["_main"]=11726,["_memcpy"]=64616,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59023,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2096,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=61452,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59022,["_monosh_bullet_reflect_rng"]=59693,["_monosh_collision_bullet_bands"]=59685,["_monosh_combat_build_collision_bands"]=2278,["_monosh_combat_fast_cache_reset"]=12092,["_monosh_combat_fast_frame"]=62221,["_monosh_combat_fast_render"]=62351,["_monosh_combat_fast_render_cached"]=12099,["_monosh_combat_fire_cooldown"]=59694,["_monosh_combat_half_frame"]=59695,["_monosh_combat_init"]=2122,["_monosh_combat_reflect_bullet"]=11737,["_monosh_combat_render"]=2275,["_monosh_combat_update"]=2217,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59850,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59699,["_monosh_enemy_active_count"]=3038,["_monosh_enemy_active_count_value"]=59697,["_monosh_enemy_bullet_count"]=59696,["_monosh_enemy_bullets"]=59779,["_monosh_enemy_camera_delta_cached"]=59848,["_monosh_enemy_collision_cursor"]=59853,["_monosh_enemy_draw_cache_valid"]=59851,["_monosh_enemy_em1_count"]=59849,["_monosh_enemy_em1_phase"]=59824,["_monosh_enemy_em1_shrink"]=59840,["_monosh_enemy_fast_advance"]=59363,["_monosh_enemy_fast_check_player_bullets"]=4128,["_monosh_enemy_fast_render"]=3613,["_monosh_enemy_fast_render_bullets"]=5078,["_monosh_enemy_fast_spawn_due"]=5454,["_monosh_enemy_fast_update_bullets"]=59033,["_monosh_enemy_fire_at"]=3050,["_monosh_enemy_fire_boss_at"]=3079,["_monosh_enemy_fire_em0_fast"]=6513,["_monosh_enemy_frame"]=2841,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59852,["_monosh_enemy_init"]=2692,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59854,["_monosh_enemy_render_only"]=2871,["_monosh_enemy_spawn_index"]=59821,["_monosh_enemy_spawn_wait"]=59822,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3044,["_monosh_enemy_stage_complete_flag"]=59698,["_monosh_ground_depth_pointer"]=62072,["_monosh_ground_offset"]=59011,["_monosh_ground_screen_delta"]=59012,["_monosh_player_bottom"]=59877,["_monosh_player_bullet_count"]=59668,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59653,["_monosh_player_can_fire"]=9341,["_monosh_player_draw_asset"]=9357,["_monosh_player_draw_flags"]=9299,["_monosh_player_init"]=9236,["_monosh_player_invuln"]=59880,["_monosh_player_pose"]=59882,["_monosh_player_state"]=59879,["_monosh_player_stumble"]=59881,["_monosh_player_update"]=60065,["_monosh_player_update_reference"]=10566,["_monosh_player_world_active"]=9335,["_monosh_player_x"]=59875,["_monosh_project_x"]=27526,["_monosh_reflected_bullet_count"]=59684,["_monosh_reflected_bullets"]=59669,["_monosh_runtime_fire_actions"]=62059,["_monosh_runtime_frame_counter"]=62060,["_monosh_runtime_paused"]=62064,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60129,["_monosh_stage_collision_bullet_index"]=60130,["_monosh_stage_contact_result"]=60127,["_monosh_stage_draw_cache_valid"]=60128,["_monosh_stage_frame"]=10841,["_monosh_stage_frame_counter"]=59991,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59995,["_monosh_stage_hitbox_count"]=60125,["_monosh_stage_hitboxes"]=59997,["_monosh_stage_init"]=10806,["_monosh_stage_is_clear"]=10890,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59996,["_monosh_stage_need_hitboxes"]=60126,["_monosh_stage_object_count"]=59989,["_monosh_stage_objects"]=59893,["_monosh_stage_render_only"]=10887,["_monosh_stage_spawn_index"]=59990,["_monosh_stage_spawn_wait"]=59993,["_monosh_stage_title_timer"]=59883,["_monosh_title_draw"]=11715,["_monosh_title_visible"]=59013,["_movement_fraction"]=59888,["_old_buttons"]=62070,["_player_flip"]=59891,["_player_fy"]=59884,["_player_run_phase"]=59892,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12093,["addeq0sp"]=64118,["addeqysp"]=64120,["addysp"]=64136,["addysp1"]=64135,["aslax2"]=64149,["aslax3"]=64160,["aslax4"]=64174,["asleax1"]=64191,["asrax1"]=64203,["asrax2"]=64213,["asrax3"]=64228,["booleq"]=64578,["boolge"]=64595,["boolgt"]=64593,["boolle"]=64585,["boollt"]=64587,["boolne"]=64572,["booluge"]=64611,["boolugt"]=64609,["boolule"]=64601,["boolult"]=64603,["c_sp"]=156,["clip_edges"]=99624,["color_boot_map"]=34587,["color_clear_dirty"]=25127,["color_clear_dirty_row"]=25131,["color_clear_dirty_skip"]=25232,["color_clear_ready"]=24057,["color_cols_done"]=24565,["color_kernel_restore"]=24802,["color_next_draw"]=24091,["color_palette"]=34459,["color_prepare_cols"]=24488,["color_rows"]=24658,["color_skip_draw"]=24826,["color_visible"]=24261,["decsp1"]=64248,["decsp2"]=64257,["decsp3"]=64270,["decsp4"]=64283,["decsp5"]=64296,["dma_cache"]=100208,["dma_cache_end"]=100409,["dma_deadline_fine"]=13064,["dma_finished"]=12989,["dma_last_line"]=255,["dma_started"]=12901,["fx_add_next_bounds"]=62724,["fx_audio_init"]=34219,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=34246,["fx_audio_sent"]=5653,["fx_build_color"]=23993,["fx_build_obj"]=26224,["fx_color_build_done"]=24833,["fx_color_cells"]=1024,["fx_color_dma"]=3640,["fx_color_dma_bytes"]=3690,["fx_color_dma_count"]=3688,["fx_color_map0"]=1908,["fx_color_map1"]=2676,["fx_color_mode"]=59014,["fx_color_next_ptr"]=59015,["fx_color_present_mode"]=3444,["fx_color_present_ptr"]=59017,["fx_color_stage_done"]=26065,["fx_color_staged"]=3692,["fx_color_upload_done"]=25925,["fx_color_vram_base"]=59020,["fx_commit_dma"]=62724,["fx_dma_bytes"]=64641,["fx_dma_count"]=64639,["fx_dma_desc"]=64643,["fx_em1_open_sizes"]=62980,["fx_emit_native"]=58225,["fx_is_obj"]=26139,["fx_latch_color"]=25729,["fx_latch_obj"]=27287,["fx_obj_build_done"]=26858,["fx_obj_count"]=64401,["fx_obj_dma_bytes"]=64441,["fx_obj_next"]=64129,["fx_obj_overflow"]=64405,["fx_obj_present"]=64265,["fx_obj_present_count"]=64403,["fx_obj_upload_done"]=27516,["fx_plan_dma"]=62705,["fx_prepare_obj_dma"]=27394,["fx_project16"]=27556,["fx_read_gsu_color_plan"]=26067,["fx_read_gsu_spans"]=62650,["fx_reset_next_bounds"]=62724,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63835,["fx_stage_color"]=26005,["fx_upload_color"]=25795,["fx_upload_color_palette"]=25927,["fx_upload_ground"]=13537,["fx_upload_obj"]=27461,["game_started"]=12102,["generic"]=99054,["generic_render"]=98622,["ground_done"]=13490,["ground_empty"]=13631,["gsu_color_axis_cache"]=100864,["gsu_color_begin"]=100416,["gsu_color_clear_end"]=100625,["gsu_color_delta_begin"]=101136,["gsu_color_delta_end"]=101316,["gsu_color_done"]=101316,["gsu_color_draw_cache"]=101024,["gsu_color_draw_cache_end"]=101122,["gsu_color_setup_cache"]=100656,["hot_cache"]=98464,["hot_cache_end"]=98975,["incsp1"]=64376,["incsp2"]=64391,["incsp3"]=64405,["incsp4"]=64410,["incsp5"]=64415,["incsp6"]=64420,["incsp7"]=64425,["incsp8"]=64430,["initialized"]=23664,["ldaidx"]=64435,["margin_render"]=98656,["margin_render_end"]=98735,["margin_select"]=100086,["memcpy_getparams"]=64657,["memcpy_upwards"]=64619,["mulax10"]=64676,["mulax3"]=64701,["mulax5"]=64718,["mulax6"]=64738,["mulax7"]=64760,["negax"]=64789,["order"]=63873,["packed_double"]=99491,["packed_double_cache"]=99522,["packed_half"]=99209,["packed_half_cache"]=99232,["packed_mirror_half"]=99383,["packed_mirror_half_cache"]=99406,["packed_mirror_one"]=99317,["packed_mirror_one_cache"]=99341,["packed_mirror_quarter"]=99442,["packed_mirror_quarter_cache"]=99461,["packed_one"]=99143,["packed_one_cache"]=99167,["packed_quarter"]=99268,["packed_quarter_cache"]=99287,["packet_done"]=23751,["packet_work"]=14,["popax"]=64383,["popptr1"]=64803,["popsargsudiv16"]=64893,["ptr1"]=164,["ptr2"]=166,["ptr3"]=168,["ptr4"]=170,["push0"]=64839,["push0ax"]=64542,["pusha"]=64821,["pusha0"]=64841,["pusha0sp"]=64817,["pushax"]=64843,["pushaysp"]=64819,["pusheax"]=64548,["pushl0"]=64539,["pushw0sp"]=64865,["pushwysp"]=64867,["regbank"]=176,["regsave"]=160,["render_entry"]=98304,["render_finished"]=12666,["render_started"]=12634,["render_stop"]=101320,["reset"]=32768,["scaled_select"]=99724,["select_dma_deadline"]=13008,["shlax2"]=64149,["shlax3"]=64160,["shlax4"]=64174,["shleax1"]=64191,["shrax1"]=64925,["shrax3"]=64933,["shrax4"]=64947,["sorted"]=23730,["sreg"]=158,["stage_update_done"]=57730,["staspidx"]=64964,["stax0sp"]=64986,["staxspidx"]=64997,["staxysp"]=64988,["subysp"]=65045,["tmp1"]=172,["tmp2"]=173,["tmp3"]=174,["tmp4"]=175,["tosadda0"]=64090,["tosaddax"]=64092,["tosdiva0"]=64309,["tosdivax"]=64311,["tosicmp"]=64332,["tosicmp0"]=64330,["tosmul0ax"]=64447,["tosmuleax"]=64453,["tossuba0"]=65024,["tossubax"]=65026,["tosudiva0"]=65058,["tosudivax"]=65060,["tosumoda0"]=65137,["tosumodax"]=65139,["tosumul0ax"]=64447,["tosumuleax"]=64453,["udiv16"]=65075,["L1"]=65109,["@L1"]=65127,["Pos"]=64327,["@L3"]=64368,["@L4"]=64369,["@L2"]=65131,["L0"]=65085,["mul32"]=64453,["ret0"]=64574,["ret1"]=64580,["L3"]=64646,["done"]=64654,["L2"]=64918,["@L0"]=65116,["udiv16by8a"]=65116,["cpu_frame_return"]=12656}
local output = "D:/AI/Nao_u_BOT/GPT/projects/monosh_fx2/build/game_v001/color"
local maxframe = 360
local scenario = "color"
local held_direction = "up-left"
local held_fire = "y"
local gsu_uv = true
local gsu_clip = true
local cpu_clip_commands = true
local report = assert(io.open(output..'/trace.jsonl','w'))
local field = 0
local game_started = false
-- 音源の初期転送を待つ。固定時刻の画像・入力標本を起動処理中に採らない。
emu.addMemoryCallback(function() game_started = true end,
  emu.callbackType.exec,0x7F0000+labels.game_started,0x7F0000+labels.game_started,
  emu.cpuType.snes,emu.memType.snesMemory)
local rendered = 0
local clock_start = 0
local gsu_start = 0
local dma_start = 0
local profile={}
local native_profile={}
local failed=false
local previous_field,previous_boss,previous_player=0,0,0
local last_logic,last_logic_field=-1,0
local stats={fields=0,rendered=0,checked=0,deaths=0,respawns=0,bossSeen=false,dyingSeen=false,doneSeen=false,loopSeen=false,
             enemyTypes={},enemyPaths={},em1States={},stumbles=0,reflected=0,maxCommands=0,minBytes=65535,maxBytes=0,
             interval1=0,interval2=0,interval3plus=0,cpuMaxMs=0,gsuMaxMs=0,dmaMaxMs=0}
local gsu_ms=0
local cpu_ms=0
-- Mesen LuaのmasterClockはuint32。約200秒ごとのwrapを時間差で吸収する。
local function elapsed(now,started) return ((now-started)&0xffffffff)/21477.272 end
local fixture_started=false
local function dump(name,memtype,address,count)
  local f=assert(io.open(output..'/'..name,'wb'));local bytes={}
  for i=0,count-1 do bytes[#bytes+1]=string.char(emu.read(address+i,memtype)) end
  f:write(table.concat(bytes));f:close()
end
local function screenshot(name)
  local f=assert(io.open(output..'/'..name..'.rgb','wb'));local rgb={}
  for _,v in ipairs(emu.getScreenBuffer()) do rgb[#rgb+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
  f:write(table.concat(rgb));f:close()
end
local function byte(name,offset)
  return emu.read(0x7E0000+assert(labels[name])+offset,emu.memType.snesMemory)
end
local function put(name,offset,value)
  emu.write(0x7E0000+assert(labels[name])+offset,value&255,emu.memType.snesMemory)
end
local function encoded(v)
  if type(v)=='table' then local out={};for k,x in pairs(v) do out[#out+1]='"'..tostring(k)..'":'..encoded(x) end;return '{'..table.concat(out,',')..'}' end
  if type(v)=='string' then return '"'..v..'"' end
  return tostring(v)
end
local function read(name, size)
  local addr=0x7E0000+assert(labels[name],name)
  local v=emu.read(addr,emu.memType.snesMemory)
  if size==2 then v=v+256*emu.read(addr+1,emu.memType.snesMemory) end
  return v
end
local function write(name,v)
  emu.write(0x7E0000+assert(labels[name]),v&255,emu.memType.snesMemory)
  emu.write(0x7E0000+assert(labels[name])+1,v>>8,emu.memType.snesMemory)
end
local function guard(fn)
  return function(...)
    if failed then return end
    local ok,err=pcall(fn,...)
    if not ok then
      failed=true
      local state=io.open(output..'/failure_state.json','w')
      state:write(encoded(emu.getState()));state:close()
      dump('failure_wram.bin',emu.memType.snesMemory,0x7e0000,65536)
      local input=io.open(output..'/failure_input.json','w')
      input:write(encoded(emu.getInput(0)));input:close()
      local q=io.open(output..'/debugram.bin','wb'); local t={}
      for k=0,32767 do t[#t+1]=string.char(emu.read(k,emu.memType.gsuWorkRam)) end
      q:write(table.concat(t)); q:close()
      local f=io.open(output..'/error.txt','w'); f:write(tostring(err)); f:close(); report:close();emu.stop(1)
    end
  end
end
-- 最終PPU合成の検査。三つのcamera高さで同じFX画像と四つの地上物を描く。
if scenario=='display' or scenario=='scenery' then
  emu.addMemoryCallback(guard(function()
    local offset=field<240 and 0 or (field<480 and 32 or 64)
    put('_monosh_ground_offset',0,offset)
    put('_fx_ground_world_phase',0,32)
    put('_fx_ground_phase',0,6)
    local farX=scenario=='scenery' and (field//4)%256 or 17
    write('_fx_far_u_acc',farX*128)
    write('_fx_far_d_acc',farX*256)
    local records={}
    for i,z in ipairs({0,24,60,110}) do
      local geometry=labels._monosh_stage_geometry+4*2
      local gp=emu.read(0x7e0000+geometry,emu.memType.snesMemory)+256*emu.read(0x7e0000+geometry+1,emu.memType.snesMemory)
      local w=emu.read(0x7e0000+gp+z*4,emu.memType.snesMemory)
      local h=emu.read(0x7e0000+gp+z*4+1,emu.memType.snesMemory)
      local source=emu.read(0x7e0000+gp+z*4+2,emu.memType.snesMemory)
      local d=byte('_fx_ground_depth_rows',offset*81+219-source)
      local sink=z>=9 and 3 or (z>=6 and 2 or (z>=2 and 1 or 0))
      records[#records+1]={({35,107,178,231})[i],207-d+sink,w,h,4,0,z,0}
    end
    records[#records+1]={66,90,32,48,9,0,0,2}
    records[#records+1]={184,75,88,38,42,0,0,2}
    if scenario=='scenery' then records={} end
    for i,r in ipairs(records) do
      local data={r[1]&255,(r[1]>>8)&255,r[2]&255,(r[2]>>8)&255,r[3],r[4],r[5],r[6],r[7],r[8]}
      for j,v in ipairs(data) do put('_fx_draw',(i-1)*10+j-1,v) end
    end
    put('_fx_draw_count',0,#records)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
  local selected={[238]=true,[478]=true,[718]=true}
  emu.addEventCallback(guard(function()
    if not selected[field] then return end
    local prefix=string.format('display%05d',field)
    dump(prefix..'_vram.bin',emu.memType.snesVideoRam,0,65536)
    dump(prefix..'_cgram.bin',emu.memType.snesCgRam,0,512)
    dump(prefix..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    local meta={}
    for _,r in ipairs({{'v',0x1d04,500,0x7f0000},{'c1',0x1d06,128,0x7e0000},
        {'c3',0x1d08,128,0x7e0000},{'far',0x1d0c,10,0x7e0000},{'h',0x1d0e,270,0x7e0000},
        {'sky',0x1d16,10,0x7e0000}}) do
      local p=emu.read(0x7e0000+r[2],emu.memType.snesMemory)+256*emu.read(0x7e0000+r[2]+1,emu.memType.snesMemory)
      dump(prefix..'_'..r[1]..'.bin',emu.memType.snesMemory,r[4]+p,r[3])
    end
    local far=emu.read(0x7e1d0a,emu.memType.snesMemory)+256*emu.read(0x7e1d0b,emu.memType.snesMemory)
    if far>=32768 then far=far-65536 end
    -- 表示中の画像にラッチ済みの座標を読む。次画像のgame状態とは時点が異なる。
    meta.farY=far;meta.offset=23-far
    meta.nearX=emu.read(0x7e1d14,emu.memType.snesMemory)+256*emu.read(0x7e1d15,emu.memType.snesMemory)
    local fp=emu.read(0x7e1d0c,emu.memType.snesMemory)+256*emu.read(0x7e1d0d,emu.memType.snesMemory)
    meta.farX=emu.read(0x7e0001+fp,emu.memType.snesMemory)+256*emu.read(0x7e0002+fp,emu.memType.snesMemory)
    meta.skyBase=labels.fx_sky_colors
    meta.fxMapBase=labels.fx_color_vram_base and read('fx_color_vram_base',2)*2 or 0x8000
    local sf=assert(io.open(output..'/'..prefix..'_state.txt','w'))
    for k,v in pairs(emu.getState()) do if k:find('ppu') and (k:lower():find('scroll') or k:lower():find('bg')) then sf:write(k..'='..tostring(v)..'\n') end end
    sf:close()
    dump(prefix..'_skycolors.bin',emu.memType.snesMemory,0x7e0000+labels.fx_sky_colors,labels.fx_sky_colors_end-labels.fx_sky_colors)
    local f=assert(io.open(output..'/'..prefix..'.json','w'));f:write(encoded(meta));f:close()
  end),emu.eventType.startFrame)
  emu.addEventCallback(guard(function()
    if selected[field] then screenshot(string.format('display%05d',field)) end
    if scenario=='scenery' and field>=140 and field<=220 and field%4==0 then screenshot(string.format('parallax%05d',field)) end
  end),emu.eventType.endFrame)
end

-- 実ゲームが出した開EM1の矩形を、全ZのWRAM表と照合する。
-- 人工描画リストのreplay/packed/stressでは任意寸法を許す。
if labels.fx_em1_open_sizes and scenario~='replay' and scenario~='packed' and scenario~='stress' and scenario~='objects' then
  emu.addMemoryCallback(guard(function()
    for i=0,read('_fx_draw_count')-1 do
      local at=i*10
      local asset=byte('_fx_draw',at+6)
      if asset>=32 and asset<=36 then
        local z=math.min(110,byte('_fx_draw',at+8))
        local addr=0x7f0000+labels.fx_em1_open_sizes+z*10+(asset-32)*2
        local width=emu.read(addr,emu.memType.snesMemory)
        local height=emu.read(addr+1,emu.memType.snesMemory)
        assert(byte('_fx_draw',at+4)==width and byte('_fx_draw',at+5)==height,'open EM1 depth lookup mismatch')
        stats.openEm1SizeChecks=(stats.openEm1SizeChecks or 0)+1
      end
    end
  end),emu.callbackType.exec,0x7f0000+labels._fx_build_packet,0x7f0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
emu.addMemoryCallback(guard(function()
  report:write(string.format('{"bootSky":%d,"skyConstant":%d}\n',emu.read(0,emu.memType.snesCgRam)+256*emu.read(1,emu.memType.snesCgRam),read('_fx_sky_color',2)))
end),emu.callbackType.exec,0x7f0000+labels.game_started,0x7f0000+labels.game_started,emu.cpuType.snes,emu.memType.snesMemory)
local obj_clock=0
emu.addMemoryCallback(guard(function() obj_clock=emu.getState().masterClock end),
  emu.callbackType.exec,0x7F0000+labels.fx_upload_obj,0x7F0000+labels.fx_upload_obj,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  report:write(string.format('{"objMs":%.6f,"objBytes":%d,"field":%d}\n',elapsed(emu.getState().masterClock,obj_clock),read('fx_obj_dma_bytes',2),field))
end),emu.callbackType.exec,0x7F0000+labels.fx_obj_upload_done,0x7F0000+labels.fx_obj_upload_done,emu.cpuType.snes,emu.memType.snesMemory)
if scenario=='objects' then
  emu.addEventCallback(guard(function()
    -- StartFrameでは直前の完成RGB、OAMは次に走査するfieldのもの。
    if field>=41 and field<=301 and (field-1)%4==0 then screenshot(string.format('objview%05d',field-1)) end
    if field>=40 and field<=300 and field%4==0 then
      dump(string.format('objview%05d_oam.bin',field),emu.memType.snesSpriteRam,0,544)
      dump(string.format('objview%05d_cgram.bin',field),emu.memType.snesCgRam,0,512)
    end
  end),emu.eventType.startFrame)
  emu.addMemoryCallback(guard(function()
    local n=read('_monosh_runtime_frame_counter',2)
    local poses={9,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30}
    local r={{128,165,68,158,4,0,0,0}}
    for i=1,6 do
      local size=1+(n+i)%16
      r[#r+1]={100+i*8,100+i*4,size,size,10,i>3 and 64 or 0,0,2}
    end
    local flags=((n//17)%4)*16
    if (n//68)%2==1 then flags=flags|128 end
    r[#r+1]={({0,256,128,128})[1+(n//4)%4],({48,180,28,230})[1+(n//7)%4],32,48,poses[1+n%17],flags,0,2}
    if n%17==0 then
      -- 最悪の重なり：初期自弾3＋反射弾3＋自機。同一走査線34tile以内。
      for i=2,7 do
        local size=(n%34==0 and i<=4) and 11 or 12
        r[i]={128,110,size,size,10,i>4 and 64 or 0,0,2}
      end
      r[8][1]=128;r[8][2]=125
    end
    for i,v in ipairs(r) do
      local b={v[1]&255,(v[1]>>8)&255,v[2]&255,(v[2]>>8)&255,v[3],v[4],v[5],v[6],v[7],v[8]}
      for j,c in ipairs(b) do put('_fx_draw',(i-1)*10+j-1,c) end
    end
    put('_fx_draw_count',0,#r)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
for _,name in ipairs({'packed_one','packed_half','packed_quarter','packed_double',
                     'packed_mirror_one','packed_mirror_half','packed_mirror_quarter'}) do
  emu.addMemoryCallback(guard(function() stats[name]=(stats[name] or 0)+1 end),
    emu.callbackType.exec,labels[name],labels[name],emu.cpuType.gsu,emu.memType.gsuMemory)
end
if scenario=='packed' then
  emu.addMemoryCallback(guard(function()
    local sprites={{40,100,32,48,0},{90,100,16,24,0},{125,100,8,12,0},
      {165,100,32,48,32},{0,100,32,48,0},{215,30,32,48,0},
      {4,180,16,24,0},{256,180,8,12,0},{120,170,32,48,16},
      {120,190,68,158,0,4},{35,200,68,158,32,4},
      {160,180,16,24,16},{200,180,8,12,48}}
    local tail=read('_monosh_runtime_frame_counter',2)%8
    sprites[#sprites+1]={256-(56+tail)+34,190,68,158,tail%2==0 and 0 or 32,4}
    stats.doubleTailRequests=stats.doubleTailRequests or {}
    stats.doubleTailRequests[tail]=true
    for i,d in ipairs(sprites) do
      local values={d[1]&255,(d[1]>>8)&255,d[2],0,d[3],d[4],d[6] or 9,d[5],i,0}
      for j,v in ipairs(values) do put('_fx_draw',(i-1)*10+j-1,v) end
    end
    put('_fx_draw_count',0,#sprites)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
if scenario=='equivalence' or scenario=='equivalence_boss' then
  -- Native移植前後で、物理frame数によらず同じlogic更新の状態を比較する。
  emu.addMemoryCallback(guard(function()
    put('_fx_fire_actions',0,2);put('_monosh_runtime_fire_actions',0,2)
    local inputs={1,2,8,4,9,6,0,0}
    local input=inputs[(read('_monosh_runtime_frame_counter',2)//96)%8+1]
    put('_fx_input',0,input)
    -- entry時点で引数は既にcc65 stackへ積まれている。実引数も揃える。
    emu.write(0x7e0000+read('c_sp',2),input,emu.memType.snesMemory)
  end),emu.callbackType.exec,0x7F0000+labels._monosh_player_update,0x7F0000+labels._monosh_player_update,emu.cpuType.snes,emu.memType.snesMemory)
  local states=assert(io.open(output..'/states.bin','wb'))
  local blocks={{'_monosh_runtime_frame_counter',2},{'_monosh_player_x',2},{'_monosh_player_bottom',2},
    {'_monosh_player_state',1},{'_monosh_player_invuln',1},{'_monosh_player_stumble',1},{'_monosh_player_pose',1},
    {'_player_fy',2},{'_death_vy',1},{'_death_timer',1},{'_movement_fraction',1},
    {'_death_accel_fraction',1},{'_intro_timer',1},{'_player_flip',1},{'_player_run_phase',1},
    {'_monosh_stage_title_timer',1},{'_monosh_title_visible',1},
    {'_monosh_stage_frame_counter',2},{'_monosh_stage_spawn_index',1},{'_monosh_stage_half_frame',1},
    {'_monosh_stage_object_count',1},{'_monosh_stage_objects',96},{'_monosh_enemy_spawn_index',1},
    {'_monosh_enemy_spawn_wait',2},{'_monosh_enemy_active_count_value',1},{'_monosh_enemy_em1_count',1},
    {'_monosh_enemy_stage_complete_flag',1},{'_monosh_enemies',80},{'_monosh_enemy_em1_phase',16},
    {'_monosh_enemy_em1_shrink',8},{'_monosh_enemy_bullet_count',1},{'_monosh_enemy_bullets',42},
    {'_boss_dda_phase',6},{'_boss_dda_x',6},{'_boss_dda_y',6},
    {'_monosh_player_bullet_count',1},{'_monosh_player_bullets',15},{'_monosh_reflected_bullet_count',1},
    {'_monosh_reflected_bullets',15},{'_monosh_boss_state',1},{'_monosh_boss_hp',1},
    {'_boss_part_x',9},{'_boss_part_bottom',9},{'_boss_part_z',9},{'_boss_part_active',9},{'_boss_part_timer',9},
    {'_monosh_ground_offset',1},{'_monosh_ground_screen_delta',1},{'_fx_ground_world_phase',1},
    {'_fx_far_u_acc',2},{'_fx_far_d_acc',2},{'_monosh_combat_fire_cooldown',1},{'_monosh_bullet_reflect_rng',1},
    {'_boss_age',1},{'_history_head',1},{'_boss_history_x',128},{'_boss_history_y',128},{'_boss_history_z',128},
    {'_fx_draw_count',1},{'_fx_draw',640}}
  local f=assert(io.open(output..'/state_blocks.json','w'));f:write(encoded(blocks));f:close()
  emu.addMemoryCallback(guard(function()
    local raw={}
    for _,b in ipairs(blocks) do for i=0,b[2]-1 do raw[#raw+1]=string.char(byte(b[1],i)) end end
    states:write(table.concat(raw));states:flush()
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
if scenario=='profile' then
for _,pair in ipairs({{'_fx_build_packet','packet_done'},{'_fx_ground_native','ground_done'},{'fx_build_color','fx_color_build_done'}}) do
  emu.addMemoryCallback(guard(function() native_profile[pair[1]]=emu.getState().masterClock end),
    emu.callbackType.exec,0x7F0000+labels[pair[1]],0x7F0000+labels[pair[1]],emu.cpuType.snes,emu.memType.snesMemory)
  emu.addMemoryCallback(guard(function()
    local start=native_profile[pair[1]]
    if start then report:write(string.format('{"function":"%s","ms":%.6f,"field":%d}\n',pair[1],elapsed(emu.getState().masterClock,start),field)) end
  end),emu.callbackType.exec,0x7F0000+labels[pair[2]],0x7F0000+labels[pair[2]],emu.cpuType.snes,emu.memType.snesMemory)
end
for _,name in ipairs({'_fx_frame','_fx_build_packet','_fx_build_ground','_fx_ground_native','_monosh_enemy_frame','_monosh_stage_frame'}) do
  emu.addMemoryCallback(guard(function()
    local clock=emu.getState().masterClock
    if profile.last then report:write(string.format('{"segment":"%s","ms":%.6f,"field":%d}\n',profile.last,elapsed(clock,profile.clock),field)) end
    profile.last=name;profile.clock=clock
  end),emu.callbackType.exec,0x7F0000+labels[name],0x7F0000+labels[name],emu.cpuType.snes,emu.memType.snesMemory)
end
end
emu.addMemoryCallback(guard(function()
  -- 入力方向の試験が敵接触による死亡アニメーションに切り替わらないよう固定。
  if scenario=='controls' then put('_monosh_player_invuln',0,255) end
  if scenario=='stumble' and field>=400 and not fixture_started then
    fixture_started=true
    write('_monosh_player_bottom',201)
    put('_monosh_player_invuln',0,0)
    put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
    for i,v in ipairs({0,0,1,3,0,0}) do put('_monosh_stage_objects',i-1,v) end
    put('_monosh_stage_object_count',0,1)
  end
  local fixture_frame=scenario=='equivalence_boss' and read('_monosh_runtime_frame_counter',2) or field
  if (scenario~='boss' and scenario~='equivalence_boss') or fixture_frame<90 then return end
  if scenario=='equivalence_boss' then put('_monosh_player_invuln',0,255) end
  if not fixture_started then
    fixture_started=true
    put('_monosh_player_invuln',0,255)
    put('_monosh_enemy_stage_complete_flag',0,1)
    put('_monosh_enemy_active_count_value',0,0);put('_monosh_enemy_bullet_count',0,0)
    put('_monosh_stage_object_count',0,0)
    put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
    write('_monosh_stage_frame_counter',3900)
  end
  -- 通常のボス射撃を先に観測。HPは変更せず、後半で自弾だけを命中位置へ置く。
  if read('_monosh_boss_state')==1 and fixture_frame>600 then
    local z=byte('_boss_part_z',0)
    local height=byte('_monosh_boss_face_geometry',math.min(z,110)*2+1)
    if z>=8 and z<=90 then
      put('_monosh_player_bullets',0,1)
      put('_monosh_player_bullets',1,byte('_boss_part_x',0))
      put('_monosh_player_bullets',2,byte('_boss_part_bottom',0)-height//2)
      put('_monosh_player_bullets',3,math.max(0,z//2-2));put('_monosh_player_bullets',4,3)
      put('_monosh_player_bullet_count',0,1)
      stats.injectedShots=(stats.injectedShots or 0)+1
    end
  end
end),emu.callbackType.exec,0x7F0000+labels._fx_frame,0x7F0000+labels._fx_frame,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  if scenario~='stress' then return end
  for i=0,19 do
    local x=(i%10)*32-16;local bottom=i<10 and 212 or 112
    put('_fx_draw',i*10,x);put('_fx_draw',i*10+1,(x>>8)&255)
    put('_fx_draw',i*10+2,bottom);put('_fx_draw',i*10+3,0)
    put('_fx_draw',i*10+4,68);put('_fx_draw',i*10+5,160)
    put('_fx_draw',i*10+6,4);put('_fx_draw',i*10+7,i%2==0 and 16 or 0)
    put('_fx_draw',i*10+8,i);put('_fx_draw',i*10+9,0)
  end
  put('_fx_draw_count',0,20)
end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  gsu_ms=elapsed(emu.getState().masterClock,clock_start)
  stats.gsuMaxMs=math.max(stats.gsuMaxMs,gsu_ms)
end),emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
emu.addMemoryCallback(guard(function()
  local now=emu.getState().masterClock
  cpu_ms=elapsed(now,clock_start)
  if scenario=='profile' and profile.last then
    report:write(string.format('{"segment":"%s","ms":%.6f,"field":%d}\n',profile.last,elapsed(now,profile.clock),field))
    profile.last=nil
  end
end),emu.callbackType.exec,0x7F0000+labels.cpu_frame_return,0x7F0000+labels.cpu_frame_return,emu.cpuType.snes,emu.memType.snesMemory)
local function trace()
  local s=emu.getState()
  if field==60 then
    local f=io.open(output..'/state.txt','w')
    for k,v in pairs(s) do if k:find('cpu') or k:find('coprocessor') then f:write(k..'='..tostring(v)..'\n') end end
    f:write('packet='..emu.read(0,emu.memType.gsuWorkRam)..' scratch='..emu.read(4,emu.memType.gsuWorkRam)..' ptr='..emu.read(6,emu.memType.gsuWorkRam)..'\n')
    for k,v in pairs(emu.getInput(0)) do f:write('input '..k..'='..tostring(v)..'\n') end
    f:write('joy='..emu.read(0x4218,emu.memType.snesMemory)..' hi='..emu.read(0x4219,emu.memType.snesMemory)..'\n')
    f:close()
  end
  report:write(string.format('{"field":%d,"logic":%d,"x":%d,"y":%d,"player":%d,"stage":%d,"enemies":%d,"shots":%d,"enemyShots":%d,"boss":%d,"hp":%d,"commands":%d,"cpuPC":%d,"ppuLine":%d,"gsuGO":%d}\n',
    field,read('_monosh_runtime_frame_counter',2),read('_monosh_player_x',2),read('_monosh_player_bottom',2),read('_monosh_player_state'),
    read('_monosh_stage_frame_counter',2),read('_monosh_enemy_active_count_value'),read('_monosh_player_bullet_count'),read('_monosh_enemy_bullet_count'),
    read('_monosh_boss_state'),read('_monosh_boss_hp'),read('_fx_packet_count',2),s['cpu.pc'],s['ppu.scanline'],emu.read(0x3030,emu.memType.snesMemory)))
  report:flush()
end
emu.addMemoryCallback(guard(function(a,v)
  if v~=1 then return end
  local s=emu.getState()
  gsu_start=s['cart.coprocessor.cycleCount'];clock_start=s.masterClock
  profile.last=nil
  if rendered==0 then
    for i=0,15 do emu.write(0x1ff0+i,0xa5,emu.memType.gsuWorkRam);emu.write(0x5000+i,0x5a,emu.memType.gsuWorkRam) end
  end
  if rendered==0 or (rendered+1)%300==0 or (scenario=='packed' and rendered<8) or (scenario=='objects' and (rendered+1)%((labels.dma_probe_delay and rendered>300) and 32 or 4)==0) then
    dump(string.format('draw%05d.bin',rendered+1),emu.memType.snesMemory,0x7E0000+labels._fx_draw,640)
    dump(string.format('obj%05d.bin',rendered+1),emu.memType.snesMemory,0x7E0000+labels.fx_obj_present,136)
    local f=assert(io.open(output..string.format('/meta%05d.json',rendered+1),'w'))
    f:write(encoded({count=read('_fx_draw_count'),logic=read('_monosh_runtime_frame_counter',2),gsuUv=gsu_uv,gsuClip=gsu_clip,cpuClipCommands=cpu_clip_commands}));f:close()
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=2 then return end
  local s=emu.getState()
  local joined=elapsed(s.masterClock,clock_start)
  stats.cpuMaxMs=math.max(stats.cpuMaxMs,joined)
  report:write(string.format('{"joinedMs":%.5f,"cpuMs":%.5f,"gsuMs":%.5f,"field":%d}\n',joined,cpu_ms,gsu_ms,field))
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=3 then return end
  local s=emu.getState()
  dma_start=s.masterClock
  local line=s['ppu.scanline'];local count=read('fx_dma_count',2)
  local deadline=emu.read(0x7e1d10,emu.memType.snesMemory)
  -- 画像差し替え後はHDMAポインタ更新と可変長OAMに最大4行を要する。
  -- 完了側でも21行以内を検査し、22行OBJ準備の余裕を独立に守る。
  assert(line>=203 and line<=deadline+4,'DMA start outside admitted blank window')
  local weight=read('fx_dma_bytes',2)+count*(labels.select_dma_deadline and 64 or 128)+(labels.select_dma_deadline and 768 or 0)
  if labels.fx_upload_color then weight=weight+64+(read('fx_color_staged',2)==0 and (read('fx_color_dma_bytes',2)+read('fx_color_dma_count',2)*64) or 0) end
  if deadline>203 then
    local limit=deadline==220 and 9984 or deadline==226 and 8960 or deadline==233 and 7680
    if labels.dma_deadline_fine then limit=math.min(9984,(279-deadline)*170-1) end
    assert(limit and weight<=math.min(limit,9984),'large DMA admitted late')
  end
  stats.lateDmaStarts=(stats.lateDmaStarts or 0)+(line>206 and 1 or 0)
  stats.maxDmaStartLine=math.max(stats.maxDmaStartLine or 0,line)
  stats.maxDmaSpanCount=math.max(stats.maxDmaSpanCount or 0,count)
  report:write(string.format('{"dmaStartLine":%d,"spans":%d,"deadline":%d,"field":%d,"colorReserve":%d}\n',line,count,deadline,field,weight-read('fx_dma_bytes',2)-count*(labels.select_dma_deadline and 64 or 128)-(labels.select_dma_deadline and 768 or 0)))
  if rendered==0 then
    local f=io.open(output..'/descriptors.txt','w')
    for i=0,31 do
      local addr=0x7E0000+labels.fx_dma_desc+i*4
      local a=emu.read(addr,emu.memType.snesMemory)+256*emu.read(addr+1,emu.memType.snesMemory)
      local n=emu.read(addr+2,emu.memType.snesMemory)+256*emu.read(addr+3,emu.memType.snesMemory)
      f:write(i..' '..a..' '..n..'\n')
    end
    f:close()
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=4 then return end
  rendered=rendered+1
  local s=emu.getState()
  assert(s['ppu.scanline']<23 or s['ppu.scanline']>=203,'DMA overlaps visible area')
  assert(s['ppu.scanline']<=21 or s['ppu.scanline']>=203,'DMA missed OBJ preparation margin')
  local duration=elapsed(s.masterClock,dma_start)
  local bytes=read('fx_dma_bytes',2)
  stats.objMaxCount=math.max(stats.objMaxCount or 0,read('fx_obj_present_count',2))
  assert(read('fx_obj_overflow',2)==0,'OBJ packet capacity exceeded')
  for i=0,127 do assert(emu.read(i,emu.memType.snesSpriteRam)==byte('fx_obj_present',i),'OAM low snapshot differs') end
  for i=0,7 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==byte('fx_obj_present',128+i),'OAM high snapshot differs') end
  stats.dmaMaxMs=math.max(stats.dmaMaxMs,duration)
  stats.minBytes=math.min(stats.minBytes,bytes);stats.maxBytes=math.max(stats.maxBytes,bytes)
  local interval=field-previous_field;previous_field=field
  if rendered>1 then if interval==1 then stats.interval1=stats.interval1+1 elseif interval==2 then stats.interval2=stats.interval2+1 else stats.interval3plus=stats.interval3plus+1 end end
  local boss=read('_monosh_boss_state');local player=read('_monosh_player_state')
  stats.enemyShotsMax=math.max(stats.enemyShotsMax or 0,read('_monosh_enemy_bullet_count'))
  if boss==1 then stats.bossSeen=true elseif boss==2 then stats.dyingSeen=true elseif boss==3 then stats.doneSeen=true end
  if previous_boss==3 and boss==0 then stats.loopSeen=true end
  if boss~=previous_boss then screenshot('boss_state'..boss) end
  if previous_player==0 and player~=0 then stats.deaths=stats.deaths+1 end
  if previous_player~=0 and player==0 then stats.respawns=stats.respawns+1 end
  if read('_monosh_player_stumble')>0 then stats.stumbles=stats.stumbles+1 end
  stats.stumbleMax=math.max(stats.stumbleMax or 0,read('_monosh_player_stumble'))
  stats.reflected=math.max(stats.reflected,read('_monosh_reflected_bullet_count'))
  previous_boss=boss;previous_player=player
  for i=0,read('_monosh_enemy_active_count_value')-1 do
    local addr=0x7E0000+labels._monosh_enemies+i*10
    local t=emu.read(addr+1,emu.memType.snesMemory);stats.enemyTypes[t]=true
    if t==5 then stats.enemyPaths[emu.read(addr+2,emu.memType.snesMemory)]=true end
    if t==6 then stats.em1States[emu.read(0x7E0000+labels._monosh_enemy_em1_phase+i*2+1,emu.memType.snesMemory)]=true end
  end
  stats.maxCommands=math.max(stats.maxCommands,read('_fx_packet_count',2))
  report:write(string.format('{"dmaMs":%.5f,"bytes":%d,"line":%d,"field":%d,"rendered":%d}\n',duration,bytes,s['ppu.scanline'],field,rendered))
  if maxframe<=720 or rendered<=10 or rendered%30==0 then
  local same=0
  for i=0,12287 do if emu.read(0x2000+i,emu.memType.gsuWorkRam)==emu.read(i,emu.memType.snesVideoRam) then same=same+1 end end
  if same~=12288 then
    local raw={};local f=io.open(output..'/vram.bin','wb')
    for i=0,12287 do raw[#raw+1]=string.char(emu.read(i,emu.memType.snesVideoRam)) end
    f:write(table.concat(raw));f:close()
    raw={};f=io.open(output..'/failed_fb.bin','wb')
    for i=0,12287 do raw[#raw+1]=string.char(emu.read(0x2000+i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(raw));f:close()
    f=io.open(output..'/state_dma.txt','w')
    for k,v in pairs(s) do if k:find('dma') or k:find('ppu.vram') then f:write(k..'='..tostring(v)..'\n') end end
    f:close()
    local f=io.open(output..'/dma_debug.txt','w')
    for i=0,12287 do if emu.read(0x2000+i,emu.memType.gsuWorkRam)~=emu.read(i,emu.memType.snesVideoRam) then f:write(i..'='..emu.read(0x2000+i,emu.memType.gsuWorkRam)..' vs '..emu.read(i,emu.memType.snesVideoRam)..'\n') end end
    f:close()
  end
  assert(same==12288,'partial DMA: '..same)
  stats.checked=stats.checked+1
  for i=0,15 do assert(emu.read(0x1ff0+i,emu.memType.gsuWorkRam)==0xa5 and emu.read(0x5000+i,emu.memType.gsuWorkRam)==0x5a,'GSU clip writes outside framebuffer') end
  local current=emu.read(0,emu.memType.snesCgRam)+256*emu.read(1,emu.memType.snesCgRam)
  local valid=false
  for i=0,(labels.fx_sky_colors_end-labels.fx_sky_colors)//4-1 do
    if current==byte('fx_sky_colors',i*4+2)+256*byte('fx_sky_colors',i*4+3) then valid=true end
  end
  assert(valid,'sky gradient palette corrupted')
  end
  if rendered==1 then
    local f=io.open(output..'/framebuffer.bin','wb'); local b={}
    for i=0,12287 do b[#b+1]=string.char(emu.read(0x2000+i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(b));f:close()
    f=io.open(output..'/packet.bin','wb');b={}
    for i=0,1311 do b[#b+1]=string.char(emu.read(i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(b));f:close()
  end
  if rendered==1 or rendered%300==0 or (scenario=='packed' and rendered<=8) or (scenario=='objects' and rendered%((labels.dma_probe_delay and rendered>300) and 32 or 4)==0) then
    dump(string.format('frame%05d.bin',rendered),emu.memType.gsuWorkRam,0x2000,12288)
    dump(string.format('packet%05d.bin',rendered),emu.memType.gsuWorkRam,0,1312)
    dump(string.format('oam%05d.bin',rendered),emu.memType.snesSpriteRam,0,544)
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addEventCallback(guard(function()
  if scenario=='held' then
    local input={}
    for direction in held_direction:gmatch('[^-]+') do if direction~='none' then input[direction]=true end end
    if held_fire~='none' then input[held_fire]=true end
    emu.setInput(input,0)
  elseif scenario=='play' then
    emu.setInput({a=true,up=field>150 and field<180,right=field>180 and field<210,left=field>240 and field<275},0)
  elseif scenario=='long' or scenario=='profile' then
    if read('_monosh_boss_state')==1 then
      local z=byte('_boss_part_z',0)
      local tx=byte('_boss_part_x',0)
      local ty=byte('_boss_part_bottom',0)-byte('_monosh_boss_face_geometry',math.min(z,110)*2+1)//2+20
      local x=read('_monosh_player_x',2);local y=read('_monosh_player_bottom',2)
      emu.setInput({a=true,right=x<tx-3,left=x>tx+3,up=y>ty+3,down=y<ty-3},0)
    else emu.setInput({a=true},0) end
  elseif scenario=='boss' then emu.setInput({},0)
  elseif scenario=='pause' then
    emu.setInput({a=true,start=(field>=151 and field<=154) or (field>=211 and field<=214)},0)
  elseif scenario=='controls' then
    emu.setInput({right=field>=301 and field<=330,left=field>=361 and field<=390,
                  down=field>=401 and field<=430,up=field>=461 and field<=490,y=field>=601 and field<=606},0)
  end
end),emu.eventType.inputPolled)
emu.addEventCallback(guard(function()
  assert(emu.read(0x213e,emu.memType.snesMemory)&0xc0==0,'OBJ scanline range/time overflow')
end),emu.eventType.endFrame)
emu.addEventCallback(guard(function()
  if not game_started then return end
  field=field+1
  local status=emu.read(0x213e,emu.memType.snesMemory)
  assert(status&0xc0==0,'OBJ range/time overflow')
  if rendered>0 then
    if scenario=='held' and held_direction=='none' and field>=90 and field<=150 then
      screenshot(string.format('shot%05d',field))
    end
    if read('_monosh_boss_state')==1 and read('_boss_age')>=100 and not stats.bossImage then screenshot('scene_boss');stats.bossImage=true end
    if read('_monosh_enemy_active_count_value')>=3 and not stats.enemyImage then screenshot('scene_enemies');stats.enemyImage=true end
    if read('_monosh_player_state')~=0 and not stats.deathImage then screenshot('scene_death');stats.deathImage=true end
  end
  if scenario=='controls' and rendered>0 then
    if field==335 then assert(read('_monosh_player_x',2)>128,'right input failed') end
    if field==435 then stats.controlUpY=read('_monosh_player_bottom',2);assert(stats.controlUpY<120,'reverse down input failed') end
    if field==495 then assert(read('_monosh_player_bottom',2)>stats.controlUpY,'reverse up input failed') end
    stats.singleShotMax=math.max(stats.singleShotMax or 0,read('_monosh_player_bullet_count'))
  end
  if scenario=='pause' then
    if field==165 then stats.pauseLogic=read('_monosh_runtime_frame_counter',2) end
    if field==195 then assert(read('_monosh_runtime_frame_counter',2)==stats.pauseLogic,'pause keeps updating logic') end
    if field==240 then assert(read('_monosh_runtime_frame_counter',2)>stats.pauseLogic,'pause did not resume') end
  end
  if field%30==0 then trace() end
  if scenario=='held' then
    if rendered>0 then
      local logic=read('_monosh_runtime_frame_counter',2)
      if logic~=last_logic then last_logic=logic;last_logic_field=field end
      stats.maxLogicGap=math.max(stats.maxLogicGap or 0,field-last_logic_field)
      assert(read('_monosh_runtime_paused')==0,'unexpected pause without Start: cached JOY1='..read('_fx_buttons',2)..' field='..field)
      assert(field-last_logic_field<=90,'logic frozen while frames continue')
      if field>=60 then
        local bits={right=0x100,left=0x200,down=0x400,up=0x800,a=0x80,y=0x4000}
        local expected=bits[held_fire] or 0
        for direction in held_direction:gmatch('[^-]+') do expected=expected|(bits[direction] or 0) end
        assert(read('_fx_buttons',2)==expected,'held buttons were sampled mid-shift: '..read('_fx_buttons',2)..' expected '..expected)
        stats.heldSamplesChecked=(stats.heldSamplesChecked or 0)+1
      end
    end
    local gap=field-previous_field
    stats.maxPresentationGap=math.max(stats.maxPresentationGap or 0,rendered>0 and gap or 0)
    if gap>90 and field>120 then
      local f=assert(io.open(output..'/freeze_state.json','w'))
      f:write(encoded(emu.getState()));f:close()
      dump('freeze_wram.bin',emu.memType.snesMemory,0x7e0000,65536)
      dump('freeze_gsu.bin',emu.memType.gsuWorkRam,0,32768)
      dump('freeze_registers.bin',emu.memType.snesMemory,0x3000,128)
      screenshot('freeze')
      trace()
      assert(false,'presentation frozen: '..gap..' fields without a new image; rendered='..rendered..' field='..field)
    end
  end
  if field==120 or field==240 or field==maxframe then
    local f=assert(io.open(output..'/field'..field..'.rgb','wb'));local rgb={}
    for _,v in ipairs(emu.getScreenBuffer()) do rgb[#rgb+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
    f:write(table.concat(rgb));f:close()
  end
  if field>=maxframe then
    stats.fields=field;stats.rendered=rendered;stats.logic=read('_monosh_runtime_frame_counter',2);stats.stage=read('_monosh_stage_frame_counter',2)
    local f=assert(io.open(output..'/summary.json','w'));f:write(encoded(stats));f:close()
    assert(rendered>1,'no presented frames')
    if scenario=='packed' then for _,name in ipairs({'packed_one','packed_half','packed_quarter','packed_double',
      'packed_mirror_one','packed_mirror_half','packed_mirror_quarter'}) do assert((stats[name] or 0)>0,'unused packed path: '..name) end end
    if scenario=='packed' then for tail=0,7 do assert(stats.doubleTailRequests[tail],'unused double tail: '..tail) end end
    if scenario=='boss' then assert(stats.bossSeen and stats.dyingSeen and stats.doneSeen and stats.loopSeen,'boss progression incomplete') end
    if scenario=='long' then assert(stats.bossSeen and stats.loopSeen and stats.deaths>0 and stats.respawns>0,'natural stage progression incomplete') end
    if scenario=='controls' then assert(stats.singleShotMax==1,'single shot was not exactly one slot') end
    if scenario=='stumble' then assert(stats.stumbles==39 and stats.stumbleMax==39 and read('_monosh_player_stumble')==0,'40-update bush stumble/recovery failed') end
    report:close();emu.stop(0);return
  end
  if scenario=='play' then
    emu.setInput({a=true,up=field>150 and field<180,right=field>180 and field<210,left=field>240 and field<275},0)
  end
end),emu.eventType.endFrame)

-- 実入力のSELECT押下・保持・再押下と、奥行き/反転/clip/消去を一つのROMで検証。
local latched_draw,latched_logic,latched_mode,latched_count
local color_samples=0
local fixture_case,latched_case
local function memblob(mem,address,n)
  local b={};for i=0,n-1 do b[#b+1]=string.char(emu.read(address+i,mem)) end
  return table.concat(b)
end
emu.addMemoryCallback(guard(function()
  local n=read('_monosh_runtime_frame_counter',2)
  local case=n%8
  if field>=40 and field<=210 then case=0 end
  fixture_case=case
  local r={{48,196,52,122,4,0,80,0},{127,91,88,48,3,0,70,0},
           {146,170,100,68,13,0,60,0},{143,175,60,92,14,0,40,0},
           {223,117,36,54,7,0,30,0},{127,142,60,48,31,0,20,0}}
  if case==1 then r[4][6]=16;r[3][6]=32 end
  if case==2 then r[1][1]=-3;r[4][1]=256 end
  if case==3 then r[4][2]=40;r[3][2]=235;r[3][6]=32 end
  if case==4 then r[4][6]=128 end
  if case==5 then r={{128,180,1,1,13,0,20,0},{255,180,2,2,14,48,1,0}} end
  if case==6 then r={{128,160,20,20,14,0,1,0},{128,160,96,64,13,0,90,0},
                     {128,155,44,19,42,0,0,2},{128,150,32,48,9,0,0,2}} end
  if case==7 then r={{128,160,100,100,14,128,1,0},{128,160,0,0,13,0,1,0}} end
  for i,v in ipairs(r) do
    local b={v[1]&255,(v[1]>>8)&255,v[2]&255,(v[2]>>8)&255,v[3],v[4],v[5],v[6],v[7],v[8]}
    for j,c in ipairs(b) do put('_fx_draw',(i-1)*10+j-1,c) end
  end
  put('_fx_draw_count',0,#r)
end),emu.callbackType.exec,0x7f0000+labels._fx_build_packet,0x7f0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  latched_count=read('_fx_draw_count')
  latched_draw=memblob(emu.memType.snesMemory,0x7e0000+labels._fx_draw,latched_count*10)
  latched_logic=read('_monosh_runtime_frame_counter',2)
  latched_mode=read('fx_color_mode')
  latched_case=fixture_case
end),emu.callbackType.exec,0x7f0000+labels.fx_latch_color,0x7f0000+labels.fx_latch_color,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  local line=emu.getState()['ppu.scanline']
  assert(line<=21 or line>=203,'color staging entered visible lines: '..line)
end),emu.callbackType.exec,0x7f0000+labels.fx_color_stage_done,0x7f0000+labels.fx_color_stage_done,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function(a,v)
  if v~=4 then return end
  color_samples=color_samples+1
  local name=string.format('color%04d',color_samples)
  local f=assert(io.open(output..'/'..name..'_draw.bin','wb'));f:write(latched_draw);f:close()
  dump(name..'_map.bin',emu.memType.snesVideoRam,read('fx_color_vram_base',2)*2,1536)
  dump(name..'_cgram.bin',emu.memType.snesCgRam,64,64)
  if labels.gsu_color_begin then
    dump(name..'_ram.bin',emu.memType.gsuWorkRam,0x1000,768)
  else
    dump(name..'_ram.bin',emu.memType.snesMemory,0x7e0000+read('fx_color_present_ptr',2),768)
  end
  f=assert(io.open(output..'/'..name..'.json','w'))
  f:write(encoded({count=latched_count,logic=latched_logic,case=latched_case,mode=latched_mode,field=field,line=emu.getState()['ppu.scanline']}));f:close()
  assert(read('fx_color_present_mode')==latched_mode,'color mode generation differs')
  assert(read('c_sp',2)>=0x1800,'C stack reached color RAM')
end),emu.callbackType.write,0x7e1df0,0x7e1df0)
emu.addEventCallback(guard(function()
  emu.setInput({select=(field>=60 and field<76) or (field>=150 and field<166)},0)
end),emu.eventType.inputPolled)
emu.addEventCallback(guard(function()
  if field==55 or field==110 or field==200 then screenshot('color_mode_'..field) end
end),emu.eventType.startFrame)
