local labels = {["__BSS_LOAD__"]=58710,["__BSS_RUN__"]=58710,["__BSS_SIZE__"]=5559,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=60567,["__DATA_LOAD__"]=4375891,["__DATA_RUN__"]=58707,["__DATA_SIZE__"]=3,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50515,["__STARTUP__"]=1,["_abs"]=60198,["_boss_age"]=59325,["_boss_attribute_cache"]=59160,["_boss_attribute_cache_count"]=59322,["_boss_attribute_z_cache"]=59304,["_boss_dda_phase"]=59543,["_boss_dda_x"]=59549,["_boss_dda_y"]=59555,["_boss_death_parts"]=59327,["_boss_death_timer"]=59326,["_boss_fire_gap"]=59336,["_boss_fire_round"]=59333,["_boss_fire_shots"]=59335,["_boss_fire_state"]=59332,["_boss_fire_volley"]=59334,["_boss_history_x"]=58776,["_boss_history_y"]=58904,["_boss_history_z"]=59032,["_boss_last_vblank"]=58712,["_boss_motion_steps"]=59331,["_boss_part_active"]=58740,["_boss_part_bottom"]=58722,["_boss_part_fall_fraction"]=58767,["_boss_part_fall_velocity"]=58758,["_boss_part_timer"]=58749,["_boss_part_x"]=58713,["_boss_part_z"]=58731,["_boss_path_half"]=59330,["_boss_player_bottom"]=59339,["_boss_player_x"]=59337,["_boss_render_camera_delta"]=59323,["_boss_restart_timer"]=59328,["_boss_z_phase"]=59329,["_death_accel_fraction"]=59575,["_death_timer"]=59573,["_death_vy"]=59572,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_boss_hits"]=58508,["_fx_boss_project"]=58313,["_fx_build_ground"]=12811,["_fx_build_packet"]=23217,["_fx_buttons"]=61741,["_fx_draw"]=59817,["_fx_draw_count"]=60457,["_fx_em0_geometry"]=55555,["_fx_enemy_collisions"]=55035,["_fx_enemy_em1_update"]=56431,["_fx_enemy_em1_update_reference"]=7583,["_fx_enemy_fire_em1"]=7521,["_fx_enemy_remove"]=7510,["_fx_enemy_render"]=54402,["_fx_enemy_render_bullets"]=54684,["_fx_far_d_acc"]=61753,["_fx_far_u_acc"]=61751,["_fx_fire_actions"]=61744,["_fx_frame"]=57335,["_fx_ground_c1ptr"]=63509,["_fx_ground_c3ptr"]=63511,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=61760,["_fx_ground_color3"]=62210,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63475,["_fx_ground_far_xptr"]=63505,["_fx_ground_far_y"]=63515,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63513,["_fx_ground_horizontal"]=62660,["_fx_ground_hptr"]=63470,["_fx_ground_native"]=12889,["_fx_ground_palette_record"]=63473,["_fx_ground_phase"]=61740,["_fx_ground_vptr"]=63507,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63472,["_fx_init"]=11702,["_fx_input"]=61743,["_fx_packet"]=60460,["_fx_packet_count"]=60458,["_fx_present"]=12370,["_fx_read_input"]=12170,["_fx_send_ground"]=12202,["_fx_sky_color"]=39095,["_fx_stage_contact"]=53718,["_fx_stage_render"]=53019,["_fx_stage_update"]=54049,["_fx_submit"]=59291,["_ground_irq_vblank_count"]=61748,["_history_head"]=59324,["_hit_pending"]=61755,["_intro_timer"]=59576,["_legacy_enemy_fire_boss_at"]=6115,["_main"]=11739,["_memcpy"]=60029,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=58711,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2096,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=58093,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=58710,["_monosh_bullet_reflect_rng"]=59381,["_monosh_collision_bullet_bands"]=59373,["_monosh_combat_build_collision_bands"]=2278,["_monosh_combat_fast_cache_reset"]=12100,["_monosh_combat_fast_frame"]=58862,["_monosh_combat_fast_render"]=58984,["_monosh_combat_fast_render_cached"]=12107,["_monosh_combat_fire_cooldown"]=59382,["_monosh_combat_half_frame"]=59383,["_monosh_combat_init"]=2122,["_monosh_combat_reflect_bullet"]=11750,["_monosh_combat_render"]=2275,["_monosh_combat_update"]=2217,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59538,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59387,["_monosh_enemy_active_count"]=3038,["_monosh_enemy_active_count_value"]=59385,["_monosh_enemy_bullet_count"]=59384,["_monosh_enemy_bullets"]=59467,["_monosh_enemy_camera_delta_cached"]=59536,["_monosh_enemy_collision_cursor"]=59541,["_monosh_enemy_draw_cache_valid"]=59539,["_monosh_enemy_em1_count"]=59537,["_monosh_enemy_em1_phase"]=59512,["_monosh_enemy_em1_shrink"]=59528,["_monosh_enemy_fast_advance"]=56023,["_monosh_enemy_fast_check_player_bullets"]=4128,["_monosh_enemy_fast_render"]=3613,["_monosh_enemy_fast_render_bullets"]=5078,["_monosh_enemy_fast_spawn_due"]=5454,["_monosh_enemy_fast_update_bullets"]=55693,["_monosh_enemy_fire_at"]=3050,["_monosh_enemy_fire_boss_at"]=3079,["_monosh_enemy_fire_em0_fast"]=6513,["_monosh_enemy_frame"]=2841,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59540,["_monosh_enemy_init"]=2692,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59542,["_monosh_enemy_render_only"]=2871,["_monosh_enemy_spawn_index"]=59509,["_monosh_enemy_spawn_wait"]=59510,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3044,["_monosh_enemy_stage_complete_flag"]=59386,["_monosh_ground_depth_pointer"]=61758,["_monosh_ground_offset"]=58707,["_monosh_ground_screen_delta"]=58708,["_monosh_player_bottom"]=59563,["_monosh_player_bullet_count"]=59356,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59341,["_monosh_player_can_fire"]=9354,["_monosh_player_draw_asset"]=9370,["_monosh_player_draw_flags"]=9312,["_monosh_player_init"]=9249,["_monosh_player_invuln"]=59566,["_monosh_player_pose"]=59568,["_monosh_player_state"]=59565,["_monosh_player_stumble"]=59567,["_monosh_player_update"]=56725,["_monosh_player_update_reference"]=10579,["_monosh_player_world_active"]=9348,["_monosh_player_x"]=59561,["_monosh_project_x"]=24196,["_monosh_reflected_bullet_count"]=59372,["_monosh_reflected_bullets"]=59357,["_monosh_runtime_fire_actions"]=61745,["_monosh_runtime_frame_counter"]=61746,["_monosh_runtime_paused"]=61750,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=59815,["_monosh_stage_collision_bullet_index"]=59816,["_monosh_stage_contact_result"]=59813,["_monosh_stage_draw_cache_valid"]=59814,["_monosh_stage_frame"]=10854,["_monosh_stage_frame_counter"]=59677,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59681,["_monosh_stage_hitbox_count"]=59811,["_monosh_stage_hitboxes"]=59683,["_monosh_stage_init"]=10819,["_monosh_stage_is_clear"]=10903,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59682,["_monosh_stage_need_hitboxes"]=59812,["_monosh_stage_object_count"]=59675,["_monosh_stage_objects"]=59579,["_monosh_stage_render_only"]=10900,["_monosh_stage_spawn_index"]=59676,["_monosh_stage_spawn_wait"]=59679,["_monosh_stage_title_timer"]=59569,["_monosh_title_draw"]=11728,["_monosh_title_visible"]=58709,["_movement_fraction"]=59574,["_old_buttons"]=61756,["_player_flip"]=59577,["_player_fy"]=59570,["_player_run_phase"]=59578,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12101,["addeq0sp"]=59531,["addeqysp"]=59533,["addysp"]=59549,["addysp1"]=59548,["aslax2"]=59562,["aslax3"]=59573,["aslax4"]=59587,["asleax1"]=59604,["asrax1"]=59616,["asrax2"]=59626,["asrax3"]=59641,["booleq"]=59991,["boolge"]=60008,["boolgt"]=60006,["boolle"]=59998,["boollt"]=60000,["boolne"]=59985,["booluge"]=60024,["boolugt"]=60022,["boolule"]=60014,["boolult"]=60016,["c_sp"]=32,["decsp1"]=59661,["decsp2"]=59670,["decsp3"]=59683,["decsp4"]=59696,["decsp5"]=59709,["dma_finished"]=12779,["dma_started"]=12721,["fx_add_next_bounds"]=59290,["fx_build_obj"]=23568,["fx_commit_dma"]=59290,["fx_dma_bytes"]=64139,["fx_dma_count"]=64137,["fx_dma_desc"]=64141,["fx_emit_native"]=54898,["fx_is_obj"]=23483,["fx_latch_obj"]=24074,["fx_obj_count"]=63913,["fx_obj_next"]=63777,["fx_obj_overflow"]=63917,["fx_obj_present"]=63845,["fx_obj_present_count"]=63915,["fx_obj_upload_done"]=24186,["fx_plan_dma"]=59271,["fx_project16"]=24226,["fx_reset_next_bounds"]=59290,["fx_upload_ground"]=13164,["fx_upload_obj"]=24098,["game_started"]=12110,["ground_done"]=13132,["ground_empty"]=13258,["incsp1"]=59789,["incsp2"]=59804,["incsp3"]=59818,["incsp4"]=59823,["incsp5"]=59828,["incsp6"]=59833,["incsp7"]=59838,["incsp8"]=59843,["ldaidx"]=59848,["memcpy_getparams"]=60070,["memcpy_upwards"]=60032,["mulax10"]=60089,["mulax3"]=60114,["mulax5"]=60131,["mulax6"]=60151,["mulax7"]=60173,["negax"]=60202,["packed_double"]=99470,["packed_half"]=99188,["packed_mirror_half"]=99362,["packed_mirror_one"]=99296,["packed_mirror_quarter"]=99421,["packed_one"]=99122,["packed_quarter"]=99247,["packet_done"]=23392,["popax"]=59796,["popptr1"]=60216,["popsargsudiv16"]=60306,["ptr1"]=40,["ptr2"]=42,["ptr3"]=44,["ptr4"]=46,["push0"]=60252,["push0ax"]=59955,["pusha"]=60234,["pusha0"]=60254,["pusha0sp"]=60230,["pushax"]=60256,["pushaysp"]=60232,["pusheax"]=59961,["pushl0"]=59952,["pushw0sp"]=60278,["pushwysp"]=60280,["regbank"]=52,["regsave"]=36,["render_entry"]=98304,["render_finished"]=12552,["render_started"]=12520,["render_stop"]=99809,["reset"]=32768,["shlax2"]=59562,["shlax3"]=59573,["shlax4"]=59587,["shleax1"]=59604,["shrax1"]=60338,["shrax3"]=60346,["shrax4"]=60360,["sreg"]=34,["stage_update_done"]=54400,["staspidx"]=60377,["stax0sp"]=60399,["staxspidx"]=60410,["staxysp"]=60401,["subysp"]=60458,["tmp1"]=48,["tmp2"]=49,["tmp3"]=50,["tmp4"]=51,["tosadda0"]=59503,["tosaddax"]=59505,["tosdiva0"]=59722,["tosdivax"]=59724,["tosicmp"]=59745,["tosicmp0"]=59743,["tosmul0ax"]=59860,["tosmuleax"]=59866,["tossuba0"]=60437,["tossubax"]=60439,["tosudiva0"]=60471,["tosudivax"]=60473,["tosumoda0"]=60550,["tosumodax"]=60552,["tosumul0ax"]=59860,["tosumuleax"]=59866,["udiv16"]=60488,["L1"]=60522,["@L1"]=60540,["Pos"]=59740,["@L3"]=59781,["@L4"]=59782,["@L2"]=60544,["L0"]=60498,["mul32"]=59866,["ret0"]=59987,["ret1"]=59993,["L3"]=60059,["done"]=60067,["L2"]=60331,["@L0"]=60529,["udiv16by8a"]=60529,["cpu_frame_return"]=12542,["admission_ready"]=12634}
local output = "D:/AI/Nao_u_BOT/GPT/projects/monosh_fx2/build/game_v001/boss_profile"
local maxframe = 18000
local scenario = "profile"
local held_direction = "none"
local held_fire = "none"
local gsu_uv = true
local gsu_clip = true
local report = assert(io.open(output..'/trace.jsonl','w'))
local field = 0
local rendered = 0
local clock_start = 0
local gsu_start = 0
local dma_start = 0
local profile={}
local native_profile={}
local failed=false
local previous_field,previous_boss,previous_player=0,0,0
local last_logic,last_logic_field=-1,0
local stats={fields=0,rendered=0,checked=0,deaths=0,respawns=0,bossSeen=false,dyingSeen=false,doneSeen=false,loopSeen=false,
             enemyTypes={},enemyPaths={},em1States={},stumbles=0,reflected=0,maxCommands=0,minBytes=65535,maxBytes=0,
             interval1=0,interval2=0,interval3plus=0,cpuMaxMs=0,gsuMaxMs=0,dmaMaxMs=0}
local gsu_ms=0
local cpu_ms=0
-- Mesen LuaのmasterClockはuint32。約200秒ごとのwrapを時間差で吸収する。
local function elapsed(now,started) return ((now-started)&0xffffffff)/21477.272 end
local fixture_started=false
local function dump(name,memtype,address,count)
  local f=assert(io.open(output..'/'..name,'wb'));local bytes={}
  for i=0,count-1 do bytes[#bytes+1]=string.char(emu.read(address+i,memtype)) end
  f:write(table.concat(bytes));f:close()
end
local function screenshot(name)
  local f=assert(io.open(output..'/'..name..'.rgb','wb'));local rgb={}
  for _,v in ipairs(emu.getScreenBuffer()) do rgb[#rgb+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
  f:write(table.concat(rgb));f:close()
end
local function byte(name,offset)
  return emu.read(0x7E0000+assert(labels[name])+offset,emu.memType.snesMemory)
end
local function put(name,offset,value)
  emu.write(0x7E0000+assert(labels[name])+offset,value&255,emu.memType.snesMemory)
end
local function encoded(v)
  if type(v)=='table' then local out={};for k,x in pairs(v) do out[#out+1]='"'..tostring(k)..'":'..encoded(x) end;return '{'..table.concat(out,',')..'}' end
  if type(v)=='string' then return '"'..v..'"' end
  return tostring(v)
end
local function read(name, size)
  local addr=0x7E0000+assert(labels[name],name)
  local v=emu.read(addr,emu.memType.snesMemory)
  if size==2 then v=v+256*emu.read(addr+1,emu.memType.snesMemory) end
  return v
end
local function write(name,v)
  emu.write(0x7E0000+assert(labels[name]),v&255,emu.memType.snesMemory)
  emu.write(0x7E0000+assert(labels[name])+1,v>>8,emu.memType.snesMemory)
end
local function guard(fn)
  return function(...)
    if failed then return end
    local ok,err=pcall(fn,...)
    if not ok then
      failed=true
      local state=io.open(output..'/failure_state.json','w')
      state:write(encoded(emu.getState()));state:close()
      dump('failure_wram.bin',emu.memType.snesMemory,0x7e0000,65536)
      local input=io.open(output..'/failure_input.json','w')
      input:write(encoded(emu.getInput(0)));input:close()
      local q=io.open(output..'/debugram.bin','wb'); local t={}
      for k=0,32767 do t[#t+1]=string.char(emu.read(k,emu.memType.gsuWorkRam)) end
      q:write(table.concat(t)); q:close()
      local f=io.open(output..'/error.txt','w'); f:write(tostring(err)); f:close(); report:close();emu.stop(1)
    end
  end
end
-- 最終PPU合成の検査。三つのcamera高さで同じFX画像と四つの地上物を描く。
if scenario=='display' then
  emu.addMemoryCallback(guard(function()
    local offset=field<240 and 0 or (field<480 and 32 or 64)
    put('_monosh_ground_offset',0,offset)
    put('_fx_ground_world_phase',0,32)
    put('_fx_ground_phase',0,6)
    local records={}
    for i,z in ipairs({0,24,60,110}) do
      local geometry=labels._monosh_stage_geometry+4*2
      local gp=emu.read(0x7e0000+geometry,emu.memType.snesMemory)+256*emu.read(0x7e0000+geometry+1,emu.memType.snesMemory)
      local w=emu.read(0x7e0000+gp+z*4,emu.memType.snesMemory)
      local h=emu.read(0x7e0000+gp+z*4+1,emu.memType.snesMemory)
      local source=emu.read(0x7e0000+gp+z*4+2,emu.memType.snesMemory)
      local d=byte('_fx_ground_depth_rows',offset*81+219-source)
      local sink=z>=9 and 3 or (z>=6 and 2 or (z>=2 and 1 or 0))
      records[#records+1]={({35,107,178,231})[i],207-d+sink,w,h,4,0,z,0}
    end
    records[#records+1]={66,90,32,48,9,0,0,2}
    records[#records+1]={184,75,88,38,42,0,0,2}
    for i,r in ipairs(records) do
      local data={r[1]&255,(r[1]>>8)&255,r[2]&255,(r[2]>>8)&255,r[3],r[4],r[5],r[6],r[7],r[8]}
      for j,v in ipairs(data) do put('_fx_draw',(i-1)*10+j-1,v) end
    end
    put('_fx_draw_count',0,#records)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
  local selected={[238]=true,[478]=true,[718]=true}
  emu.addEventCallback(guard(function()
    if not selected[field] then return end
    local prefix=string.format('display%05d',field)
    dump(prefix..'_vram.bin',emu.memType.snesVideoRam,0,65536)
    dump(prefix..'_cgram.bin',emu.memType.snesCgRam,0,512)
    dump(prefix..'_oam.bin',emu.memType.snesSpriteRam,0,544)
    local meta={}
    for _,r in ipairs({{'v',0x1d04,500,0x7f0000},{'c1',0x1d06,128,0x7e0000},
        {'c3',0x1d08,128,0x7e0000},{'far',0x1d0c,10,0x7e0000},{'h',0x1d0e,270,0x7e0000}}) do
      local p=emu.read(0x7e0000+r[2],emu.memType.snesMemory)+256*emu.read(0x7e0000+r[2]+1,emu.memType.snesMemory)
      dump(prefix..'_'..r[1]..'.bin',emu.memType.snesMemory,r[4]+p,r[3])
    end
    local far=emu.read(0x7e1d0a,emu.memType.snesMemory)+256*emu.read(0x7e1d0b,emu.memType.snesMemory)
    if far>=32768 then far=far-65536 end
    meta.farY=far;meta.offset=14-far
    local f=assert(io.open(output..'/'..prefix..'.json','w'));f:write(encoded(meta));f:close()
  end),emu.eventType.startFrame)
  emu.addEventCallback(guard(function()
    if selected[field] then screenshot(string.format('display%05d',field)) end
  end),emu.eventType.endFrame)
end

emu.addMemoryCallback(guard(function()
  report:write(string.format('{"bootSky":%d,"skyConstant":%d}\n',emu.read(0,emu.memType.snesCgRam)+256*emu.read(1,emu.memType.snesCgRam),read('_fx_sky_color',2)))
end),emu.callbackType.exec,0x7f0000+labels.game_started,0x7f0000+labels.game_started,emu.cpuType.snes,emu.memType.snesMemory)
local obj_clock=0
emu.addMemoryCallback(guard(function() obj_clock=emu.getState().masterClock end),
  emu.callbackType.exec,0x7F0000+labels.fx_upload_obj,0x7F0000+labels.fx_upload_obj,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  report:write(string.format('{"objMs":%.6f,"objBytes":68,"field":%d}\n',elapsed(emu.getState().masterClock,obj_clock),field))
end),emu.callbackType.exec,0x7F0000+labels.fx_obj_upload_done,0x7F0000+labels.fx_obj_upload_done,emu.cpuType.snes,emu.memType.snesMemory)
if scenario=='objects' then
  emu.addEventCallback(guard(function()
    -- StartFrameでは直前の完成RGB、OAMは次に走査するfieldのもの。
    if field>=41 and field<=301 and (field-1)%4==0 then screenshot(string.format('objview%05d',field-1)) end
    if field>=40 and field<=300 and field%4==0 then
      dump(string.format('objview%05d_oam.bin',field),emu.memType.snesSpriteRam,0,544)
      dump(string.format('objview%05d_cgram.bin',field),emu.memType.snesCgRam,0,512)
    end
  end),emu.eventType.startFrame)
  emu.addMemoryCallback(guard(function()
    local n=read('_monosh_runtime_frame_counter',2)
    local poses={9,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30}
    local r={{128,165,68,158,4,0,0,0}}
    for i=1,6 do
      local size=1+(n+i)%16
      r[#r+1]={100+i*8,100+i*4,size,size,10,0,0,2}
    end
    local flags=((n//17)%4)*16
    if (n//68)%2==1 then flags=flags|128 end
    r[#r+1]={({0,256,128,128})[1+(n//4)%4],({48,180,28,230})[1+(n//7)%4],32,48,poses[1+n%17],flags,0,2}
    for i,v in ipairs(r) do
      local b={v[1]&255,(v[1]>>8)&255,v[2]&255,(v[2]>>8)&255,v[3],v[4],v[5],v[6],v[7],v[8]}
      for j,c in ipairs(b) do put('_fx_draw',(i-1)*10+j-1,c) end
    end
    put('_fx_draw_count',0,#r)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
for _,name in ipairs({'packed_one','packed_half','packed_quarter','packed_double',
                     'packed_mirror_one','packed_mirror_half','packed_mirror_quarter'}) do
  emu.addMemoryCallback(guard(function() stats[name]=(stats[name] or 0)+1 end),
    emu.callbackType.exec,labels[name],labels[name],emu.cpuType.gsu,emu.memType.gsuMemory)
end
if scenario=='packed' then
  emu.addMemoryCallback(guard(function()
    local sprites={{40,100,32,48,0},{90,100,16,24,0},{125,100,8,12,0},
      {165,100,32,48,32},{0,100,32,48,0},{215,30,32,48,0},
      {4,180,16,24,0},{256,180,8,12,0},{120,170,32,48,16},
      {120,190,68,158,0,4},{35,200,68,158,32,4},
      {160,180,16,24,16},{200,180,8,12,48}}
    local tail=read('_monosh_runtime_frame_counter',2)%8
    sprites[#sprites+1]={256-(56+tail)+34,190,68,158,tail%2==0 and 0 or 32,4}
    stats.doubleTailRequests=stats.doubleTailRequests or {}
    stats.doubleTailRequests[tail]=true
    for i,d in ipairs(sprites) do
      local values={d[1]&255,(d[1]>>8)&255,d[2],0,d[3],d[4],d[6] or 9,d[5],i,0}
      for j,v in ipairs(values) do put('_fx_draw',(i-1)*10+j-1,v) end
    end
    put('_fx_draw_count',0,#sprites)
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
if scenario=='equivalence' or scenario=='equivalence_boss' then
  -- Native移植前後で、物理frame数によらず同じlogic更新の状態を比較する。
  emu.addMemoryCallback(guard(function()
    put('_fx_fire_actions',0,2);put('_monosh_runtime_fire_actions',0,2)
    local inputs={1,2,8,4,9,6,0,0}
    local input=inputs[(read('_monosh_runtime_frame_counter',2)//96)%8+1]
    put('_fx_input',0,input)
    -- entry時点で引数は既にcc65 stackへ積まれている。実引数も揃える。
    emu.write(0x7e0000+read('c_sp',2),input,emu.memType.snesMemory)
  end),emu.callbackType.exec,0x7F0000+labels._monosh_player_update,0x7F0000+labels._monosh_player_update,emu.cpuType.snes,emu.memType.snesMemory)
  local states=assert(io.open(output..'/states.bin','wb'))
  local blocks={{'_monosh_runtime_frame_counter',2},{'_monosh_player_x',2},{'_monosh_player_bottom',2},
    {'_monosh_player_state',1},{'_monosh_player_invuln',1},{'_monosh_player_stumble',1},{'_monosh_player_pose',1},
    {'_player_fy',2},{'_death_vy',1},{'_death_timer',1},{'_movement_fraction',1},
    {'_death_accel_fraction',1},{'_intro_timer',1},{'_player_flip',1},{'_player_run_phase',1},
    {'_monosh_stage_title_timer',1},{'_monosh_title_visible',1},
    {'_monosh_stage_frame_counter',2},{'_monosh_stage_spawn_index',1},{'_monosh_stage_half_frame',1},
    {'_monosh_stage_object_count',1},{'_monosh_stage_objects',96},{'_monosh_enemy_spawn_index',1},
    {'_monosh_enemy_spawn_wait',2},{'_monosh_enemy_active_count_value',1},{'_monosh_enemy_em1_count',1},
    {'_monosh_enemy_stage_complete_flag',1},{'_monosh_enemies',80},{'_monosh_enemy_em1_phase',16},
    {'_monosh_enemy_em1_shrink',8},{'_monosh_enemy_bullet_count',1},{'_monosh_enemy_bullets',42},
    {'_boss_dda_phase',6},{'_boss_dda_x',6},{'_boss_dda_y',6},
    {'_monosh_player_bullet_count',1},{'_monosh_player_bullets',15},{'_monosh_reflected_bullet_count',1},
    {'_monosh_reflected_bullets',15},{'_monosh_boss_state',1},{'_monosh_boss_hp',1},
    {'_boss_part_x',9},{'_boss_part_bottom',9},{'_boss_part_z',9},{'_boss_part_active',9},{'_boss_part_timer',9},
    {'_monosh_ground_offset',1},{'_monosh_ground_screen_delta',1},{'_fx_ground_world_phase',1},
    {'_fx_far_u_acc',2},{'_fx_far_d_acc',2},{'_monosh_combat_fire_cooldown',1},{'_monosh_bullet_reflect_rng',1},
    {'_boss_age',1},{'_history_head',1},{'_boss_history_x',128},{'_boss_history_y',128},{'_boss_history_z',128},
    {'_fx_draw_count',1},{'_fx_draw',640}}
  local f=assert(io.open(output..'/state_blocks.json','w'));f:write(encoded(blocks));f:close()
  emu.addMemoryCallback(guard(function()
    local raw={}
    for _,b in ipairs(blocks) do for i=0,b[2]-1 do raw[#raw+1]=string.char(byte(b[1],i)) end end
    states:write(table.concat(raw));states:flush()
  end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
end
if scenario=='profile' then
for _,pair in ipairs({{'_fx_build_packet','packet_done'},{'_fx_ground_native','ground_done'}}) do
  emu.addMemoryCallback(guard(function() native_profile[pair[1]]=emu.getState().masterClock end),
    emu.callbackType.exec,0x7F0000+labels[pair[1]],0x7F0000+labels[pair[1]],emu.cpuType.snes,emu.memType.snesMemory)
  emu.addMemoryCallback(guard(function()
    local start=native_profile[pair[1]]
    if start then report:write(string.format('{"function":"%s","ms":%.6f,"field":%d}\n',pair[1],elapsed(emu.getState().masterClock,start),field)) end
  end),emu.callbackType.exec,0x7F0000+labels[pair[2]],0x7F0000+labels[pair[2]],emu.cpuType.snes,emu.memType.snesMemory)
end
for _,name in ipairs({'_fx_frame','_fx_build_packet','_fx_build_ground','_fx_ground_native','_monosh_enemy_frame','_monosh_stage_frame'}) do
  emu.addMemoryCallback(guard(function()
    local clock=emu.getState().masterClock
    if profile.last then report:write(string.format('{"segment":"%s","ms":%.6f,"field":%d}\n',profile.last,elapsed(clock,profile.clock),field)) end
    profile.last=name;profile.clock=clock
  end),emu.callbackType.exec,0x7F0000+labels[name],0x7F0000+labels[name],emu.cpuType.snes,emu.memType.snesMemory)
end
end
emu.addMemoryCallback(guard(function()
  -- 入力方向の試験が敵接触による死亡アニメーションに切り替わらないよう固定。
  if scenario=='controls' then put('_monosh_player_invuln',0,255) end
  if scenario=='stumble' and field>=400 and not fixture_started then
    fixture_started=true
    write('_monosh_player_bottom',201)
    put('_monosh_player_invuln',0,0)
    put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
    for i,v in ipairs({0,0,1,3,0,0}) do put('_monosh_stage_objects',i-1,v) end
    put('_monosh_stage_object_count',0,1)
  end
  local fixture_frame=scenario=='equivalence_boss' and read('_monosh_runtime_frame_counter',2) or field
  if (scenario~='boss' and scenario~='equivalence_boss') or fixture_frame<90 then return end
  if scenario=='equivalence_boss' then put('_monosh_player_invuln',0,255) end
  if not fixture_started then
    fixture_started=true
    put('_monosh_player_invuln',0,255)
    put('_monosh_enemy_stage_complete_flag',0,1)
    put('_monosh_enemy_active_count_value',0,0);put('_monosh_enemy_bullet_count',0,0)
    put('_monosh_stage_object_count',0,0)
    put('_monosh_stage_spawn_index',0,read('_monosh_stage1_spawn_count',2)-1)
    write('_monosh_stage_frame_counter',3900)
  end
  -- 通常のボス射撃を先に観測。HPは変更せず、後半で自弾だけを命中位置へ置く。
  if read('_monosh_boss_state')==1 and fixture_frame>600 then
    local z=byte('_boss_part_z',0)
    local height=byte('_monosh_boss_face_geometry',math.min(z,110)*2+1)
    if z>=8 and z<=90 then
      put('_monosh_player_bullets',0,1)
      put('_monosh_player_bullets',1,byte('_boss_part_x',0))
      put('_monosh_player_bullets',2,byte('_boss_part_bottom',0)-height//2)
      put('_monosh_player_bullets',3,math.max(0,z//2-2));put('_monosh_player_bullets',4,3)
      put('_monosh_player_bullet_count',0,1)
      stats.injectedShots=(stats.injectedShots or 0)+1
    end
  end
end),emu.callbackType.exec,0x7F0000+labels._fx_frame,0x7F0000+labels._fx_frame,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  if scenario~='stress' then return end
  for i=0,19 do
    local x=(i%10)*32-16;local bottom=i<10 and 212 or 112
    put('_fx_draw',i*10,x);put('_fx_draw',i*10+1,(x>>8)&255)
    put('_fx_draw',i*10+2,bottom);put('_fx_draw',i*10+3,0)
    put('_fx_draw',i*10+4,68);put('_fx_draw',i*10+5,160)
    put('_fx_draw',i*10+6,4);put('_fx_draw',i*10+7,i%2==0 and 16 or 0)
    put('_fx_draw',i*10+8,i);put('_fx_draw',i*10+9,0)
  end
  put('_fx_draw_count',0,20)
end),emu.callbackType.exec,0x7F0000+labels._fx_build_packet,0x7F0000+labels._fx_build_packet,emu.cpuType.snes,emu.memType.snesMemory)
-- test.luaへ挿入する観測専用コード。ROM・ゲーム状態は書き換えない。
-- CPUは次世代、GSUは提示予定の世代を並行処理するため、sceneは開始時に固定する。
local boss_report=assert(io.open(output..'/timings.jsonl','w'))
local probe,previous_dma=nil,nil
local function stamp()
  local s=emu.getState()
  return {clock=s.masterClock,line=s['ppu.scanline'],hclock=s['ppu.hClock'],
          cycle=s['ppu.cycle'],ppuFrame=s['ppu.frameCount'],field=field}
end
emu.addMemoryCallback(guard(function(a,v)
  if v==1 then
    probe={start=stamp(),boss=read('_monosh_boss_state'),hp=read('_monosh_boss_hp'),
      logic=read('_monosh_runtime_frame_counter',2),player=read('_monosh_player_state'),
      x=read('_monosh_player_x',2),y=read('_monosh_player_bottom',2),
      enemyShots=read('_monosh_enemy_bullet_count'),shots=read('_monosh_player_bullet_count'),
      previousDma=previous_dma,commands=read('_fx_packet_count',2)}
  elseif v==2 then probe.joined=stamp()
  elseif v==3 then
    probe.dmaStart=stamp()
    probe.deadline=emu.read(0x7e1d10,emu.memType.snesMemory)
    probe.bytes=read('fx_dma_bytes',2);probe.spans=read('fx_dma_count',2)
  elseif v==4 then
    probe.dmaEnd=stamp();probe.image=rendered
    boss_report:write(encoded(probe)..'\n');boss_report:flush()
    previous_dma={start=probe.dmaStart,finish=probe.dmaEnd,bytes=probe.bytes}
  end
end),emu.callbackType.write,0x7e1df0,0x7e1df0)
emu.addMemoryCallback(guard(function() if probe then probe.cpuEnd=stamp() end end),
  emu.callbackType.exec,0x7f0000+labels.cpu_frame_return,0x7f0000+labels.cpu_frame_return,
  emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function() if probe then probe.gsuEnd=stamp() end end),
  emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
-- wait_bottom直前のSEPは各提示で1回だけ通る。VBlank待ちを処理時間へ含めない。
emu.addMemoryCallback(guard(function() if probe then probe.ready=stamp() end end),
  emu.callbackType.exec,0x7f0000+labels.admission_ready,0x7f0000+labels.admission_ready,
  emu.cpuType.snes,emu.memType.snesMemory)

emu.addMemoryCallback(guard(function()
  gsu_ms=elapsed(emu.getState().masterClock,clock_start)
  stats.gsuMaxMs=math.max(stats.gsuMaxMs,gsu_ms)
end),emu.callbackType.exec,labels.render_stop,labels.render_stop,emu.cpuType.gsu,emu.memType.gsuMemory)
emu.addMemoryCallback(guard(function()
  local now=emu.getState().masterClock
  cpu_ms=elapsed(now,clock_start)
  if scenario=='profile' and profile.last then
    report:write(string.format('{"segment":"%s","ms":%.6f,"field":%d}\n',profile.last,elapsed(now,profile.clock),field))
    profile.last=nil
  end
end),emu.callbackType.exec,0x7F0000+labels.cpu_frame_return,0x7F0000+labels.cpu_frame_return,emu.cpuType.snes,emu.memType.snesMemory)
local function trace()
  local s=emu.getState()
  if field==60 then
    local f=io.open(output..'/state.txt','w')
    for k,v in pairs(s) do if k:find('cpu') or k:find('coprocessor') then f:write(k..'='..tostring(v)..'\n') end end
    f:write('packet='..emu.read(0,emu.memType.gsuWorkRam)..' scratch='..emu.read(4,emu.memType.gsuWorkRam)..' ptr='..emu.read(6,emu.memType.gsuWorkRam)..'\n')
    for k,v in pairs(emu.getInput(0)) do f:write('input '..k..'='..tostring(v)..'\n') end
    f:write('joy='..emu.read(0x4218,emu.memType.snesMemory)..' hi='..emu.read(0x4219,emu.memType.snesMemory)..'\n')
    f:close()
  end
  report:write(string.format('{"field":%d,"logic":%d,"x":%d,"y":%d,"player":%d,"stage":%d,"enemies":%d,"shots":%d,"enemyShots":%d,"boss":%d,"hp":%d,"commands":%d,"cpuPC":%d,"ppuLine":%d,"gsuGO":%d}\n',
    field,read('_monosh_runtime_frame_counter',2),read('_monosh_player_x',2),read('_monosh_player_bottom',2),read('_monosh_player_state'),
    read('_monosh_stage_frame_counter',2),read('_monosh_enemy_active_count_value'),read('_monosh_player_bullet_count'),read('_monosh_enemy_bullet_count'),
    read('_monosh_boss_state'),read('_monosh_boss_hp'),read('_fx_packet_count',2),s['cpu.pc'],s['ppu.scanline'],emu.read(0x3030,emu.memType.snesMemory)))
  report:flush()
end
emu.addMemoryCallback(guard(function(a,v)
  if v~=1 then return end
  local s=emu.getState()
  gsu_start=s['cart.coprocessor.cycleCount'];clock_start=s.masterClock
  profile.last=nil
  if rendered==0 then
    for i=0,15 do emu.write(0x1ff0+i,0xa5,emu.memType.gsuWorkRam);emu.write(0x5000+i,0x5a,emu.memType.gsuWorkRam) end
  end
  if rendered==0 or (rendered+1)%300==0 or (scenario=='packed' and rendered<8) or (scenario=='objects' and (rendered+1)%4==0) then
    dump(string.format('draw%05d.bin',rendered+1),emu.memType.snesMemory,0x7E0000+labels._fx_draw,640)
    dump(string.format('obj%05d.bin',rendered+1),emu.memType.snesMemory,0x7E0000+labels.fx_obj_present,68)
    local f=assert(io.open(output..string.format('/meta%05d.json',rendered+1),'w'))
    f:write(encoded({count=read('_fx_draw_count'),logic=read('_monosh_runtime_frame_counter',2),gsuUv=gsu_uv,gsuClip=gsu_clip}));f:close()
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=2 then return end
  local s=emu.getState()
  local joined=elapsed(s.masterClock,clock_start)
  stats.cpuMaxMs=math.max(stats.cpuMaxMs,joined)
  report:write(string.format('{"joinedMs":%.5f,"cpuMs":%.5f,"gsuMs":%.5f,"field":%d}\n',joined,cpu_ms,gsu_ms,field))
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=3 then return end
  local s=emu.getState()
  dma_start=s.masterClock
  local line=s['ppu.scanline'];local count=read('fx_dma_count',2)
  local deadline=emu.read(0x7e1d10,emu.memType.snesMemory)
  assert(line>=203 and line<=deadline+3,'DMA start outside admitted blank window')
  if deadline==220 then
    assert(read('fx_dma_bytes',2)+count*128<=9216,'large DMA admitted late')
  end
  stats.lateDmaStarts=(stats.lateDmaStarts or 0)+(line>206 and 1 or 0)
  stats.maxDmaStartLine=math.max(stats.maxDmaStartLine or 0,line)
  stats.maxDmaSpanCount=math.max(stats.maxDmaSpanCount or 0,count)
  report:write(string.format('{"dmaStartLine":%d,"spans":%d,"deadline":%d,"field":%d}\n',line,count,deadline,field))
  if rendered==0 then
    local f=io.open(output..'/descriptors.txt','w')
    for i=0,31 do
      local addr=0x7E0000+labels.fx_dma_desc+i*4
      local a=emu.read(addr,emu.memType.snesMemory)+256*emu.read(addr+1,emu.memType.snesMemory)
      local n=emu.read(addr+2,emu.memType.snesMemory)+256*emu.read(addr+3,emu.memType.snesMemory)
      f:write(i..' '..a..' '..n..'\n')
    end
    f:close()
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addMemoryCallback(guard(function(a,v)
  if v~=4 then return end
  rendered=rendered+1
  local s=emu.getState()
  assert(s['ppu.scanline']<23 or s['ppu.scanline']>=203,'DMA overlaps visible area')
  local duration=elapsed(s.masterClock,dma_start)
  local bytes=read('fx_dma_bytes',2)
  stats.objMaxCount=math.max(stats.objMaxCount or 0,read('fx_obj_present_count',2))
  assert(read('fx_obj_overflow',2)==0,'OBJ packet capacity exceeded')
  for i=0,63 do assert(emu.read(i,emu.memType.snesSpriteRam)==byte('fx_obj_present',i),'OAM low snapshot differs') end
  for i=0,3 do assert(emu.read(512+i,emu.memType.snesSpriteRam)==byte('fx_obj_present',64+i),'OAM high snapshot differs') end
  stats.dmaMaxMs=math.max(stats.dmaMaxMs,duration)
  stats.minBytes=math.min(stats.minBytes,bytes);stats.maxBytes=math.max(stats.maxBytes,bytes)
  local interval=field-previous_field;previous_field=field
  if rendered>1 then if interval==1 then stats.interval1=stats.interval1+1 elseif interval==2 then stats.interval2=stats.interval2+1 else stats.interval3plus=stats.interval3plus+1 end end
  local boss=read('_monosh_boss_state');local player=read('_monosh_player_state')
  stats.enemyShotsMax=math.max(stats.enemyShotsMax or 0,read('_monosh_enemy_bullet_count'))
  if boss==1 then stats.bossSeen=true elseif boss==2 then stats.dyingSeen=true elseif boss==3 then stats.doneSeen=true end
  if previous_boss==3 and boss==0 then stats.loopSeen=true end
  if boss~=previous_boss then screenshot('boss_state'..boss) end
  if previous_player==0 and player~=0 then stats.deaths=stats.deaths+1 end
  if previous_player~=0 and player==0 then stats.respawns=stats.respawns+1 end
  if read('_monosh_player_stumble')>0 then stats.stumbles=stats.stumbles+1 end
  stats.stumbleMax=math.max(stats.stumbleMax or 0,read('_monosh_player_stumble'))
  stats.reflected=math.max(stats.reflected,read('_monosh_reflected_bullet_count'))
  previous_boss=boss;previous_player=player
  for i=0,read('_monosh_enemy_active_count_value')-1 do
    local addr=0x7E0000+labels._monosh_enemies+i*10
    local t=emu.read(addr+1,emu.memType.snesMemory);stats.enemyTypes[t]=true
    if t==5 then stats.enemyPaths[emu.read(addr+2,emu.memType.snesMemory)]=true end
    if t==6 then stats.em1States[emu.read(0x7E0000+labels._monosh_enemy_em1_phase+i*2+1,emu.memType.snesMemory)]=true end
  end
  stats.maxCommands=math.max(stats.maxCommands,read('_fx_packet_count',2))
  report:write(string.format('{"dmaMs":%.5f,"bytes":%d,"line":%d,"field":%d,"rendered":%d}\n',duration,bytes,s['ppu.scanline'],field,rendered))
  if maxframe<=720 or rendered<=10 or rendered%30==0 then
  local same=0
  for i=0,12287 do if emu.read(0x2000+i,emu.memType.gsuWorkRam)==emu.read(i,emu.memType.snesVideoRam) then same=same+1 end end
  if same~=12288 then
    local raw={};local f=io.open(output..'/vram.bin','wb')
    for i=0,12287 do raw[#raw+1]=string.char(emu.read(i,emu.memType.snesVideoRam)) end
    f:write(table.concat(raw));f:close()
    raw={};f=io.open(output..'/failed_fb.bin','wb')
    for i=0,12287 do raw[#raw+1]=string.char(emu.read(0x2000+i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(raw));f:close()
    f=io.open(output..'/state_dma.txt','w')
    for k,v in pairs(s) do if k:find('dma') or k:find('ppu.vram') then f:write(k..'='..tostring(v)..'\n') end end
    f:close()
    local f=io.open(output..'/dma_debug.txt','w')
    for i=0,12287 do if emu.read(0x2000+i,emu.memType.gsuWorkRam)~=emu.read(i,emu.memType.snesVideoRam) then f:write(i..'='..emu.read(0x2000+i,emu.memType.gsuWorkRam)..' vs '..emu.read(i,emu.memType.snesVideoRam)..'\n') end end
    f:close()
  end
  assert(same==12288,'partial DMA: '..same)
  stats.checked=stats.checked+1
  for i=0,15 do assert(emu.read(0x1ff0+i,emu.memType.gsuWorkRam)==0xa5 and emu.read(0x5000+i,emu.memType.gsuWorkRam)==0x5a,'GSU clip writes outside framebuffer') end
  assert(emu.read(0,emu.memType.snesCgRam)==0xd8 and emu.read(1,emu.memType.snesCgRam)==0x7d,'purple backdrop palette corruption: '..emu.read(0,emu.memType.snesCgRam)..'/'..emu.read(1,emu.memType.snesCgRam)..' constant '..read('_fx_sky_color',2))
  end
  if rendered==1 then
    local f=io.open(output..'/framebuffer.bin','wb'); local b={}
    for i=0,12287 do b[#b+1]=string.char(emu.read(0x2000+i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(b));f:close()
    f=io.open(output..'/packet.bin','wb');b={}
    for i=0,1311 do b[#b+1]=string.char(emu.read(i,emu.memType.gsuWorkRam)) end
    f:write(table.concat(b));f:close()
  end
  if rendered==1 or rendered%300==0 or (scenario=='packed' and rendered<=8) or (scenario=='objects' and rendered%4==0) then
    dump(string.format('frame%05d.bin',rendered),emu.memType.gsuWorkRam,0x2000,12288)
    dump(string.format('packet%05d.bin',rendered),emu.memType.gsuWorkRam,0,1312)
    dump(string.format('oam%05d.bin',rendered),emu.memType.snesSpriteRam,0,544)
  end
end),emu.callbackType.write,0x7E1DF0,0x7E1DF0)
emu.addEventCallback(guard(function()
  if scenario=='held' then
    local input={}
    for direction in held_direction:gmatch('[^-]+') do if direction~='none' then input[direction]=true end end
    if held_fire~='none' then input[held_fire]=true end
    emu.setInput(input,0)
  elseif scenario=='play' then
    emu.setInput({a=true,up=field>150 and field<180,right=field>180 and field<210,left=field>240 and field<275},0)
  elseif scenario=='long' or scenario=='profile' then
    if read('_monosh_boss_state')==1 then
      local z=byte('_boss_part_z',0)
      local tx=byte('_boss_part_x',0)
      local ty=byte('_boss_part_bottom',0)-byte('_monosh_boss_face_geometry',math.min(z,110)*2+1)//2+20
      local x=read('_monosh_player_x',2);local y=read('_monosh_player_bottom',2)
      emu.setInput({a=true,right=x<tx-3,left=x>tx+3,up=y>ty+3,down=y<ty-3},0)
    else emu.setInput({a=true},0) end
  elseif scenario=='boss' then emu.setInput({},0)
  elseif scenario=='pause' then
    emu.setInput({a=true,start=(field>=151 and field<=154) or (field>=211 and field<=214)},0)
  elseif scenario=='controls' then
    emu.setInput({right=field>=301 and field<=330,left=field>=361 and field<=390,
                  down=field>=401 and field<=430,up=field>=461 and field<=490,y=field>=601 and field<=606},0)
  end
end),emu.eventType.inputPolled)
emu.addEventCallback(guard(function()
  field=field+1
  local status=emu.read(0x213e,emu.memType.snesMemory)
  assert(status&0xc0==0,'OBJ range/time overflow')
  if rendered>0 then
    if read('_monosh_boss_state')==1 and read('_boss_age')>=100 and not stats.bossImage then screenshot('scene_boss');stats.bossImage=true end
    if read('_monosh_enemy_active_count_value')>=3 and not stats.enemyImage then screenshot('scene_enemies');stats.enemyImage=true end
    if read('_monosh_player_state')~=0 and not stats.deathImage then screenshot('scene_death');stats.deathImage=true end
  end
  if scenario=='controls' and rendered>0 then
    if field==335 then assert(read('_monosh_player_x',2)>128,'right input failed') end
    if field==435 then stats.controlUpY=read('_monosh_player_bottom',2);assert(stats.controlUpY<120,'reverse down input failed') end
    if field==495 then assert(read('_monosh_player_bottom',2)>stats.controlUpY,'reverse up input failed') end
    stats.singleShotMax=math.max(stats.singleShotMax or 0,read('_monosh_player_bullet_count'))
  end
  if scenario=='pause' then
    if field==165 then stats.pauseLogic=read('_monosh_runtime_frame_counter',2) end
    if field==195 then assert(read('_monosh_runtime_frame_counter',2)==stats.pauseLogic,'pause keeps updating logic') end
    if field==240 then assert(read('_monosh_runtime_frame_counter',2)>stats.pauseLogic,'pause did not resume') end
  end
  if field%30==0 then trace() end
  if scenario=='held' then
    if rendered>0 then
      local logic=read('_monosh_runtime_frame_counter',2)
      if logic~=last_logic then last_logic=logic;last_logic_field=field end
      stats.maxLogicGap=math.max(stats.maxLogicGap or 0,field-last_logic_field)
      assert(read('_monosh_runtime_paused')==0,'unexpected pause without Start: cached JOY1='..read('_fx_buttons',2)..' field='..field)
      assert(field-last_logic_field<=90,'logic frozen while frames continue')
      if field>=60 then
        local bits={right=0x100,left=0x200,down=0x400,up=0x800,a=0x80,y=0x4000}
        local expected=bits[held_fire] or 0
        for direction in held_direction:gmatch('[^-]+') do expected=expected|(bits[direction] or 0) end
        assert(read('_fx_buttons',2)==expected,'held buttons were sampled mid-shift: '..read('_fx_buttons',2)..' expected '..expected)
        stats.heldSamplesChecked=(stats.heldSamplesChecked or 0)+1
      end
    end
    local gap=field-previous_field
    stats.maxPresentationGap=math.max(stats.maxPresentationGap or 0,rendered>0 and gap or 0)
    if gap>90 and field>120 then
      local f=assert(io.open(output..'/freeze_state.json','w'))
      f:write(encoded(emu.getState()));f:close()
      dump('freeze_wram.bin',emu.memType.snesMemory,0x7e0000,65536)
      dump('freeze_gsu.bin',emu.memType.gsuWorkRam,0,32768)
      dump('freeze_registers.bin',emu.memType.snesMemory,0x3000,128)
      screenshot('freeze')
      trace()
      assert(false,'presentation frozen: '..gap..' fields without a new image; rendered='..rendered..' field='..field)
    end
  end
  if field==120 or field==240 or field==maxframe then
    local f=assert(io.open(output..'/field'..field..'.rgb','wb'));local rgb={}
    for _,v in ipairs(emu.getScreenBuffer()) do rgb[#rgb+1]=string.char((v>>16)&255,(v>>8)&255,v&255) end
    f:write(table.concat(rgb));f:close()
  end
  if field>=maxframe then
    stats.fields=field;stats.rendered=rendered;stats.logic=read('_monosh_runtime_frame_counter',2);stats.stage=read('_monosh_stage_frame_counter',2)
    local f=assert(io.open(output..'/summary.json','w'));f:write(encoded(stats));f:close()
    assert(rendered>1,'no presented frames')
    if scenario=='packed' then for _,name in ipairs({'packed_one','packed_half','packed_quarter','packed_double',
      'packed_mirror_one','packed_mirror_half','packed_mirror_quarter'}) do assert((stats[name] or 0)>0,'unused packed path: '..name) end end
    if scenario=='packed' then for tail=0,7 do assert(stats.doubleTailRequests[tail],'unused double tail: '..tail) end end
    if scenario=='boss' then assert(stats.bossSeen and stats.dyingSeen and stats.doneSeen and stats.loopSeen,'boss progression incomplete') end
    if scenario=='long' then assert(stats.bossSeen and stats.loopSeen and stats.deaths>0 and stats.respawns>0,'natural stage progression incomplete') end
    if scenario=='controls' then assert(stats.singleShotMax==1,'single shot was not exactly one slot') end
    if scenario=='stumble' then assert(stats.stumbles==39 and stats.stumbleMax==39 and read('_monosh_player_stumble')==0,'40-update bush stumble/recovery failed') end
    boss_report:close();report:close();emu.stop(0);return
  end
  if scenario=='play' then
    emu.setInput({a=true,up=field>150 and field<180,right=field>180 and field<210,left=field>240 and field<275},0)
  end
end),emu.eventType.endFrame)
