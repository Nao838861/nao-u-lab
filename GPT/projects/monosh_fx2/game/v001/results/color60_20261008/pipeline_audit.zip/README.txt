Color pipeline audit for the integrated MonoSH FX2 ROM

ROM: audit.sfc
SHA-256: 0c7282ce976a9345adcd1719d6aa14fa8088e553cfa01a0ba95e1a134955da38
Emulator and source fingerprints are recorded in metadata.json.

These are deterministic synthetic regression fixtures, not measurements of natural-game presentation rate. They run the actual CPU and GSU code while injecting edge cases through Mesen's Lua callbacks. Physical hardware was not tested.

Suites:
- cache_delta.lua: all 65 camera offsets at world phases 0, 1, 32, 64 and 127; six generations per key exercise all three buffers on misses and hits. Checks unchanged inactive buffers, exact horizontal HDMA projection, continuing palette/far/sky updates, GSU color delta descriptors and shadows, SRAM guards, palette-generation latching, and final VRAM/CGRAM.
- full_framebuffer.lua: the same 1,950 ground builds and 1,949 presentations, forcing full 12,288-byte framebuffer transfers and all 32 OAM entries while toggling color mode every generation. Asserts DMA completion before line 22 and HDMA re-enable before line 0.
- late_max_oam.lua: cache/delta fixture with maximum OAM, allowing the ordinary late-admission path; guards line-0 HDMA initialization.
- obj_latch.lua: 263 generations sweeping OAM counts 0 through 32 and back, including odd counts, grow/shrink/empty transitions, high-table updates and final PPU OAM values. Unused low entries use the game's canonical hidden representation.

Delta cases include invalid persisted shadow state, zero changed words, the maximum 12 separated spans, 64/66-byte coalescing boundaries, first/last byte changes, full-map changes, and staged VRAM-bank switches. Canaries cover color scratch boundaries and descriptor gaps.

Reproduce with the copied ROM and each Lua file using Mesen 2.1.1:
Mesen --testRunner --timeout=240 --doNotSaveSettings --enableStdout audit.sfc SUITE.lua
Enable Lua file access and set GsuClockSpeed to 100. The Linux environment used here preloads the system libstdc++ and uses the isolated settings recorded by the main test environment. Each Lua file's local output variable must point to this directory if the directory is moved.

The full_framebuffer_hclock.jsonl file contains the exact status=4 completion scanline and master-clock position for every forced-full-frame presentation. SHA256SUMS.json seals the copied ROM, labels, fixtures, metadata and results.
