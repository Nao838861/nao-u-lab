local labels={["__BSS_LOAD__"]=59022,["__BSS_RUN__"]=59022,["__BSS_SIZE__"]=5749,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65129,["__COLORBSS_LOAD__"]=3700,["__COLORBSS_RUN__"]=3700,["__COLORBSS_SIZE__"]=1788,["__COLORRODATA_LOAD__"]=35634,["__COLORRODATA_RUN__"]=1024,["__COLORRODATA_SIZE__"]=2676,["__DATA_LOAD__"]=4376195,["__DATA_RUN__"]=59011,["__DATA_SIZE__"]=11,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50819,["__STARTUP__"]=1,["_abs"]=64760,["_boss_age"]=59637,["_boss_attribute_cache"]=59472,["_boss_attribute_cache_count"]=59634,["_boss_attribute_z_cache"]=59616,["_boss_dda_phase"]=59855,["_boss_dda_x"]=59861,["_boss_dda_y"]=59867,["_boss_death_parts"]=59639,["_boss_death_timer"]=59638,["_boss_fire_gap"]=59648,["_boss_fire_round"]=59645,["_boss_fire_shots"]=59647,["_boss_fire_state"]=59644,["_boss_fire_volley"]=59646,["_boss_history_x"]=59088,["_boss_history_y"]=59216,["_boss_history_z"]=59344,["_boss_last_vblank"]=59024,["_boss_motion_steps"]=59643,["_boss_part_active"]=59052,["_boss_part_bottom"]=59034,["_boss_part_fall_fraction"]=59079,["_boss_part_fall_velocity"]=59070,["_boss_part_timer"]=59061,["_boss_part_x"]=59025,["_boss_part_z"]=59043,["_boss_path_half"]=59642,["_boss_player_bottom"]=59651,["_boss_player_x"]=59649,["_boss_render_camera_delta"]=59635,["_boss_restart_timer"]=59640,["_boss_z_phase"]=59641,["_death_accel_fraction"]=59889,["_death_timer"]=59887,["_death_vy"]=59886,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_boss_hits"]=61850,["_fx_boss_project"]=61655,["_fx_build_ground"]=13112,["_fx_build_packet"]=23587,["_fx_buttons"]=62055,["_fx_draw"]=60131,["_fx_draw_count"]=60771,["_fx_em0_geometry"]=58878,["_fx_enemy_collisions"]=58353,["_fx_enemy_em1_update"]=59754,["_fx_enemy_em1_update_reference"]=7583,["_fx_enemy_fire_em1"]=7521,["_fx_enemy_remove"]=7510,["_fx_enemy_render"]=57723,["_fx_enemy_render_bullets"]=58002,["_fx_far_d_acc"]=62067,["_fx_far_u_acc"]=62065,["_fx_fire_actions"]=62058,["_fx_frame"]=60658,["_fx_ground_c1ptr"]=63823,["_fx_ground_c3ptr"]=63825,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62074,["_fx_ground_color3"]=62524,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63789,["_fx_ground_far_xptr"]=63819,["_fx_ground_far_y"]=63829,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63827,["_fx_ground_horizontal"]=62974,["_fx_ground_hptr"]=63784,["_fx_ground_native"]=13197,["_fx_ground_palette_record"]=63787,["_fx_ground_phase"]=62054,["_fx_ground_vptr"]=63821,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63786,["_fx_init"]=11689,["_fx_input"]=62057,["_fx_open_size"]=62912,["_fx_packet"]=60774,["_fx_packet_count"]=60772,["_fx_present"]=12397,["_fx_read_input"]=12161,["_fx_send_ground"]=12193,["_fx_sky_color"]=39095,["_fx_stage_contact"]=57039,["_fx_stage_render"]=56340,["_fx_stage_update"]=57370,["_fx_submit"]=62700,["_fx_toggle_color"]=23913,["_ground_irq_vblank_count"]=62062,["_history_head"]=59636,["_hit_pending"]=62069,["_intro_timer"]=59890,["_legacy_enemy_fire_boss_at"]=6115,["_main"]=11726,["_memcpy"]=64591,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59023,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2096,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=61435,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59022,["_monosh_bullet_reflect_rng"]=59693,["_monosh_collision_bullet_bands"]=59685,["_monosh_combat_build_collision_bands"]=2278,["_monosh_combat_fast_cache_reset"]=12087,["_monosh_combat_fast_frame"]=62204,["_monosh_combat_fast_render"]=62326,["_monosh_combat_fast_render_cached"]=12094,["_monosh_combat_fire_cooldown"]=59694,["_monosh_combat_half_frame"]=59695,["_monosh_combat_init"]=2122,["_monosh_combat_reflect_bullet"]=11737,["_monosh_combat_render"]=2275,["_monosh_combat_update"]=2217,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59850,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59699,["_monosh_enemy_active_count"]=3038,["_monosh_enemy_active_count_value"]=59697,["_monosh_enemy_bullet_count"]=59696,["_monosh_enemy_bullets"]=59779,["_monosh_enemy_camera_delta_cached"]=59848,["_monosh_enemy_collision_cursor"]=59853,["_monosh_enemy_draw_cache_valid"]=59851,["_monosh_enemy_em1_count"]=59849,["_monosh_enemy_em1_phase"]=59824,["_monosh_enemy_em1_shrink"]=59840,["_monosh_enemy_fast_advance"]=59346,["_monosh_enemy_fast_check_player_bullets"]=4128,["_monosh_enemy_fast_render"]=3613,["_monosh_enemy_fast_render_bullets"]=5078,["_monosh_enemy_fast_spawn_due"]=5454,["_monosh_enemy_fast_update_bullets"]=59016,["_monosh_enemy_fire_at"]=3050,["_monosh_enemy_fire_boss_at"]=3079,["_monosh_enemy_fire_em0_fast"]=6513,["_monosh_enemy_frame"]=2841,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59852,["_monosh_enemy_init"]=2692,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59854,["_monosh_enemy_render_only"]=2871,["_monosh_enemy_spawn_index"]=59821,["_monosh_enemy_spawn_wait"]=59822,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3044,["_monosh_enemy_stage_complete_flag"]=59698,["_monosh_ground_depth_pointer"]=62072,["_monosh_ground_offset"]=59011,["_monosh_ground_screen_delta"]=59012,["_monosh_player_bottom"]=59877,["_monosh_player_bullet_count"]=59668,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59653,["_monosh_player_can_fire"]=9341,["_monosh_player_draw_asset"]=9357,["_monosh_player_draw_flags"]=9299,["_monosh_player_init"]=9236,["_monosh_player_invuln"]=59880,["_monosh_player_pose"]=59882,["_monosh_player_state"]=59879,["_monosh_player_stumble"]=59881,["_monosh_player_update"]=60048,["_monosh_player_update_reference"]=10566,["_monosh_player_world_active"]=9335,["_monosh_player_x"]=59875,["_monosh_project_x"]=27517,["_monosh_reflected_bullet_count"]=59684,["_monosh_reflected_bullets"]=59669,["_monosh_runtime_fire_actions"]=62059,["_monosh_runtime_frame_counter"]=62060,["_monosh_runtime_paused"]=62064,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60129,["_monosh_stage_collision_bullet_index"]=60130,["_monosh_stage_contact_result"]=60127,["_monosh_stage_draw_cache_valid"]=60128,["_monosh_stage_frame"]=10841,["_monosh_stage_frame_counter"]=59991,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59995,["_monosh_stage_hitbox_count"]=60125,["_monosh_stage_hitboxes"]=59997,["_monosh_stage_init"]=10806,["_monosh_stage_is_clear"]=10890,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59996,["_monosh_stage_need_hitboxes"]=60126,["_monosh_stage_object_count"]=59989,["_monosh_stage_objects"]=59893,["_monosh_stage_render_only"]=10887,["_monosh_stage_spawn_index"]=59990,["_monosh_stage_spawn_wait"]=59993,["_monosh_stage_title_timer"]=59883,["_monosh_title_draw"]=11715,["_monosh_title_visible"]=59013,["_movement_fraction"]=59888,["_old_buttons"]=62070,["_player_flip"]=59891,["_player_fy"]=59884,["_player_run_phase"]=59892,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12088,["addeq0sp"]=64093,["addeqysp"]=64095,["addysp"]=64111,["addysp1"]=64110,["aslax2"]=64124,["aslax3"]=64135,["aslax4"]=64149,["asleax1"]=64166,["asrax1"]=64178,["asrax2"]=64188,["asrax3"]=64203,["booleq"]=64553,["boolge"]=64570,["boolgt"]=64568,["boolle"]=64560,["boollt"]=64562,["boolne"]=64547,["booluge"]=64586,["boolugt"]=64584,["boolule"]=64576,["boolult"]=64578,["c_sp"]=154,["clip_edges"]=99624,["color_boot_map"]=33586,["color_clear_dirty"]=25118,["color_clear_dirty_row"]=25122,["color_clear_dirty_skip"]=25223,["color_clear_ready"]=24048,["color_cols_done"]=24556,["color_kernel_restore"]=24793,["color_next_draw"]=24082,["color_palette"]=33458,["color_prepare_cols"]=24479,["color_rows"]=24649,["color_skip_draw"]=24817,["color_visible"]=24252,["decsp1"]=64223,["decsp2"]=64232,["decsp3"]=64245,["decsp4"]=64258,["decsp5"]=64271,["dma_cache"]=100208,["dma_cache_end"]=100409,["dma_deadline_fine"]=13055,["dma_finished"]=12980,["dma_last_line"]=255,["dma_started"]=12892,["fx_add_next_bounds"]=62699,["fx_build_color"]=23984,["fx_build_obj"]=26215,["fx_color_build_done"]=24824,["fx_color_cells"]=1024,["fx_color_dma"]=5432,["fx_color_dma_bytes"]=5482,["fx_color_dma_count"]=5480,["fx_color_map0"]=3700,["fx_color_map1"]=4468,["fx_color_mode"]=59014,["fx_color_next_ptr"]=59015,["fx_color_present_mode"]=5236,["fx_color_present_ptr"]=59017,["fx_color_stage_done"]=26056,["fx_color_staged"]=5484,["fx_color_upload_done"]=25916,["fx_color_vram_base"]=59020,["fx_commit_dma"]=62699,["fx_dma_bytes"]=64641,["fx_dma_count"]=64639,["fx_dma_desc"]=64643,["fx_em1_open_sizes"]=62955,["fx_emit_native"]=58216,["fx_is_obj"]=26130,["fx_latch_color"]=25720,["fx_latch_obj"]=27278,["fx_obj_build_done"]=26849,["fx_obj_count"]=64401,["fx_obj_dma_bytes"]=64441,["fx_obj_next"]=64129,["fx_obj_overflow"]=64405,["fx_obj_present"]=64265,["fx_obj_present_count"]=64403,["fx_obj_upload_done"]=27507,["fx_plan_dma"]=62680,["fx_prepare_obj_dma"]=27385,["fx_project16"]=27547,["fx_read_gsu_color_plan"]=26058,["fx_read_gsu_spans"]=62625,["fx_reset_next_bounds"]=62699,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63835,["fx_stage_color"]=25996,["fx_upload_color"]=25786,["fx_upload_color_palette"]=25918,["fx_upload_ground"]=13528,["fx_upload_obj"]=27452,["game_started"]=12097,["generic"]=99054,["generic_render"]=98622,["ground_done"]=13481,["ground_empty"]=13622,["gsu_color_axis_cache"]=100864,["gsu_color_begin"]=100416,["gsu_color_clear_end"]=100625,["gsu_color_delta_begin"]=101136,["gsu_color_delta_end"]=101316,["gsu_color_done"]=101316,["gsu_color_draw_cache"]=101024,["gsu_color_draw_cache_end"]=101122,["gsu_color_setup_cache"]=100656,["hot_cache"]=98464,["hot_cache_end"]=98975,["incsp1"]=64351,["incsp2"]=64366,["incsp3"]=64380,["incsp4"]=64385,["incsp5"]=64390,["incsp6"]=64395,["incsp7"]=64400,["incsp8"]=64405,["initialized"]=23655,["ldaidx"]=64410,["margin_render"]=98656,["margin_render_end"]=98735,["margin_select"]=100086,["memcpy_getparams"]=64632,["memcpy_upwards"]=64594,["mulax10"]=64651,["mulax3"]=64676,["mulax5"]=64693,["mulax6"]=64713,["mulax7"]=64735,["negax"]=64764,["order"]=63873,["packed_double"]=99491,["packed_double_cache"]=99522,["packed_half"]=99209,["packed_half_cache"]=99232,["packed_mirror_half"]=99383,["packed_mirror_half_cache"]=99406,["packed_mirror_one"]=99317,["packed_mirror_one_cache"]=99341,["packed_mirror_quarter"]=99442,["packed_mirror_quarter_cache"]=99461,["packed_one"]=99143,["packed_one_cache"]=99167,["packed_quarter"]=99268,["packed_quarter_cache"]=99287,["packet_done"]=23742,["packet_work"]=12,["popax"]=64358,["popptr1"]=64778,["popsargsudiv16"]=64868,["ptr1"]=162,["ptr2"]=164,["ptr3"]=166,["ptr4"]=168,["push0"]=64814,["push0ax"]=64517,["pusha"]=64796,["pusha0"]=64816,["pusha0sp"]=64792,["pushax"]=64818,["pushaysp"]=64794,["pusheax"]=64523,["pushl0"]=64514,["pushw0sp"]=64840,["pushwysp"]=64842,["regbank"]=174,["regsave"]=158,["render_entry"]=98304,["render_finished"]=12661,["render_started"]=12629,["render_stop"]=101320,["reset"]=32768,["scaled_select"]=99724,["select_dma_deadline"]=12999,["shlax2"]=64124,["shlax3"]=64135,["shlax4"]=64149,["shleax1"]=64166,["shrax1"]=64900,["shrax3"]=64908,["shrax4"]=64922,["sorted"]=23721,["sreg"]=156,["stage_update_done"]=57721,["staspidx"]=64939,["stax0sp"]=64961,["staxspidx"]=64972,["staxysp"]=64963,["subysp"]=65020,["tmp1"]=170,["tmp2"]=171,["tmp3"]=172,["tmp4"]=173,["tosadda0"]=64065,["tosaddax"]=64067,["tosdiva0"]=64284,["tosdivax"]=64286,["tosicmp"]=64307,["tosicmp0"]=64305,["tosmul0ax"]=64422,["tosmuleax"]=64428,["tossuba0"]=64999,["tossubax"]=65001,["tosudiva0"]=65033,["tosudivax"]=65035,["tosumoda0"]=65112,["tosumodax"]=65114,["tosumul0ax"]=64422,["tosumuleax"]=64428,["udiv16"]=65050,["L1"]=65084,["@L1"]=65102,["Pos"]=64302,["@L3"]=64343,["@L4"]=64344,["@L2"]=65106,["L0"]=65060,["mul32"]=64428,["ret0"]=64549,["ret1"]=64555,["L3"]=64621,["done"]=64629,["L2"]=64893,["@L0"]=65091,["udiv16by8a"]=65091}
local output="/workspace/shared/fx2-env/color-audit-final/0c7282ce"
local colorpalette=string.char(0,0,99,12,16,66,255,127,0,0,225,8,163,18,240,51,0,0,169,12,214,41,63,79,0,0,99,20,15,74,189,123,0,0,47,0,31,1,159,23,0,0,6,73,77,122,219,127,0,0,108,52,56,97,31,127,0,0,225,4,231,26,29,71)
local monochrome=string.char(0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127,0,0,99,12,16,66,255,127)
local failed=false
local ground=0
local completed=0
local currentoffset,currentphase,currentfar,currentpalette
local groundbefore,writes= {},0
local keyBySlot={}
local expectedMap,expectedSpans,expectedBytes,deltaCase
local previousMap={}
local latchedMode
local stats={groundCalls=0,groundCacheHits=0,groundCacheMisses=0,hdmaLines=0,deltaChecks=0,descriptorChecks=0,paletteChecks=0,stages=0,zeroSpans=0,twelveSpans=0,guards=0,fullMaps=0}
local function m(a) return emu.read(a,emu.memType.snesMemory) end
local function rb(a) return emu.read(a,emu.memType.gsuWorkRam) end
local function wb(a,v) emu.write(a,v&255,emu.memType.gsuWorkRam) end
local function rw(a) return rb(a)+256*rb(a+1) end
local function ww(a,v) wb(a,v);wb(a+1,v>>8) end
local function read(n) local a=0x7e0000+labels[n];return m(a)+256*m(a+1) end
local function put(n,v) emu.write(0x7e0000+labels[n],v&255,emu.memType.snesMemory) end
local function write(n,v) put(n,v);emu.write(0x7e0001+labels[n],(v>>8)&255,emu.memType.snesMemory) end
local function blob(a,n,mem)
 local b={};for i=0,n-1 do b[#b+1]=string.char(emu.read(a+i,mem or emu.memType.snesMemory)) end;return table.concat(b)
end
local function finish(code,error)
 local f=assert(io.open(output..'/late_max_oam_result.json','w'))
 local result={};for k,v in pairs(stats) do result[#result+1]='"'..k..'":'..v end
 if error then result[#result+1]='"error":'..string.format('%q',tostring(error)) end
 f:write('{'..table.concat(result,',')..'}\n');f:close();emu.stop(code)
end
local function guard(fn) return function(...)
 if failed then return end
 local ok,err=pcall(fn,...)
 if not ok then failed=true;finish(1,err) end
end end
local function hook(name,fn,gsu)
 local a=assert(labels[name]);if not gsu then a=a+0x7f0000 end
 emu.addMemoryCallback(guard(fn),emu.callbackType.exec,a,a,gsu and emu.cpuType.gsu or emu.cpuType.snes,gsu and emu.memType.gsuMemory or emu.memType.snesMemory)
end
local guardranges={{0x0960,0x097f},{0x09a0,0x09bf},{0x09d8,0x09ff},{0x1606,0x161f},{0x1650,0x16ff}}
hook('game_started',function()
 for _,r in ipairs(guardranges) do for a=r[1],r[2] do wb(a,0xa5) end end
 ww(0x1604,0xbad) -- CPU's first-generation initialization must reject stale SRAM.
end)
hook('_fx_build_packet',function()
 put('_fx_draw_count',0)
 if ground==9 then
  local draw={128,0,212,0,255,255,13,48,0,0}
  for i,v in ipairs(draw) do emu.write(0x7e0000+labels._fx_draw+i-1,v,emu.memType.snesMemory) end
  put('_fx_draw_count',1)
 end
end)
hook('fx_build_color',function() put('fx_color_mode',ground%2) end)
hook('fx_latch_color',function() latchedMode=m(0x7e0000+labels.fx_color_mode) end)
hook('_fx_build_ground',function()
 local case=ground//6
 currentoffset=case%65
 currentphase=({0,1,32,64,127})[1+(case//65)%5]
 currentfar=(ground*137)&65535
 currentpalette=ground%14
 put('_monosh_ground_offset',currentoffset);put('_fx_ground_world_phase',currentphase)
 put('_fx_ground_phase',currentpalette);write('_fx_far_u_acc',currentfar)
 for slot=0,2 do groundbefore[slot]=blob(0x7e0000+labels._fx_ground_horizontal+slot*270,270) end
 writes=0
end)
emu.addMemoryCallback(guard(function() writes=writes+1 end),emu.callbackType.write,0x7e0000+labels._fx_ground_horizontal,0x7e0000+labels._fx_ground_horizontal+809,emu.cpuType.snes,emu.memType.snesMemory)
hook('ground_done',function()
 local ptr=read('_fx_ground_hptr')
 local slot=(ptr-labels._fx_ground_horizontal)//270
 local key=currentoffset*256+currentphase+1
 local hit=keyBySlot[slot]==key
 if hit then assert(writes==0,'cache hit wrote horizontal table');stats.groundCacheHits=stats.groundCacheHits+1
 else assert(writes>0,'cache miss did not rebuild');stats.groundCacheMisses=stats.groundCacheMisses+1 end
 keyBySlot[slot]=key
 for other=0,2 do if slot~=other then assert(blob(0x7e0000+labels._fx_ground_horizontal+other*270,270)==groundbefore[other],'nonselected horizontal buffer modified') end end
 local p,line,last=0,0,128
 while true do
  local count=m(0x7e0000+ptr+p);p=p+1
  if count==0 then break end
  assert(count<128,'unexpected per-line horizontal descriptor')
  last=m(0x7e0000+ptr+p)+256*m(0x7e0000+ptr+p+1);p=p+2
  for i=1,count do
   local horizon=104+currentoffset
   local span=100-currentoffset
   local source=math.max(0,math.min(80,((line-horizon)*80+span//2)//span))
   local expected=128+(currentphase*source*51)//(64*80)
   assert(last==expected,'HDMA horizontal mismatch offset='..currentoffset..' phase='..currentphase..' line='..line..' expected='..expected..' got='..last)
   line=line+1;stats.hdmaLines=stats.hdmaLines+1
  end
 end
 assert(read('_fx_ground_palette_record')==(currentoffset*14+currentpalette)%1024,'palette animation stale on cache hit')
 local f=read('_fx_ground_far_xptr');assert(m(0x7e0001+f)+256*m(0x7e0002+f)==(currentfar>>7)&511,'far-X stale on cache hit')
 local sky=read('fx_sky_pointer');local count=m(0x7e0000+sky)
 assert(count==math.min(127,currentoffset+74),'sky head mismatch')
 assert(read('_fx_ground_far_y')==((23-currentoffset)&65535),'far-Y mismatch')
 ground=ground+1;stats.groundCalls=ground
end)
hook('gsu_color_delta_begin',function()
 deltaCase=completed%8
 expectedMap={};for i=0,767 do expectedMap[i]=previousMap[i] or (0x20|(((i%32)*24+i//32)>>8)) end
 local change={}
 if deltaCase==0 or deltaCase==2 then for i=0,767 do change[i]=true end
 elseif deltaCase==3 then for i=0,11 do change[i*68]=true;change[i*68+1]=true end
 elseif deltaCase==4 then change[0]=true;change[66]=true
 elseif deltaCase==5 then change[0]=true;change[68]=true
 elseif deltaCase==6 then change[767]=true
 elseif deltaCase==7 then change[1]=true;change[764]=true end
 for i=0,767 do if change[i] then expectedMap[i]=expectedMap[i]~4 end;wb(0x1000+i,expectedMap[i]) end
 expectedSpans={};expectedBytes=0
 if completed==0 then
  assert(rw(0x1604)==0,'CPU did not reset stale shadow-valid SRAM')
  expectedSpans={{0,768}}
 else
  local start,stop=nil,nil
  for i=0,766,2 do
   if expectedMap[i]~=previousMap[i] or expectedMap[i+1]~=previousMap[i+1] then
    if not start then start=i elseif i-stop>64 then expectedSpans[#expectedSpans+1]={start,stop-start};start=i end
    stop=i+2
   end
  end
  if start then expectedSpans[#expectedSpans+1]={start,stop-start} end
 end
 for _,r in ipairs(expectedSpans) do expectedBytes=expectedBytes+r[2] end
end,true)
hook('render_stop',function()
 assert(rw(0x1600)==#expectedSpans,'GSU descriptor count mismatch')
 assert(rw(0x1602)==expectedBytes,'GSU descriptor byte sum mismatch got='..rw(0x1602)..' expected='..expectedBytes)
 assert(rw(0x1604)==1,'GSU shadow-valid mismatch')
 for i,r in ipairs(expectedSpans) do
  assert(rw(0x1620+(i-1)*4)==0x4000+r[1] and rw(0x1622+(i-1)*4)==r[2],'GSU descriptor value mismatch')
  stats.descriptorChecks=stats.descriptorChecks+1
 end
 for i=0,767 do assert(rb(0x1300+i)==expectedMap[i],'shadow content mismatch') end
 for _,r in ipairs(guardranges) do for a=r[1],r[2] do assert(rb(a)==0xa5,'SRAM guard overwritten at '..a);stats.guards=stats.guards+1 end end
 stats.deltaChecks=stats.deltaChecks+1
 if #expectedSpans==0 then stats.zeroSpans=stats.zeroSpans+1 end
 if #expectedSpans==12 then stats.twelveSpans=stats.twelveSpans+1 end
 if completed==10 or completed==21 then ww(8,1);ww(10,12288);ww(0x600,0);ww(0x602,12288);stats.fullMaps=stats.fullMaps+1 end
end,true)
hook('fx_upload_color',function()
  local st=emu.getState()
  local line=st['ppu.scanline']
  assert(line>=203 and line<=261,'HDMA enabled after line-0 initialization: '..line)
  stats.latestHdmaReenableLine=math.max(stats.latestHdmaReenableLine or 0,line)
end)
hook('fx_color_stage_done',function() stats.stages=stats.stages+1 end)
emu.addMemoryCallback(guard(function(a,v)
 if v~=4 then return end
 assert(read('fx_color_dma_count')==#expectedSpans,'CPU plan copy count mismatch')
 for i,r in ipairs(expectedSpans) do
  local addr=0x7e0000+labels.fx_color_dma+(i-1)*4
  assert(m(addr)+256*m(addr+1)==0x4000+r[1] and m(addr+2)+256*m(addr+3)==r[2],'CPU plan copy mismatch')
 end
 local base=read('fx_color_vram_base')*2
 for i=0,767 do assert(emu.read(base+i*2+1,emu.memType.snesVideoRam)==expectedMap[i],'VRAM delta mismatch at '..i) end
 local palette=blob(64,64,emu.memType.snesCgRam)
 assert(palette==(latchedMode==1 and colorpalette or monochrome),'CGRAM mode mismatch')
 stats.paletteChecks=stats.paletteChecks+1
 previousMap=expectedMap;completed=completed+1
 if ground>=1950 then finish(0) end
end),emu.callbackType.write,0x7e1df0,0x7e1df0)
emu.addEventCallback(guard(function() emu.setInput({},0) end),emu.eventType.inputPolled)

hook('fx_prepare_obj_dma',function() write('fx_obj_present_count',32) end)
