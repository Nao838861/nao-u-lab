
local labels={["LoadAudioData"]=34429,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=36751,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=34035,["Tad_GetSong"]=34139,["Tad_GlobalVolumesPersist"]=34167,["Tad_GlobalVolumesResetOnSongStart"]=34161,["Tad_Init"]=33651,["Tad_IsLoaderActive"]=34193,["Tad_IsSfxPlaying"]=34207,["Tad_IsSongLoaded"]=34201,["Tad_IsSongPlaying"]=34213,["Tad_LoadSong"]=34094,["Tad_LoadSongIfChanged"]=34127,["Tad_Loader_Bin"]=36635,["Tad_Loader_SIZE"]=116,["Tad_Process"]=33778,["Tad_QueueCommand"]=34051,["Tad_QueueCommandOverride"]=34056,["Tad_QueuePannedSoundEffect"]=34073,["Tad_QueueSoundEffect"]=34083,["Tad_ReloadCommonAudioData"]=34143,["Tad_SetTransferSize"]=34173,["Tad_SongsStartImmediately"]=34149,["Tad_SongsStartPaused"]=34155,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=1,["Tad_sfxQueue_sfx"]=0,["__BSS_LOAD__"]=59022,["__BSS_RUN__"]=59022,["__BSS_SIZE__"]=5741,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65167,["__COLORBSS_LOAD__"]=3712,["__COLORBSS_RUN__"]=3712,["__COLORBSS_SIZE__"]=1820,["__COLORRODATA_LOAD__"]=54881,["__COLORRODATA_RUN__"]=1024,["__COLORRODATA_SIZE__"]=2688,["__DATA_LOAD__"]=4376195,["__DATA_RUN__"]=59011,["__DATA_SIZE__"]=11,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50819,["__STARTUP__"]=1,["_abs"]=64798,["_boss_age"]=59637,["_boss_attribute_cache"]=59472,["_boss_attribute_cache_count"]=59634,["_boss_attribute_z_cache"]=59616,["_boss_dda_phase"]=59855,["_boss_dda_x"]=59861,["_boss_dda_y"]=59867,["_boss_death_parts"]=59639,["_boss_death_timer"]=59638,["_boss_fire_gap"]=59648,["_boss_fire_round"]=59645,["_boss_fire_shots"]=59647,["_boss_fire_state"]=59644,["_boss_fire_volley"]=59646,["_boss_history_x"]=59088,["_boss_history_y"]=59216,["_boss_history_z"]=59344,["_boss_last_vblank"]=59024,["_boss_motion_steps"]=59643,["_boss_part_active"]=59052,["_boss_part_bottom"]=59034,["_boss_part_fall_fraction"]=59079,["_boss_part_fall_velocity"]=59070,["_boss_part_timer"]=59061,["_boss_part_x"]=59025,["_boss_part_z"]=59043,["_boss_path_half"]=59642,["_boss_player_bottom"]=59651,["_boss_player_x"]=59649,["_boss_render_camera_delta"]=59635,["_boss_restart_timer"]=59640,["_boss_z_phase"]=59641,["_death_accel_fraction"]=59889,["_death_timer"]=59887,["_death_vy"]=59886,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_audio_events"]=5648,["_fx_boss_hits"]=61880,["_fx_boss_project"]=61685,["_fx_build_ground"]=13056,["_fx_build_packet"]=23493,["_fx_buttons"]=62055,["_fx_draw"]=60131,["_fx_draw_count"]=60771,["_fx_em0_geometry"]=58908,["_fx_enemy_collisions"]=58375,["_fx_enemy_em1_update"]=59784,["_fx_enemy_em1_update_reference"]=7583,["_fx_enemy_fire_em1"]=7521,["_fx_enemy_remove"]=7510,["_fx_enemy_render"]=57745,["_fx_enemy_render_bullets"]=58024,["_fx_far_d_acc"]=62067,["_fx_far_u_acc"]=62065,["_fx_fire_actions"]=62058,["_fx_frame"]=60688,["_fx_ground_c1ptr"]=63823,["_fx_ground_c3ptr"]=63825,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62074,["_fx_ground_color3"]=62524,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63789,["_fx_ground_far_xptr"]=63819,["_fx_ground_far_y"]=63829,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63827,["_fx_ground_horizontal"]=62974,["_fx_ground_hptr"]=63784,["_fx_ground_native"]=13141,["_fx_ground_palette_record"]=63787,["_fx_ground_phase"]=62054,["_fx_ground_vptr"]=63821,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63786,["_fx_init"]=11689,["_fx_input"]=62057,["_fx_open_size"]=62950,["_fx_packet"]=60774,["_fx_packet_count"]=60772,["_fx_present"]=12402,["_fx_read_input"]=12166,["_fx_send_ground"]=12198,["_fx_sky_color"]=39095,["_fx_stage_contact"]=57061,["_fx_stage_render"]=56362,["_fx_stage_update"]=57392,["_fx_submit"]=62738,["_fx_toggle_color"]=23819,["_ground_irq_vblank_count"]=62062,["_history_head"]=59636,["_hit_pending"]=62069,["_intro_timer"]=59890,["_legacy_enemy_fire_boss_at"]=6115,["_main"]=11726,["_memcpy"]=64629,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59023,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2096,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=61465,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59022,["_monosh_bullet_reflect_rng"]=59693,["_monosh_collision_bullet_bands"]=59685,["_monosh_combat_build_collision_bands"]=2278,["_monosh_combat_fast_cache_reset"]=12092,["_monosh_combat_fast_frame"]=62234,["_monosh_combat_fast_render"]=62364,["_monosh_combat_fast_render_cached"]=12099,["_monosh_combat_fire_cooldown"]=59694,["_monosh_combat_half_frame"]=59695,["_monosh_combat_init"]=2122,["_monosh_combat_reflect_bullet"]=11737,["_monosh_combat_render"]=2275,["_monosh_combat_update"]=2217,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59850,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59699,["_monosh_enemy_active_count"]=3038,["_monosh_enemy_active_count_value"]=59697,["_monosh_enemy_bullet_count"]=59696,["_monosh_enemy_bullets"]=59779,["_monosh_enemy_camera_delta_cached"]=59848,["_monosh_enemy_collision_cursor"]=59853,["_monosh_enemy_draw_cache_valid"]=59851,["_monosh_enemy_em1_count"]=59849,["_monosh_enemy_em1_phase"]=59824,["_monosh_enemy_em1_shrink"]=59840,["_monosh_enemy_fast_advance"]=59376,["_monosh_enemy_fast_check_player_bullets"]=4128,["_monosh_enemy_fast_render"]=3613,["_monosh_enemy_fast_render_bullets"]=5078,["_monosh_enemy_fast_spawn_due"]=5454,["_monosh_enemy_fast_update_bullets"]=59046,["_monosh_enemy_fire_at"]=3050,["_monosh_enemy_fire_boss_at"]=3079,["_monosh_enemy_fire_em0_fast"]=6513,["_monosh_enemy_frame"]=2841,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59852,["_monosh_enemy_init"]=2692,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59854,["_monosh_enemy_render_only"]=2871,["_monosh_enemy_spawn_index"]=59821,["_monosh_enemy_spawn_wait"]=59822,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3044,["_monosh_enemy_stage_complete_flag"]=59698,["_monosh_ground_depth_pointer"]=62072,["_monosh_ground_offset"]=59011,["_monosh_ground_screen_delta"]=59012,["_monosh_player_bottom"]=59877,["_monosh_player_bullet_count"]=59668,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59653,["_monosh_player_can_fire"]=9341,["_monosh_player_draw_asset"]=9357,["_monosh_player_draw_flags"]=9299,["_monosh_player_init"]=9236,["_monosh_player_invuln"]=59880,["_monosh_player_pose"]=59882,["_monosh_player_state"]=59879,["_monosh_player_stumble"]=59881,["_monosh_player_update"]=60078,["_monosh_player_update_reference"]=10566,["_monosh_player_world_active"]=9335,["_monosh_player_x"]=59875,["_monosh_project_x"]=27539,["_monosh_reflected_bullet_count"]=59684,["_monosh_reflected_bullets"]=59669,["_monosh_runtime_fire_actions"]=62059,["_monosh_runtime_frame_counter"]=62060,["_monosh_runtime_paused"]=62064,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60129,["_monosh_stage_collision_bullet_index"]=60130,["_monosh_stage_contact_result"]=60127,["_monosh_stage_draw_cache_valid"]=60128,["_monosh_stage_frame"]=10841,["_monosh_stage_frame_counter"]=59991,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59995,["_monosh_stage_hitbox_count"]=60125,["_monosh_stage_hitboxes"]=59997,["_monosh_stage_init"]=10806,["_monosh_stage_is_clear"]=10890,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59996,["_monosh_stage_need_hitboxes"]=60126,["_monosh_stage_object_count"]=59989,["_monosh_stage_objects"]=59893,["_monosh_stage_render_only"]=10887,["_monosh_stage_spawn_index"]=59990,["_monosh_stage_spawn_wait"]=59993,["_monosh_stage_title_timer"]=59883,["_monosh_title_draw"]=11715,["_monosh_title_visible"]=59013,["_movement_fraction"]=59888,["_old_buttons"]=62070,["_player_flip"]=59891,["_player_fy"]=59884,["_player_run_phase"]=59892,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12093,["addeq0sp"]=64131,["addeqysp"]=64133,["addysp"]=64149,["addysp1"]=64148,["aslax2"]=64162,["aslax3"]=64173,["aslax4"]=64187,["asleax1"]=64204,["asrax1"]=64216,["asrax2"]=64226,["asrax3"]=64241,["booleq"]=64591,["boolge"]=64608,["boolgt"]=64606,["boolle"]=64598,["boollt"]=64600,["boolne"]=64585,["booluge"]=64624,["boolugt"]=64622,["boolule"]=64614,["boolult"]=64616,["c_sp"]=80,["clip_edges"]=99624,["color_boot_map"]=34587,["color_palette"]=34459,["decsp1"]=64261,["decsp2"]=64270,["decsp3"]=64283,["decsp4"]=64296,["decsp5"]=64309,["dma_cache"]=100208,["dma_cache_end"]=100409,["dma_deadline_fine"]=12999,["dma_finished"]=12924,["dma_started"]=12845,["fx_add_next_bounds"]=62737,["fx_audio_init"]=34219,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=34246,["fx_audio_sent"]=5653,["fx_build_color"]=23896,["fx_build_obj"]=26323,["fx_color_build_done"]=24884,["fx_color_cells"]=1024,["fx_color_dma"]=5512,["fx_color_dma_bytes"]=5518,["fx_color_dma_count"]=5516,["fx_color_map0"]=3712,["fx_color_map1"]=4480,["fx_color_mode"]=59014,["fx_color_next_ptr"]=59015,["fx_color_present_mode"]=5248,["fx_color_present_ptr"]=59017,["fx_color_stage_done"]=26236,["fx_color_staged"]=5522,["fx_color_upload_done"]=26174,["fx_color_vram_base"]=59020,["fx_commit_dma"]=62737,["fx_dma_bytes"]=64633,["fx_dma_count"]=64631,["fx_dma_desc"]=64635,["fx_em1_open_sizes"]=62993,["fx_emit_native"]=58238,["fx_is_obj"]=26238,["fx_latch_color"]=25918,["fx_latch_obj"]=27386,["fx_obj_build_done"]=26957,["fx_obj_count"]=64395,["fx_obj_dma_bytes"]=64435,["fx_obj_next"]=64123,["fx_obj_overflow"]=64399,["fx_obj_present"]=64259,["fx_obj_present_count"]=64397,["fx_obj_upload_done"]=27529,["fx_plan_dma"]=62718,["fx_project16"]=27569,["fx_read_gsu_spans"]=62663,["fx_reset_next_bounds"]=62737,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63835,["fx_stage_color"]=26176,["fx_upload_color"]=25970,["fx_upload_ground"]=13434,["fx_upload_obj"]=27410,["game_started"]=12102,["generic"]=99054,["generic_render"]=98622,["ground_done"]=13387,["ground_empty"]=13528,["hot_cache"]=98464,["hot_cache_end"]=98975,["incsp1"]=64389,["incsp2"]=64404,["incsp3"]=64418,["incsp4"]=64423,["incsp5"]=64428,["incsp6"]=64433,["incsp7"]=64438,["incsp8"]=64443,["initialized"]=23561,["ldaidx"]=64448,["margin_render"]=98656,["margin_render_end"]=98735,["margin_select"]=100086,["memcpy_getparams"]=64670,["memcpy_upwards"]=64632,["mulax10"]=64689,["mulax3"]=64714,["mulax5"]=64731,["mulax6"]=64751,["mulax7"]=64773,["negax"]=64802,["order"]=63867,["packed_double"]=99491,["packed_double_cache"]=99522,["packed_half"]=99209,["packed_half_cache"]=99232,["packed_mirror_half"]=99383,["packed_mirror_half_cache"]=99406,["packed_mirror_one"]=99317,["packed_mirror_one_cache"]=99341,["packed_mirror_quarter"]=99442,["packed_mirror_quarter_cache"]=99461,["packed_one"]=99143,["packed_one_cache"]=99167,["packed_quarter"]=99268,["packed_quarter_cache"]=99287,["packet_done"]=23648,["packet_work"]=14,["popax"]=64396,["popptr1"]=64816,["popsargsudiv16"]=64906,["ptr1"]=88,["ptr2"]=90,["ptr3"]=92,["ptr4"]=94,["push0"]=64852,["push0ax"]=64555,["pusha"]=64834,["pusha0"]=64854,["pusha0sp"]=64830,["pushax"]=64856,["pushaysp"]=64832,["pusheax"]=64561,["pushl0"]=64552,["pushw0sp"]=64878,["pushwysp"]=64880,["regbank"]=100,["regsave"]=84,["render_entry"]=98304,["render_finished"]=12632,["render_started"]=12600,["render_stop"]=100413,["reset"]=32768,["scaled_select"]=99724,["select_dma_deadline"]=12943,["shlax2"]=64162,["shlax3"]=64173,["shlax4"]=64187,["shleax1"]=64204,["shrax1"]=64938,["shrax3"]=64946,["shrax4"]=64960,["sorted"]=23627,["sreg"]=82,["stage_update_done"]=57743,["staspidx"]=64977,["stax0sp"]=64999,["staxspidx"]=65010,["staxysp"]=65001,["subysp"]=65058,["tmp1"]=96,["tmp2"]=97,["tmp3"]=98,["tmp4"]=99,["tosadda0"]=64103,["tosaddax"]=64105,["tosdiva0"]=64322,["tosdivax"]=64324,["tosicmp"]=64345,["tosicmp0"]=64343,["tosmul0ax"]=64460,["tosmuleax"]=64466,["tossuba0"]=65037,["tossubax"]=65039,["tosudiva0"]=65071,["tosudivax"]=65073,["tosumoda0"]=65150,["tosumodax"]=65152,["tosumul0ax"]=64460,["tosumuleax"]=64466,["udiv16"]=65088,["L1"]=65122,["@L1"]=65140,["Pos"]=64340,["@L3"]=64381,["@L4"]=64382,["@L2"]=65144,["L0"]=65098,["mul32"]=64466,["ret0"]=64587,["ret1"]=64593,["L3"]=64659,["done"]=64667,["L2"]=64931,["@L0"]=65129,["udiv16by8a"]=65129}
local output="D:/AI/Nao_u_BOT/GPT/projects/monosh_fx2/build/game_v001/audio_quick"
local field=0
local initialized=false
local report=assert(io.open(output..'/trace.jsonl','w'))
local commands={}
local parameters={0,0,0,0}
local shots=0
local busyCalls=0
local audioStart=0
local audioMax=0
local audioSum=0
local audioCalls=0
local requested=nil
local scheduled=nil
local captured={}
local fixtures={}
local pauseTick=nil
local pauseStable=0
local restoredBoss=nil
local function read(name) return emu.read(0x7e0000+assert(labels[name]),emu.memType.snesMemory) end
local function put(name,v) emu.write(0x7e0000+assert(labels[name]),v,emu.memType.snesMemory) end
local function tick() return emu.read16(3,emu.memType.spcRam) end
local function dump(name,mt,count)
  local f=assert(io.open(output..'/'..name,'wb'))
  local bytes={}
  for i=0,count-1 do bytes[#bytes+1]=string.char(emu.read(i,mt)) end
  f:write(table.concat(bytes));f:close()
end
local function snapshot(name)
  dump(name..'.ram',emu.memType.spcRam,65536)
  dump(name..'.dsp',emu.memType.spcDspRegisters,128)
  local f=assert(io.open(output..'/'..name..'.state','w'))
  for k,v in pairs(emu.getState()) do
    if k:sub(1,4)=='spc.' and (type(v)=='number' or type(v)=='boolean') then f:write(k..'='..tostring(v)..'\n') end
  end
  if name:sub(1,3)=='sfx' then
    for i=1,4 do f:write('capture.port'..(i-1)..'='..parameters[i]..'\n') end
  end
  f:close()
end
local function guard(fn)
  return function(...)
    local ok,err=pcall(fn,...)
    if not ok then local f=io.open(output..'/error.txt','w');f:write(tostring(err));f:close();emu.stop(1) end
  end
end
emu.addMemoryCallback(guard(function(a,v)
  parameters[a-0x2140+1]=v
  if a==0x2140 and initialized then
    local cmd=v&0x1e
    if cmd==6 then
      local id=parameters[2]
      commands[id]=(commands[id] or 0)+1
      report:write(string.format('{"field":%d,"sfx":%d,"tick":%d}\n',field,id,tick()))
      if not captured[id] then requested='sfx'..id;captured[id]=true end
    elseif cmd==0 or cmd==4 then
      report:write(string.format('{"field":%d,"command":%d,"tick":%d}\n',field,cmd,tick()))
    end
  end
end),emu.callbackType.write,0x2140,0x2143,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function(a,v)
  if initialized and v&1~=0 then shots=shots+1 end
end),emu.callbackType.write,0x7e0000+labels._fx_audio_events,0x7e0000+labels._fx_audio_events,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  initialized=true
  if field<550 or field>1000 then put('_monosh_player_invuln',255) end
  if field>=400 and not fixtures.stumble then
    put('_hit_pending',2);fixtures.stumble=true
  end
  if field>=600 and not fixtures.death then
    put('_monosh_player_invuln',0);put('_hit_pending',1);fixtures.death=true
  end
end),emu.callbackType.exec,0x7f0000+labels._fx_frame,0x7f0000+labels._fx_frame,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  audioStart=emu.getState().masterClock
  if emu.read(0x3030,emu.memType.snesMemory)&0x20~=0 then busyCalls=busyCalls+1 end
  if field>=320 and not fixtures.explosion then put('_fx_audio_events',2);fixtures.explosion=true end
  if field>=360 and not fixtures.reflect then put('_fx_audio_events',4);fixtures.reflect=true end
  if field>=950 and not fixtures.boss then
    restoredBoss=read('_monosh_boss_state');put('_monosh_boss_state',2);fixtures.boss=true
  end
end),emu.callbackType.exec,labels.fx_audio_process,labels.fx_audio_process,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  local ms=((emu.getState().masterClock-audioStart)&0xffffffff)/21477.272
  audioMax=math.max(audioMax,ms);audioSum=audioSum+ms;audioCalls=audioCalls+1
  if restoredBoss then put('_monosh_boss_state',restoredBoss);restoredBoss=nil end
end),emu.callbackType.exec,0x7f0000+labels.render_finished+4,0x7f0000+labels.render_finished+4,emu.cpuType.snes,emu.memType.snesMemory)
-- Driver v0.4.2 mainloopの命令境界でSPCを書き出す。
emu.addMemoryCallback(guard(function()
  if requested then snapshot(requested);requested=nil end
end),emu.callbackType.exec,0x0394,0x0394,emu.cpuType.spc,emu.memType.spcMemory)
emu.addEventCallback(guard(function()
  emu.setInput({a=field>=110 and field<300,start=(field>=1100 and field<=1103) or (field>=1220 and field<=1223)},0)
end),emu.eventType.inputPolled)
emu.addEventCallback(guard(function()
  field=field+1
  if field==305 then requested='bgm' end
  if scheduled and field>=scheduled.field then requested=scheduled.name;scheduled=nil end
  if field==1140 then pauseTick=tick() end
  if field>1140 and field<1200 then assert(tick()==pauseTick,'music advanced while paused');pauseStable=pauseStable+1 end
  if field%300==0 then
    local env={}
    for ch=0,7 do env[#env+1]=emu.read(ch*16+8,emu.memType.spcDspRegisters) end
    report:write(string.format('{"field":%d,"tick":%d,"env":[%s]}\n',field,tick(),table.concat(env,',')))
  end
  if field==1600-5 then requested='loop' end
  if field>=1600 then
    for id=0,5 do assert(commands[id] and commands[id]>0,'missing sfx '..id) end
    assert(busyCalls==0,'audio API called while GSU running')
    assert(pauseStable==59,'pause not checked')
    assert(shots>=commands[5],'more shot sounds than actual spawns')
    if false then assert(tick()>30720,'song has not crossed loop point') end
    local f=assert(io.open(output..'/summary.json','w'))
    local counts={};for id=0,5 do counts[#counts+1]=commands[id] end
    f:write(string.format('{"fields":%d,"ticks":%d,"sfxCommands":[%s],"spawns":%d,"busyCalls":%d,"pauseStableFields":%d,"audioCalls":%d,"audioMaxMs":%.6f,"audioMeanMs":%.6f}',field,tick(),table.concat(counts,','),shots,busyCalls,pauseStable,audioCalls,audioMax,audioSum/audioCalls))
    f:close();report:close();emu.stop(0)
  end
end),emu.eventType.endFrame)
