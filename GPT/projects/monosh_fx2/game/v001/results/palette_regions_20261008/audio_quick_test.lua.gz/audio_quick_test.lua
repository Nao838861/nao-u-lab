
local labels={["LoadAudioData"]=34429,["TAD_IO_VERSION"]=20,["Tad_AudioDriver_Bin"]=36751,["Tad_AudioDriver_SIZE"]=3221,["Tad_FinishLoadingData"]=34035,["Tad_GetSong"]=34139,["Tad_GlobalVolumesPersist"]=34167,["Tad_GlobalVolumesResetOnSongStart"]=34161,["Tad_Init"]=33651,["Tad_IsLoaderActive"]=34193,["Tad_IsSfxPlaying"]=34207,["Tad_IsSongLoaded"]=34201,["Tad_IsSongPlaying"]=34213,["Tad_LoadSong"]=34094,["Tad_LoadSongIfChanged"]=34127,["Tad_Loader_Bin"]=36635,["Tad_Loader_SIZE"]=116,["Tad_Process"]=33778,["Tad_QueueCommand"]=34051,["Tad_QueueCommandOverride"]=34056,["Tad_QueuePannedSoundEffect"]=34073,["Tad_QueueSoundEffect"]=34083,["Tad_ReloadCommonAudioData"]=34143,["Tad_SetTransferSize"]=34173,["Tad_SongsStartImmediately"]=34149,["Tad_SongsStartPaused"]=34155,["Tad_audioMode"]=5633,["Tad_flags"]=5632,["Tad_sfxQueue_pan"]=1,["Tad_sfxQueue_sfx"]=0,["__BSS_LOAD__"]=59022,["__BSS_RUN__"]=59022,["__BSS_SIZE__"]=5749,["__CODE_LOAD__"]=4259840,["__CODE_RUN__"]=0,["__CODE_SIZE__"]=65154,["__COLORBSS_LOAD__"]=1908,["__COLORBSS_RUN__"]=1908,["__COLORBSS_SIZE__"]=1788,["__COLORRODATA_LOAD__"]=54881,["__COLORRODATA_RUN__"]=1024,["__COLORRODATA_SIZE__"]=884,["__DATA_LOAD__"]=4376195,["__DATA_RUN__"]=59011,["__DATA_SIZE__"]=11,["__RODATA_LOAD__"]=4325376,["__RODATA_RUN__"]=8192,["__RODATA_SIZE__"]=50819,["__STARTUP__"]=1,["_abs"]=64785,["_boss_age"]=59637,["_boss_attribute_cache"]=59472,["_boss_attribute_cache_count"]=59634,["_boss_attribute_z_cache"]=59616,["_boss_dda_phase"]=59855,["_boss_dda_x"]=59861,["_boss_dda_y"]=59867,["_boss_death_parts"]=59639,["_boss_death_timer"]=59638,["_boss_fire_gap"]=59648,["_boss_fire_round"]=59645,["_boss_fire_shots"]=59647,["_boss_fire_state"]=59644,["_boss_fire_volley"]=59646,["_boss_history_x"]=59088,["_boss_history_y"]=59216,["_boss_history_z"]=59344,["_boss_last_vblank"]=59024,["_boss_motion_steps"]=59643,["_boss_part_active"]=59052,["_boss_part_bottom"]=59034,["_boss_part_fall_fraction"]=59079,["_boss_part_fall_velocity"]=59070,["_boss_part_timer"]=59061,["_boss_part_x"]=59025,["_boss_part_z"]=59043,["_boss_path_half"]=59642,["_boss_player_bottom"]=59651,["_boss_player_x"]=59649,["_boss_render_camera_delta"]=59635,["_boss_restart_timer"]=59640,["_boss_z_phase"]=59641,["_death_accel_fraction"]=59889,["_death_timer"]=59887,["_death_vy"]=59886,["_enemy_p0_samples"]=22798,["_enemy_p1_samples"]=23533,["_enemy_p2_samples"]=24238,["_enemy_p3_samples"]=24943,["_enemy_p4_samples"]=25648,["_enemy_p5_samples"]=26365,["_enemy_p6_samples"]=27082,["_enemy_p7_samples"]=27649,["_enemy_p8_samples"]=28216,["_fx_asset_bank"]=33552,["_fx_asset_height"]=33508,["_fx_asset_width"]=33464,["_fx_audio_events"]=5648,["_fx_boss_hits"]=61867,["_fx_boss_project"]=61672,["_fx_build_ground"]=13121,["_fx_build_packet"]=23596,["_fx_buttons"]=62055,["_fx_draw"]=60131,["_fx_draw_count"]=60771,["_fx_em0_geometry"]=58895,["_fx_enemy_collisions"]=58362,["_fx_enemy_em1_update"]=59771,["_fx_enemy_em1_update_reference"]=7583,["_fx_enemy_fire_em1"]=7521,["_fx_enemy_remove"]=7510,["_fx_enemy_render"]=57732,["_fx_enemy_render_bullets"]=58011,["_fx_far_d_acc"]=62067,["_fx_far_u_acc"]=62065,["_fx_fire_actions"]=62058,["_fx_frame"]=60675,["_fx_ground_c1ptr"]=63823,["_fx_ground_c3ptr"]=63825,["_fx_ground_camera"]=33596,["_fx_ground_color1"]=62074,["_fx_ground_color3"]=62524,["_fx_ground_depth_rows"]=33741,["_fx_ground_far_x"]=63789,["_fx_ground_far_xptr"]=63819,["_fx_ground_far_y"]=63829,["_fx_ground_greens"]=39087,["_fx_ground_horizon"]=63827,["_fx_ground_horizontal"]=62974,["_fx_ground_hptr"]=63784,["_fx_ground_native"]=13206,["_fx_ground_palette_record"]=63787,["_fx_ground_phase"]=62054,["_fx_ground_vptr"]=63821,["_fx_ground_width"]=39006,["_fx_ground_world_phase"]=63786,["_fx_init"]=11689,["_fx_input"]=62057,["_fx_open_size"]=62937,["_fx_packet"]=60774,["_fx_packet_count"]=60772,["_fx_present"]=12402,["_fx_read_input"]=12166,["_fx_send_ground"]=12198,["_fx_sky_color"]=39095,["_fx_stage_contact"]=57048,["_fx_stage_render"]=56349,["_fx_stage_update"]=57379,["_fx_submit"]=62725,["_fx_toggle_color"]=23922,["_ground_irq_vblank_count"]=62062,["_history_head"]=59636,["_hit_pending"]=62069,["_intro_timer"]=59890,["_legacy_enemy_fire_boss_at"]=6115,["_main"]=11726,["_memcpy"]=64616,["_monosh_bom_geometry"]=18431,["_monosh_boss_body_geometry"]=14174,["_monosh_boss_bom_depth_by_size"]=14618,["_monosh_boss_bom_geometry"]=14396,["_monosh_boss_bullet_velocity"]=14856,["_monosh_boss_draw_order_base"]=9632,["_monosh_boss_draw_order_mid"]=11792,["_monosh_boss_explosion_ground_bottom"]=14745,["_monosh_boss_explosion_scale_low"]=14634,["_monosh_boss_face_geometry"]=13952,["_monosh_boss_frame"]=178,["_monosh_boss_hp"]=59023,["_monosh_boss_init"]=21,["_monosh_boss_path_center_y"]=8672,["_monosh_boss_path_center_y_mid"]=9392,["_monosh_boss_path_x"]=8432,["_monosh_boss_path_x_mid"]=9152,["_monosh_boss_path_z"]=8192,["_monosh_boss_path_z_mid"]=8912,["_monosh_boss_prepare_fire"]=2096,["_monosh_boss_prepare_render"]=214,["_monosh_boss_render_only"]=61452,["_monosh_boss_should_restart"]=0,["_monosh_boss_state"]=59022,["_monosh_bullet_reflect_rng"]=59693,["_monosh_collision_bullet_bands"]=59685,["_monosh_combat_build_collision_bands"]=2278,["_monosh_combat_fast_cache_reset"]=12092,["_monosh_combat_fast_frame"]=62221,["_monosh_combat_fast_render"]=62351,["_monosh_combat_fast_render_cached"]=12099,["_monosh_combat_fire_cooldown"]=59694,["_monosh_combat_half_frame"]=59695,["_monosh_combat_init"]=2122,["_monosh_combat_reflect_bullet"]=11737,["_monosh_combat_render"]=2275,["_monosh_combat_update"]=2217,["_monosh_ebullet4_geometry"]=19238,["_monosh_ebullet_animation_geometry"]=19016,["_monosh_ebullet_geometry"]=19460,["_monosh_ebullet_velocity"]=19470,["_monosh_em1_animation_assets_ready"]=59850,["_monosh_em1_closed_geometry"]=18653,["_monosh_em1_open_geometry"]=18875,["_monosh_enemies"]=59699,["_monosh_enemy_active_count"]=3038,["_monosh_enemy_active_count_value"]=59697,["_monosh_enemy_bullet_count"]=59696,["_monosh_enemy_bullets"]=59779,["_monosh_enemy_camera_delta_cached"]=59848,["_monosh_enemy_collision_cursor"]=59853,["_monosh_enemy_draw_cache_valid"]=59851,["_monosh_enemy_em1_count"]=59849,["_monosh_enemy_em1_phase"]=59824,["_monosh_enemy_em1_shrink"]=59840,["_monosh_enemy_fast_advance"]=59363,["_monosh_enemy_fast_check_player_bullets"]=4128,["_monosh_enemy_fast_render"]=3613,["_monosh_enemy_fast_render_bullets"]=5078,["_monosh_enemy_fast_spawn_due"]=5454,["_monosh_enemy_fast_update_bullets"]=59033,["_monosh_enemy_fire_at"]=3050,["_monosh_enemy_fire_boss_at"]=3079,["_monosh_enemy_fire_em0_fast"]=6513,["_monosh_enemy_frame"]=2841,["_monosh_enemy_geometry"]=18209,["_monosh_enemy_ground_bottom"]=18905,["_monosh_enemy_half_frame"]=59852,["_monosh_enemy_init"]=2692,["_monosh_enemy_path_fire_frames"]=28828,["_monosh_enemy_path_frames"]=28819,["_monosh_enemy_paths"]=28783,["_monosh_enemy_player_hit"]=59854,["_monosh_enemy_render_only"]=2871,["_monosh_enemy_spawn_index"]=59821,["_monosh_enemy_spawn_wait"]=59822,["_monosh_enemy_spawns"]=28837,["_monosh_enemy_stage_complete"]=3044,["_monosh_enemy_stage_complete_flag"]=59698,["_monosh_ground_depth_pointer"]=62072,["_monosh_ground_offset"]=59011,["_monosh_ground_screen_delta"]=59012,["_monosh_player_bottom"]=59877,["_monosh_player_bullet_count"]=59668,["_monosh_player_bullet_sizes"]=18184,["_monosh_player_bullets"]=59653,["_monosh_player_can_fire"]=9341,["_monosh_player_draw_asset"]=9357,["_monosh_player_draw_flags"]=9299,["_monosh_player_init"]=9236,["_monosh_player_invuln"]=59880,["_monosh_player_pose"]=59882,["_monosh_player_state"]=59879,["_monosh_player_stumble"]=59881,["_monosh_player_update"]=60065,["_monosh_player_update_reference"]=10566,["_monosh_player_world_active"]=9335,["_monosh_player_x"]=59875,["_monosh_project_x"]=27526,["_monosh_reflected_bullet_count"]=59684,["_monosh_reflected_bullets"]=59669,["_monosh_runtime_fire_actions"]=62059,["_monosh_runtime_frame_counter"]=62060,["_monosh_runtime_paused"]=62064,["_monosh_stage1_spawn_count"]=29979,["_monosh_stage1_spawns"]=29043,["_monosh_stage_collision_bullet_cursor"]=60129,["_monosh_stage_collision_bullet_index"]=60130,["_monosh_stage_contact_result"]=60127,["_monosh_stage_draw_cache_valid"]=60128,["_monosh_stage_frame"]=10841,["_monosh_stage_frame_counter"]=59991,["_monosh_stage_geometry"]=32645,["_monosh_stage_half_frame"]=59995,["_monosh_stage_hitbox_count"]=60125,["_monosh_stage_hitboxes"]=59997,["_monosh_stage_init"]=10806,["_monosh_stage_is_clear"]=10890,["_monosh_stage_lift"]=33434,["_monosh_stage_near_count"]=59996,["_monosh_stage_need_hitboxes"]=60126,["_monosh_stage_object_count"]=59989,["_monosh_stage_objects"]=59893,["_monosh_stage_render_only"]=10887,["_monosh_stage_spawn_index"]=59990,["_monosh_stage_spawn_wait"]=59993,["_monosh_stage_title_timer"]=59883,["_monosh_title_draw"]=11715,["_monosh_title_visible"]=59013,["_movement_fraction"]=59888,["_old_buttons"]=62070,["_player_flip"]=59891,["_player_fy"]=59884,["_player_run_phase"]=59892,["_pose_x_01"]=28981,["_pose_x_12"]=29000,["_pose_x_23"]=29019,["_stage_bom0_geometry"]=32201,["_stage_bush0_geometry"]=29981,["_stage_bush1_geometry"]=30425,["_stage_em0_geometry"]=31313,["_stage_flystone_geometry"]=30869,["_stage_lift_0"]=32657,["_stage_lift_1"]=32768,["_stage_lift_2"]=32879,["_stage_lift_3"]=32990,["_stage_lift_4"]=33101,["_stage_lift_5"]=33212,["_stage_lift_6"]=33323,["_stage_tree0_geometry"]=31757,["_v9968_copy_to_vram_linear"]=12093,["addeq0sp"]=64118,["addeqysp"]=64120,["addysp"]=64136,["addysp1"]=64135,["aslax2"]=64149,["aslax3"]=64160,["aslax4"]=64174,["asleax1"]=64191,["asrax1"]=64203,["asrax2"]=64213,["asrax3"]=64228,["booleq"]=64578,["boolge"]=64595,["boolgt"]=64593,["boolle"]=64585,["boollt"]=64587,["boolne"]=64572,["booluge"]=64611,["boolugt"]=64609,["boolule"]=64601,["boolult"]=64603,["c_sp"]=156,["clip_edges"]=99624,["color_boot_map"]=34587,["color_clear_dirty"]=25127,["color_clear_dirty_row"]=25131,["color_clear_dirty_skip"]=25232,["color_clear_ready"]=24057,["color_cols_done"]=24565,["color_kernel_restore"]=24802,["color_next_draw"]=24091,["color_palette"]=34459,["color_prepare_cols"]=24488,["color_rows"]=24658,["color_skip_draw"]=24826,["color_visible"]=24261,["decsp1"]=64248,["decsp2"]=64257,["decsp3"]=64270,["decsp4"]=64283,["decsp5"]=64296,["dma_cache"]=100208,["dma_cache_end"]=100409,["dma_deadline_fine"]=13064,["dma_finished"]=12989,["dma_last_line"]=255,["dma_started"]=12901,["fx_add_next_bounds"]=62724,["fx_audio_init"]=34219,["fx_audio_last_sfx"]=5655,["fx_audio_process"]=34246,["fx_audio_sent"]=5653,["fx_build_color"]=23993,["fx_build_obj"]=26224,["fx_color_build_done"]=24833,["fx_color_cells"]=1024,["fx_color_dma"]=3640,["fx_color_dma_bytes"]=3690,["fx_color_dma_count"]=3688,["fx_color_map0"]=1908,["fx_color_map1"]=2676,["fx_color_mode"]=59014,["fx_color_next_ptr"]=59015,["fx_color_present_mode"]=3444,["fx_color_present_ptr"]=59017,["fx_color_stage_done"]=26065,["fx_color_staged"]=3692,["fx_color_upload_done"]=25925,["fx_color_vram_base"]=59020,["fx_commit_dma"]=62724,["fx_dma_bytes"]=64641,["fx_dma_count"]=64639,["fx_dma_desc"]=64643,["fx_em1_open_sizes"]=62980,["fx_emit_native"]=58225,["fx_is_obj"]=26139,["fx_latch_color"]=25729,["fx_latch_obj"]=27287,["fx_obj_build_done"]=26858,["fx_obj_count"]=64401,["fx_obj_dma_bytes"]=64441,["fx_obj_next"]=64129,["fx_obj_overflow"]=64405,["fx_obj_present"]=64265,["fx_obj_present_count"]=64403,["fx_obj_upload_done"]=27516,["fx_plan_dma"]=62705,["fx_prepare_obj_dma"]=27394,["fx_project16"]=27556,["fx_read_gsu_color_plan"]=26067,["fx_read_gsu_spans"]=62650,["fx_reset_next_bounds"]=62724,["fx_sky_colors"]=47777,["fx_sky_colors_end"]=47861,["fx_sky_pointer"]=63835,["fx_stage_color"]=26005,["fx_upload_color"]=25795,["fx_upload_color_palette"]=25927,["fx_upload_ground"]=13537,["fx_upload_obj"]=27461,["game_started"]=12102,["generic"]=99054,["generic_render"]=98622,["ground_done"]=13490,["ground_empty"]=13631,["gsu_color_axis_cache"]=100864,["gsu_color_begin"]=100416,["gsu_color_clear_end"]=100625,["gsu_color_delta_begin"]=101136,["gsu_color_delta_end"]=101316,["gsu_color_done"]=101316,["gsu_color_draw_cache"]=101024,["gsu_color_draw_cache_end"]=101122,["gsu_color_setup_cache"]=100656,["hot_cache"]=98464,["hot_cache_end"]=98975,["incsp1"]=64376,["incsp2"]=64391,["incsp3"]=64405,["incsp4"]=64410,["incsp5"]=64415,["incsp6"]=64420,["incsp7"]=64425,["incsp8"]=64430,["initialized"]=23664,["ldaidx"]=64435,["margin_render"]=98656,["margin_render_end"]=98735,["margin_select"]=100086,["memcpy_getparams"]=64657,["memcpy_upwards"]=64619,["mulax10"]=64676,["mulax3"]=64701,["mulax5"]=64718,["mulax6"]=64738,["mulax7"]=64760,["negax"]=64789,["order"]=63873,["packed_double"]=99491,["packed_double_cache"]=99522,["packed_half"]=99209,["packed_half_cache"]=99232,["packed_mirror_half"]=99383,["packed_mirror_half_cache"]=99406,["packed_mirror_one"]=99317,["packed_mirror_one_cache"]=99341,["packed_mirror_quarter"]=99442,["packed_mirror_quarter_cache"]=99461,["packed_one"]=99143,["packed_one_cache"]=99167,["packed_quarter"]=99268,["packed_quarter_cache"]=99287,["packet_done"]=23751,["packet_work"]=14,["popax"]=64383,["popptr1"]=64803,["popsargsudiv16"]=64893,["ptr1"]=164,["ptr2"]=166,["ptr3"]=168,["ptr4"]=170,["push0"]=64839,["push0ax"]=64542,["pusha"]=64821,["pusha0"]=64841,["pusha0sp"]=64817,["pushax"]=64843,["pushaysp"]=64819,["pusheax"]=64548,["pushl0"]=64539,["pushw0sp"]=64865,["pushwysp"]=64867,["regbank"]=176,["regsave"]=160,["render_entry"]=98304,["render_finished"]=12666,["render_started"]=12634,["render_stop"]=101320,["reset"]=32768,["scaled_select"]=99724,["select_dma_deadline"]=13008,["shlax2"]=64149,["shlax3"]=64160,["shlax4"]=64174,["shleax1"]=64191,["shrax1"]=64925,["shrax3"]=64933,["shrax4"]=64947,["sorted"]=23730,["sreg"]=158,["stage_update_done"]=57730,["staspidx"]=64964,["stax0sp"]=64986,["staxspidx"]=64997,["staxysp"]=64988,["subysp"]=65045,["tmp1"]=172,["tmp2"]=173,["tmp3"]=174,["tmp4"]=175,["tosadda0"]=64090,["tosaddax"]=64092,["tosdiva0"]=64309,["tosdivax"]=64311,["tosicmp"]=64332,["tosicmp0"]=64330,["tosmul0ax"]=64447,["tosmuleax"]=64453,["tossuba0"]=65024,["tossubax"]=65026,["tosudiva0"]=65058,["tosudivax"]=65060,["tosumoda0"]=65137,["tosumodax"]=65139,["tosumul0ax"]=64447,["tosumuleax"]=64453,["udiv16"]=65075,["L1"]=65109,["@L1"]=65127,["Pos"]=64327,["@L3"]=64368,["@L4"]=64369,["@L2"]=65131,["L0"]=65085,["mul32"]=64453,["ret0"]=64574,["ret1"]=64580,["L3"]=64646,["done"]=64654,["L2"]=64918,["@L0"]=65116,["udiv16by8a"]=65116}
local output="/workspace/shared/MonoSH_FX2-palette/build/game_v001/audio_quick"
local field=0
local initialized=false
local report=assert(io.open(output..'/trace.jsonl','w'))
local commands={}
local parameters={0,0,0,0}
local shots=0
local busyCalls=0
local audioStart=0
local audioMax=0
local audioSum=0
local audioCalls=0
local requested=nil
local scheduled=nil
local captured={}
local fixtures={}
local pauseTick=nil
local pauseStable=0
local restoredBoss=nil
local function read(name) return emu.read(0x7e0000+assert(labels[name]),emu.memType.snesMemory) end
local function put(name,v) emu.write(0x7e0000+assert(labels[name]),v,emu.memType.snesMemory) end
local function tick() return emu.read16(3,emu.memType.spcRam) end
local function dump(name,mt,count)
  local f=assert(io.open(output..'/'..name,'wb'))
  local bytes={}
  for i=0,count-1 do bytes[#bytes+1]=string.char(emu.read(i,mt)) end
  f:write(table.concat(bytes));f:close()
end
local function snapshot(name)
  dump(name..'.ram',emu.memType.spcRam,65536)
  dump(name..'.dsp',emu.memType.spcDspRegisters,128)
  local f=assert(io.open(output..'/'..name..'.state','w'))
  for k,v in pairs(emu.getState()) do
    if k:sub(1,4)=='spc.' and (type(v)=='number' or type(v)=='boolean') then f:write(k..'='..tostring(v)..'\n') end
  end
  if name:sub(1,3)=='sfx' then
    for i=1,4 do f:write('capture.port'..(i-1)..'='..parameters[i]..'\n') end
  end
  f:close()
end
local function guard(fn)
  return function(...)
    local ok,err=pcall(fn,...)
    if not ok then local f=io.open(output..'/error.txt','w');f:write(tostring(err));f:close();emu.stop(1) end
  end
end
emu.addMemoryCallback(guard(function(a,v)
  parameters[a-0x2140+1]=v
  if a==0x2140 and initialized then
    local cmd=v&0x1e
    if cmd==6 then
      local id=parameters[2]
      commands[id]=(commands[id] or 0)+1
      report:write(string.format('{"field":%d,"sfx":%d,"tick":%d}\n',field,id,tick()))
      if not captured[id] then requested='sfx'..id;captured[id]=true end
    elseif cmd==0 or cmd==4 then
      report:write(string.format('{"field":%d,"command":%d,"tick":%d}\n',field,cmd,tick()))
    end
  end
end),emu.callbackType.write,0x2140,0x2143,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function(a,v)
  if initialized and v&1~=0 then shots=shots+1 end
end),emu.callbackType.write,0x7e0000+labels._fx_audio_events,0x7e0000+labels._fx_audio_events,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  initialized=true
  if field<550 or field>1000 then put('_monosh_player_invuln',255) end
  if field>=400 and not fixtures.stumble then
    put('_hit_pending',2);fixtures.stumble=true
  end
  if field>=600 and not fixtures.death then
    put('_monosh_player_invuln',0);put('_hit_pending',1);fixtures.death=true
  end
end),emu.callbackType.exec,0x7f0000+labels._fx_frame,0x7f0000+labels._fx_frame,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  audioStart=emu.getState().masterClock
  if emu.read(0x3030,emu.memType.snesMemory)&0x20~=0 then busyCalls=busyCalls+1 end
  if field>=320 and not fixtures.explosion then put('_fx_audio_events',2);fixtures.explosion=true end
  if field>=360 and not fixtures.reflect then put('_fx_audio_events',4);fixtures.reflect=true end
  if field>=950 and not fixtures.boss then
    restoredBoss=read('_monosh_boss_state');put('_monosh_boss_state',2);fixtures.boss=true
  end
end),emu.callbackType.exec,labels.fx_audio_process,labels.fx_audio_process,emu.cpuType.snes,emu.memType.snesMemory)
emu.addMemoryCallback(guard(function()
  local ms=((emu.getState().masterClock-audioStart)&0xffffffff)/21477.272
  audioMax=math.max(audioMax,ms);audioSum=audioSum+ms;audioCalls=audioCalls+1
  if restoredBoss then put('_monosh_boss_state',restoredBoss);restoredBoss=nil end
end),emu.callbackType.exec,0x7f0000+labels.render_finished+4,0x7f0000+labels.render_finished+4,emu.cpuType.snes,emu.memType.snesMemory)
-- Driver v0.4.2 mainloopの命令境界でSPCを書き出す。
emu.addMemoryCallback(guard(function()
  if requested then snapshot(requested);requested=nil end
end),emu.callbackType.exec,0x0394,0x0394,emu.cpuType.spc,emu.memType.spcMemory)
emu.addEventCallback(guard(function()
  emu.setInput({a=field>=110 and field<300,start=(field>=1100 and field<=1103) or (field>=1220 and field<=1223)},0)
end),emu.eventType.inputPolled)
emu.addEventCallback(guard(function()
  field=field+1
  if field==305 then requested='bgm' end
  if scheduled and field>=scheduled.field then requested=scheduled.name;scheduled=nil end
  if field==1140 then pauseTick=tick() end
  if field>1140 and field<1200 then assert(tick()==pauseTick,'music advanced while paused');pauseStable=pauseStable+1 end
  if field%300==0 then
    local env={}
    for ch=0,7 do env[#env+1]=emu.read(ch*16+8,emu.memType.spcDspRegisters) end
    report:write(string.format('{"field":%d,"tick":%d,"env":[%s]}\n',field,tick(),table.concat(env,',')))
  end
  if field==1400-5 then requested='loop' end
  if field>=1400 then
    for id=0,5 do assert(commands[id] and commands[id]>0,'missing sfx '..id) end
    assert(busyCalls==0,'audio API called while GSU running')
    assert(pauseStable==59,'pause not checked')
    assert(shots>=commands[5],'more shot sounds than actual spawns')
    if false then assert(tick()>30720,'song has not crossed loop point') end
    local f=assert(io.open(output..'/summary.json','w'))
    local counts={};for id=0,5 do counts[#counts+1]=commands[id] end
    f:write(string.format('{"fields":%d,"ticks":%d,"sfxCommands":[%s],"spawns":%d,"busyCalls":%d,"pauseStableFields":%d,"audioCalls":%d,"audioMaxMs":%.6f,"audioMeanMs":%.6f}',field,tick(),table.concat(counts,','),shots,busyCalls,pauseStable,audioCalls,audioMax,audioSum/audioCalls))
    f:close();report:close();emu.stop(0)
  end
end),emu.eventType.endFrame)
