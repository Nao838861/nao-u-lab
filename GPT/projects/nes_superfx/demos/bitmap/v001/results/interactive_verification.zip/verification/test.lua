local L={displayed_phase=1,displayed_profile=21,front=10,missed=7,nmi_count=4,phase=0,profile=20,render_fields=9,stage=6,switches=22,updates=2} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/bitmap/interactive_v001/verification"
local frame=0 local previous=-1 local stable=0 local done=false local pressUntil=-1
local wanted=0 local captured=0 local wrappedAt=nil
local trace=assert(io.open(out..'/trace.jsonl','w'))
local captures=assert(io.open(out..'/captures.jsonl','w'))
local function word(a) return emu.read(a,emu.memType.nesMemory)+256*emu.read(a+1,emu.memType.nesMemory) end
emu.addEventCallback(function() emu.setInput({a=frame<pressUntil},0) end,emu.eventType.inputPolled)
emu.addEventCallback(function()
  if done then return end
  local ok,err=pcall(function()
    frame=frame+1
    assert(frame<2500,'timeout')
    assert(emu.read(0x5fe3,emu.memType.nesMemory)==0,'bitmap fault')
    local u=word(L.updates) local p=emu.read(L.displayed_profile,emu.memType.nesMemory)
    local phase=emu.read(L.displayed_phase,emu.memType.nesMemory)
    if u~=previous then
      trace:write(string.format('{"frame":%d,"updates":%d,"profile":%d,"phase":%d,"switches":%d,"missed":%d}\n',
        frame,u,p,phase,word(L.switches),word(L.missed)));trace:flush()
      stable=0;previous=u
    else stable=stable+1 end
    if wanted==10 then
      if p==0 and word(L.switches)==10 then
        if not wrappedAt then wrappedAt=frame end
        assert(word(L.switches)==10,'held A repeated')
        if frame-wrappedAt>=16 then done=true;trace:close();captures:close();emu.stop(0) end
      end
      return
    end
    if p==wanted and u>0 and stable==1 then
      assert(word(L.switches)==wanted,'held A repeated')
      local image=emu.getScreenBuffer() local rgb={}
      for i=1,#image do local c=image[i];rgb[i]=string.char(math.floor(c/65536)%256,math.floor(c/256)%256,c%256) end
      local name=string.format('/p%02d_%02d',p,captured)
      local f=assert(io.open(out..name..'.rgb','wb'));f:write(table.concat(rgb));f:close()
      local front=emu.read(0x5fe2,emu.memType.nesMemory) local ram={}
      for i=0,16383 do ram[#ram+1]=string.char(emu.read(front*16384+i,emu.memType.nesMapperRam)) end
      f=assert(io.open(out..name..'.ram','wb'));f:write(table.concat(ram));f:close()
      captures:write(string.format('{"profile":%d,"sample":%d,"phase":%d,"frame":%d,"updates":%d}\n',p,captured,phase,frame,u));captures:flush()
      captured=captured+1
      if captured==64 then wanted=wanted+1;captured=0;pressUntil=frame+8 end
    end
  end)
  if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
