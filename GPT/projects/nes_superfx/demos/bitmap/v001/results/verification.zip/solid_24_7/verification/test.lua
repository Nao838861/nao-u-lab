local L={displayed_phase=1,front=10,missed=7,nmi_count=4,phase=0,render_fields=9,stage=6,updates=2} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/bitmap/solid_24_7/verification"
local frames=0 local previous=-1 local stable=0 local images=0 local seen={} local done=false
local trace=assert(io.open(out..'/trace.jsonl','w'))
local function word(a) return emu.read(a,emu.memType.nesMemory)+256*emu.read(a+1,emu.memType.nesMemory) end
emu.addEventCallback(function()
  if done then return end
  local ok,err=pcall(function()
    frames=frames+1
    local u=word(L.updates) local p=emu.read(L.displayed_phase,emu.memType.nesMemory)
    local front=emu.read(0x5fe2,emu.memType.nesMemory)
    local fault=emu.read(0x5fe3,emu.memType.nesMemory)
    assert(emu.read(L.stage,emu.memType.nesMemory)~=0xe1,'ABI2 missing')
    assert(fault==0,'bitmap fault '..fault)
    local clocks=0 for i=3,0,-1 do clocks=clocks*256+emu.read(0x5fd0+i,emu.memType.nesMemory) end
    if u~=previous then
      trace:write(string.format('{"frame":%d,"updates":%d,"phase":%d,"front":%d,"missed":%d,"gsu_clocks":%d}\n',frames,u,p,front,word(L.missed),clocks));trace:flush()
      stable=0;previous=u
    else stable=stable+1 end
    if u>0 and stable==1 and not seen[u] then
      -- takeScreenshot() reads an asynchronously decoded, potentially older frame.
      -- getScreenBuffer() converts the current PPU buffer synchronously at endFrame.
      local screen=emu.getScreenBuffer() local rgb={}
      for i=1,#screen do
        local c=screen[i]
        rgb[i]=string.char(math.floor(c/65536)%256,math.floor(c/256)%256,c%256)
      end
      local s=assert(io.open(out..string.format('/screen_%03d.rgb',images),'wb'))
      s:write(table.concat(rgb));s:close()
      local data={}
      for i=0,16383 do data[#data+1]=string.char(emu.read(front*16384+i,emu.memType.nesMapperRam)) end
      local ram=assert(io.open(out..string.format('/ram_%03d.bin',images),'wb'))
      ram:write(table.concat(data));ram:close()
      local meta=assert(io.open(out..string.format('/phase_%03d.txt',images),'w'));meta:write(p);meta:close()
      seen[u]=true;images=images+1
      if images==64 then done=true;trace:close();emu.stop(0) end
    end
    assert(frames<3000,'display timeout')
  end)
  if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
