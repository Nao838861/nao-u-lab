local L={displayed_phase=1,idle=33027,nmi_count=4,phase=0,stage=5,updates=2}
local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/cube_verification"
local ramSeen={} local imageSeen={} local imageCount=0 local ramCount=0 local stable=0 local lastUpdate=-1
local function dump(path,address,count,memory)
  local parts={}
  for i=0,count-1 do parts[#parts+1]=string.char(emu.read(address+i,memory)) end
  local f=assert(io.open(path,'wb'));f:write(table.concat(parts));f:close()
end
local report=assert(io.open(out..'/trace.jsonl','w'))
local frames=0
emu.addEventCallback(function()
  local ok,err=pcall(function()
    frames=frames+1
    local stage=emu.read(L.stage,emu.memType.nesMemory)
    assert(stage~=0xe1,'GSU mapper missing');assert(stage~=0xe2,'GSU timeout')
    local phase=emu.read(L.phase,emu.memType.nesMemory)
    local updates=emu.read(L.updates,emu.memType.nesMemory)+256*emu.read(L.updates+1,emu.memType.nesMemory)
    local shown=emu.read(L.displayed_phase,emu.memType.nesMemory)
    if (stage==2 or stage==3) and emu.read(0x5030,emu.memType.nesMemory)%64<32 and not ramSeen[phase] then
      dump(out..string.format('/ram_%02d.bin',phase),0x6000,2048,emu.memType.nesMemory)
      dump(out..string.format('/vertices_%02d.bin',phase),0x7100,32,emu.memType.nesMemory)
      ramSeen[phase]=true;ramCount=ramCount+1
    end
    if updates~=lastUpdate then stable=0;lastUpdate=updates else stable=stable+1 end
    if updates>0 and stable==2 and not imageSeen[shown] then
      -- Read both real nametables; the expected displayed one is updates parity.
      dump(out..string.format('/nt_%02d.bin',shown),0x2000+(updates%2)*0x400,1024,emu.memType.nesPpuMemory)
      local f=assert(io.open(out..string.format('/screen_%02d.png',shown),'wb'))
      f:write(emu.takeScreenshot());f:close()
      report:write(string.format('{"frame":%d,"phase":%d,"updates":%d}\n',frames,shown,updates));report:flush()
      imageSeen[shown]=true;imageCount=imageCount+1
      if imageCount==64 then assert(ramCount==64,'missing fresh GSU captures');report:close();emu.stop(0) end
    end
    assert(frames<2000,'rotation did not complete')
  end)
  if not ok then
    local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1)
  end
end,emu.eventType.endFrame)
