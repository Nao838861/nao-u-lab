local L={displayed_ground=3,displayed_phase=1,displayed_view=5,front=15,ground=2,gsu_clocks=16,missed=12,nmi_count=9,paused=6,phase=0,queue_overflow=45,render_fields=14,stage=11,switches=20,updates=7,view=4} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/ground/v002/frontend_25" local frame=0 local last=-1 local stable=0
local sample=0 local wanted=0 local pressUntil=-1 local press={} local done=false local pauseStage=0 local pausePhase=nil
local trace=assert(io.open(out..'/trace.jsonl','w')) local captures=assert(io.open(out..'/captures.jsonl','w'))
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
local function capture(v,m,p)
 local name=string.format('/%02d_%02d',wanted,sample) local screen=emu.getScreenBuffer() local rgb={}
 for i=1,#screen do local c=screen[i];rgb[i]=string.char(math.floor(c/65536)%256,math.floor(c/256)%256,c%256) end
 local f=assert(io.open(out..name..'.rgb','wb'));f:write(table.concat(rgb));f:close()
 local front=byte(0x5fe2) local ram={}
 for i=0,16383 do ram[#ram+1]=string.char(emu.read(front*16384+i,emu.memType.nesMapperRam)) end
 f=assert(io.open(out..name..'.ram','wb'));f:write(table.concat(ram));f:close()
 captures:write(string.format('{"profile":%d,"sample":%d,"view":%d,"mode":%d,"phase":%d,"frame":%d,"updates":%d,"fields":%d}\n',wanted,sample,v,m,p,frame,word(L.updates),byte(L.render_fields)));captures:flush()
end
emu.addEventCallback(function() emu.setInput(frame<pressUntil and press or {},0) end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 if done then return end
 local ok,err=pcall(function()
  frame=frame+1;assert(frame<10000,'timeout');assert(byte(L.stage)~=0xe1,'mapper missing');assert(byte(0x5fe3)==0,'bitmap fault');assert(byte(L.queue_overflow)==0,'input queue overflow')
  local u=word(L.updates) local v=byte(L.displayed_view) local m=byte(L.displayed_ground) local p=byte(L.displayed_phase)
  if u~=last then
   local clocks=0 for i=3,0,-1 do clocks=clocks*256+byte(L.gsu_clocks+i) end
   trace:write(string.format('{"frame":%d,"updates":%d,"view":%d,"mode":%d,"phase":%d,"gsu_clocks":%d,"missed":%d}\n',frame,u,v,m,p,clocks,word(L.missed)));trace:flush();last=u;stable=0
  else stable=stable+1 end
  if wanted==8 then
   if frame<pressUntil then return end
   if pauseStage==0 and u>0 and stable==1 then press={select=true};pressUntil=frame+8;pauseStage=1;return end
   if pauseStage==1 and stable==1 then assert(v==2,'view wraparound failed');press={b=true};pressUntil=frame+8;pauseStage=2;return end
   if pauseStage==2 and byte(L.paused)==1 and stable==1 then pausePhase=p;press={a=true};pressUntil=frame+8;pauseStage=3;return end
   if pauseStage==3 and stable==1 then
    assert(byte(L.paused)==1 and p==pausePhase and m==0,'renderer changed position while paused')
    press={right=true};pressUntil=frame+8;pauseStage=4;return
   end
   if pauseStage==4 and stable==1 then
    assert(p==(pausePhase+1)%64,'step did not move exactly once')
    press={left=true};pressUntil=frame+8;pauseStage=5;return
   end
   if pauseStage==5 and stable==1 then
    assert(p==pausePhase,'reverse step did not move exactly once')
    done=true;trace:close();captures:close();emu.stop(0)
   end
   return
  end
  local wantV=(2+math.floor(wanted/2))%4 local wantM=wanted%2
  if u>0 and stable==1 and v==wantV and m==wantM then
   assert(word(L.switches)==wanted,'held A repeated')
   capture(v,m,p);sample=sample+1
   if sample==8 then
    sample=0;wanted=wanted+1
    if wanted<8 then press={a=true,select=(wanted%2==0)};pressUntil=frame+8 end
   end
  end
 end)
 if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
