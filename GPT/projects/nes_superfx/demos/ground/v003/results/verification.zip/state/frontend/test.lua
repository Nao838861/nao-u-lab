local L={capture_mmc5_state=33410,displayed_ground=3,displayed_phase=1,displayed_tick=786,displayed_view=5,external_state=784,front=15,ground=2,gsu_clocks=16,missed=12,nmi_count=9,original_state=768,paused=6,phase=0,queue_overflow=45,render_fields=14,render_from_mmc5_state=33437,render_tick=810,stage=11,state_error=785,switches=20,updates=7,view=4} local cases={{mode=0,tick=200,state={0,56,2,0,136,1,0,0,0,0,200,0}},{mode=1,tick=200,state={0,56,2,0,136,1,0,0,0,0,200,0}},{mode=0,tick=201,state={128,56,2,64,136,1,0,32,0,0,201,0}},{mode=1,tick=201,state={128,56,2,64,136,1,0,32,0,0,201,0}},{mode=0,tick=202,state={129,56,2,64,136,1,0,64,0,0,202,0}},{mode=1,tick=202,state={129,56,2,64,136,1,0,64,0,0,202,0}},{mode=0,tick=203,state={0,48,2,0,94,1,255,255,0,32,203,0}},{mode=1,tick=203,state={0,48,2,0,94,1,255,255,0,32,203,0}},{mode=0,tick=204,state={0,44,1,0,64,1,0,128,0,192,204,0}},{mode=1,tick=204,state={0,44,1,0,64,1,0,128,0,192,204,0}},{mode=0,tick=205,state={0,72,0,0,217,0,0,192,0,128,205,0}},{mode=1,tick=205,state={0,72,0,0,217,0,0,192,0,128,205,0}},{mode=0,tick=206,state={0,251,1,0,55,2,0,192,255,255,206,0}},{mode=1,tick=206,state={0,251,1,0,55,2,0,192,255,255,206,0}},{mode=0,tick=207,state={0,32,0,0,58,0,0,0,0,128,207,0}},{mode=1,tick=207,state={0,32,0,0,58,0,0,0,0,128,207,0}}} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/ground/v003/state_frontend" local frame=0 local index=1 local armed=false local done=false local minimumUpdate=0
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
local function put(a,v) emu.write(a,v,emu.memType.nesMemory) end
emu.addEventCallback(function()
 if done then return end
 local ok,err=pcall(function()
 frame=frame+1;assert(frame<1500,'timeout');assert(byte(L.stage)~=0xe1,'state rejected');assert(byte(0x5fe3)==0,'mapper fault')
 if word(L.updates)==0 then return end
 local c=cases[index]
 if not armed then
  put(L.external_state,1);put(L.paused,1);put(L.ground,c.mode)
  for i,v in ipairs(c.state) do put(L.original_state+i-1,v) end
  -- A control write during GO must not be mistaken for an already-started frame.
  minimumUpdate=word(L.updates)+2
  armed=true;return
 end
 if word(L.updates)<minimumUpdate then return end
 if word(L.displayed_tick)~=c.tick or byte(L.displayed_ground)~=c.mode then return end
 local ram={} local front=byte(0x5fe2)
 for i=0,16383 do ram[#ram+1]=string.char(emu.read(front*16384+i,emu.memType.nesMapperRam)) end
 local f=assert(io.open(out..'/'..index..'.ram','wb'));f:write(table.concat(ram));f:close()
 index=index+1;armed=false
 if index>#cases then done=true;emu.stop(0) end
 end)
 if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
