local L={desired_ground=1105,desired_mode=1106,desired_view=1104,displayed_ground=8,displayed_tick=786,displayed_view=7,drive_mode=6,external_state=784,frame=57723,front=9,ground=5,gsu_clocks=11,latest_state=896,nmi=58728,nmi_count=0,original_state=768,physics_ticks=1096,present_ready=15,render_from_mmc5_state=57907,render_tick=810,reset=57344,reset_request=1107,sim_begin=58949,sim_end=58952,stage=10,state_error=785,updates=2,view=4,fills3=60145,fills2=59928,fills1=59711,fills0=59494,physics_drift=59286,physics_grip=59094,irq=59031,save_render_zp=58901,no_present=58792,fill_command=58586,fills_hi=59490,fills_lo=59486,rows_hi=59482,rows_lo=59478,multiply_loop=58383,position_ready=58208,invalid_position=58218,divide10=58154,negate_num=58220,camera_offset=58319,cameras=59058,convert_direction=58246,invalid_state=58109,convert_position=58116,capture_mmc5_state=57880,wait_present=57861,hud=58654,poll=57834,clear_background=58562,fail=57868,copy_latest=57753,palette=59054,load_rows=58495,texture_chunk=58482,texture_bank=57586,physics_hi=59092,physics_lo=59090,copy_data=58529,init_wram=57456,restart=57414,trampoline=59032,trampoline_end=59054,init_source_bank=28,init_bank=27,copy_sequence=26,backhigh=25,fillcount=24,fillptr=22,left=20,dst=18,src=16} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/racing/v001/controls" local frame=0 local phase=0 local untilFrame=0 local press={} local mark=0 local lastView=0 local done=false
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
local function tap(k) press=k;untilFrame=frame+8 end
emu.addEventCallback(function() emu.setInput(frame<untilFrame and press or {},0) end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 if done then return end
 frame=frame+1
 local ok,err=pcall(function()
 assert(frame<1800,'controls timeout phase='..phase)
 if frame<untilFrame then return end
 local ticks=word(L.physics_ticks) local updates=word(L.updates)
 if phase==0 and updates>1 then
  assert(byte(L.drive_mode)==0);lastView=byte(L.displayed_view);tap({select=true});phase=1
 elseif phase==1 and byte(L.displayed_view)==(lastView+1)%4 then
  assert(byte(L.desired_view)==(lastView+1)%4,'held SELECT repeated');tap({up=true});phase=2
 elseif phase==2 and byte(L.displayed_ground)==1 then
  assert(byte(L.desired_ground)==1,'held UP repeated');tap({down=true});phase=3
 elseif phase==3 and byte(L.drive_mode)==1 and ticks>20 then
  assert(byte(L.desired_mode)==1,'held DOWN repeated')
  local f=assert(io.open(out..'/drift.png','wb'));f:write(emu.takeScreenshot());f:close()
  mark=ticks;tap({start=true});phase=4
 elseif phase==4 and ticks<mark and ticks>0 then
  assert(byte(L.drive_mode)==1,'START changed mode');phase=5;mark=frame
 elseif phase==5 and frame>mark+30 then
  -- A display-range failure must still allow START to recover; physics keeps running.
  emu.write(0x41,0,emu.memType.nesMemory);emu.write(0x42,0xa4,emu.memType.nesMemory);emu.write(0x43,6,emu.memType.nesMemory);phase=6
 elseif phase==6 and byte(L.stage)==0xe1 then tap({start=true});phase=7
 elseif phase==7 and byte(L.stage)~=0xe1 and ticks>0 then
  assert(byte(0x4fe3)==0,'bitmap fault after restart')
  local f=assert(io.open(out..'/pass.json','w'));f:write('{"status":"pass","held_edges":true,"view_switch":true,"ground_switch":true,"mode_switch":true,"start_reset":true,"range_reset_recovery":true}');f:close();done=true;emu.stop(0)
 end
 end)
 if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
