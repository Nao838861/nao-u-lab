local L={desired_ground=1105,desired_mode=1106,desired_view=1104,displayed_ground=8,displayed_tick=786,displayed_view=7,drive_mode=6,external_state=784,frame=57723,front=9,ground=5,gsu_clocks=11,latest_state=896,nmi=58728,nmi_count=0,original_state=768,physics_ticks=1096,present_ready=15,render_from_mmc5_state=57907,render_tick=810,reset=57344,reset_request=1107,sim_begin=58949,sim_end=58952,stage=10,state_error=785,updates=2,view=4,fills3=60145,fills2=59928,fills1=59711,fills0=59494,physics_drift=59286,physics_grip=59094,irq=59031,save_render_zp=58901,no_present=58792,fill_command=58586,fills_hi=59490,fills_lo=59486,rows_hi=59482,rows_lo=59478,multiply_loop=58383,position_ready=58208,invalid_position=58218,divide10=58154,negate_num=58220,camera_offset=58319,cameras=59058,convert_direction=58246,invalid_state=58109,convert_position=58116,capture_mmc5_state=57880,wait_present=57861,hud=58654,poll=57834,clear_background=58562,fail=57868,copy_latest=57753,palette=59054,load_rows=58495,texture_chunk=58482,texture_bank=57586,physics_hi=59092,physics_lo=59090,copy_data=58529,init_wram=57456,restart=57414,trampoline=59032,trampoline_end=59054,init_source_bank=28,init_bank=27,copy_sequence=26,backhigh=25,fillcount=24,fillptr=22,left=20,dst=18,src=16} local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/racing/v001/native_drift_50_0" local wantedMode=1 local wantedGround=0 local frame=0 local count=0 local last=-1 local done=false local started=0 local capturePending=false
local trace=assert(io.open(out..'/physics.jsonl','w')) local images=assert(io.open(out..'/images.jsonl','w'))
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
local function put(a,v) emu.write(a,v,emu.memType.nesMemory) end
local function dump(name,a,n,kind)
 local t={} for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,kind)) end
 local f=assert(io.open(out..'/'..name,'wb'));f:write(table.concat(t));f:close()
end
emu.addMemoryCallback(function() put(L.desired_mode,wantedMode);put(L.desired_ground,wantedGround) end,emu.callbackType.exec,L.restart)
emu.addEventCallback(function()
 local k={} local phase=count%320
 if phase<235 then k.a=true end
 if phase>=55 and phase<100 then k.right=true;k.b=true elseif phase>=100 and phase<135 then k.left=true end
 -- Renderer controls are ignored by original vehicle physics, but still passed through.
 if count==200 or count==400 or count==600 then k.select=true end
 emu.setInput(k,0)
end,emu.eventType.inputPolled)
emu.addMemoryCallback(function() started=emu.getState()['cpu.cycleCount'] end,emu.callbackType.exec,L.sim_begin)
emu.addMemoryCallback(function()
 count=count+1
 local state={} for a=0x40,0xff do state[#state+1]=byte(a) end
 trace:write('{"tick":'..count..',"frame":'..frame..',"cycles":'..(emu.getState()['cpu.cycleCount']-started)..',"buttons":'..byte(0x40)..',"offroad":'..byte(0x6771)..',"tail":'..byte(0x6772)..',"state":['..table.concat(state,',')..']}\n');trace:flush()
end,emu.callbackType.exec,L.sim_end)
emu.addEventCallback(function()
 if done then return end
 frame=frame+1
 local ok,err=pcall(function()
 if frame==2499 then dump('timeout-cpu.bin',0,2048,emu.memType.nesMemory) end
 assert(frame<2500,'timeout stage='..byte(L.stage)..' ticks='..word(L.physics_ticks)..' PC='..tostring(emu.getState()['cpu.pc']));assert(byte(L.stage)~=0xe1,'pose range error');assert(byte(0x4fe3)==0,'bitmap fault='..byte(0x4fe3)..' tick='..count..' frame='..frame)
 local update=word(L.updates)
 if update~=last and update>0 then
  last=update;capturePending=true
 elseif update>0 and capturePending then
  -- Front swaps at NMI. Wait one field for the newly published PPU frame.
  capturePending=false
  if update<=24 or update%40==0 then
   local front=byte(0x4fe2) local name='image'..update
   dump(name..'.ram',front*16384,16384,emu.memType.nesMapperRam)
   dump(name..'.state',0x320,12,emu.memType.nesMemory)
   local f=assert(io.open(out..'/'..name..'.png','wb'));f:write(emu.takeScreenshot());f:close()
   images:write('{"name":"'..name..'","view":'..byte(L.displayed_view)..',"mode":'..byte(L.displayed_ground)..',"tick":'..word(L.displayed_tick)..',"frame":'..frame..'}\n');images:flush()
  end
 end
 if count>=1024 then trace:close();images:close();done=true;emu.stop(0) end
 end)
 if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
