local out="D:/AI/Nao_u_BOT/GPT/projects/nes_superfx/build/racing/v001/grip" local mode="grip" local frame=0 local tick=0 local saved=false
local trace=assert(io.open(out..'/native.jsonl','w'))
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function dump(name,a,n,kind)
 local t={} for i=0,n-1 do t[#t+1]=string.char(emu.read(a+i,kind)) end
 local f=assert(io.open(out..'/'..name,'wb'));f:write(table.concat(t));f:close()
end
emu.addEventCallback(function()
 local k={}
 if mode=='drift' and frame>=101 and frame<106 then k.down=true end
 if frame==130 then k.a=true end
 if tick>0 then k.a=true;if tick%160>=55 and tick%160<100 then k.right=true;k.b=true elseif tick%160>=100 and tick%160<135 then k.left=true end end
 emu.setInput(k,0)
end,emu.eventType.inputPolled)
emu.addMemoryCallback(function()
 if tick==55 then dump('pre56-cpu.bin',0,2048,emu.memType.nesMemory);dump('pre56-wram.bin',0,131072,emu.memType.nesSaveRam) end
 if not saved then
  dump('initial-cpu.bin',0,2048,emu.memType.nesMemory)
  dump('initial-wram.bin',0,131072,emu.memType.nesSaveRam)
  saved=true
 end
end,emu.callbackType.exec,0xf78a)
emu.addMemoryCallback(function()
 tick=tick+1
 local t={} for a=0x40,0xff do t[#t+1]=byte(a) end
 trace:write('{"tick":'..tick..',"frame":'..frame..',"delta":'..byte(0x6740)..',"buttons":'..byte(0x40)..',"state":['..table.concat(t,',')..']}\n');trace:flush()
 if tick==128 then trace:close();emu.stop(0) end
end,emu.callbackType.exec,0xf7a9)
emu.addEventCallback(function() frame=frame+1;if frame>2500 then error('baseline timeout') end end,emu.eventType.endFrame)
