
local L={desired_ground=1105,desired_mode=1106,desired_view=1104,displayed_ground=8,displayed_tick=786,displayed_view=7,drive_mode=6,external_state=784,frame=57723,front=9,ground=5,gsu_clocks=11,latest_state=896,nmi=58728,nmi_count=0,original_state=768,physics_ticks=1096,present_ready=15,render_from_mmc5_state=57907,render_tick=810,reset=57344,reset_request=1107,sim_begin=58949,sim_end=58952,stage=10,state_error=785,updates=2,view=4,fills3=60145,fills2=59928,fills1=59711,fills0=59494,physics_drift=59286,physics_grip=59094,irq=59031,save_render_zp=58901,no_present=58792,fill_command=58586,fills_hi=59490,fills_lo=59486,rows_hi=59482,rows_lo=59478,multiply_loop=58383,position_ready=58208,invalid_position=58218,divide10=58154,negate_num=58220,camera_offset=58319,cameras=59058,convert_direction=58246,invalid_state=58109,convert_position=58116,capture_mmc5_state=57880,wait_present=57861,hud=58654,poll=57834,clear_background=58562,fail=57868,copy_latest=57753,palette=59054,load_rows=58495,texture_chunk=58482,texture_bank=57586,physics_hi=59092,physics_lo=59090,copy_data=58529,init_wram=57456,restart=57414,trampoline=59032,trampoline_end=59054,init_source_bank=28,init_bank=27,copy_sequence=26,backhigh=25,fillcount=24,fillptr=22,left=20,dst=18,src=16} local out="C:/AI/nao-u-lab/GPT/.tmp/nesfx-audio-repo/GPT/projects/nes_superfx/build/racing/v002/audio-test/001-1-25" local frame=0 local count=0 local armed=false
local states=assert(io.open(out..'/physics.txt','w'))
local audio=assert(io.open(out..'/apu.txt','w'))
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
emu.addMemoryCallback(function() emu.write(L.desired_mode,1,emu.memType.nesMemory) end,emu.callbackType.exec,L.restart)
emu.addEventCallback(function()
 local t=word(L.physics_ticks)
 emu.setInput({a=t>=80 and t<620,b=t>=620 and t<850,right=t>=400 and t<620,left=t>=620 and t<850},0)
end,emu.eventType.inputPolled)
emu.addMemoryCallback(function(a,v)
 audio:write(string.format('%d %04x %02x\n',count,a,v))
end,emu.callbackType.write,0x4000,0x4017)
emu.addMemoryCallback(function()
 count=count+1
 for a=0x40,0xe9 do
  if a<0xc2 or a>0xc4 then states:write(string.format('%02x',byte(a))) end
 end
 states:write('\n')
end,emu.callbackType.exec,L.sim_end)
emu.addEventCallback(function()
 frame=frame+1
 if frame>2600 then error('audio test timed out') end
 if count>=1000 then
  local report=assert(io.open(out..'/counters.json','w'))
  report:write(string.format('{"physics_ticks":%d,"audio_ticks":%d,"fault":%d}',word(L.physics_ticks),word(0x454),byte(0x4fe3)))
  report:close();states:close();audio:close()
  local f=assert(io.open(out..'/screen.png','wb'));f:write(emu.takeScreenshot());f:close()
  emu.stop(0)
 end
end,emu.eventType.endFrame)
