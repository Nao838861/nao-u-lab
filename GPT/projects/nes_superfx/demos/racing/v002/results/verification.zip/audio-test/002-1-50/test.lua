
local L={audio_begin=59074,audio_end=59077,audio_ticks=1108,desired_ground=1105,desired_mode=1106,desired_view=1104,displayed_ground=8,displayed_tick=786,displayed_view=7,drive_mode=6,external_state=784,frame=57744,front=9,ground=5,gsu_clocks=11,latest_state=896,nmi=58749,nmi_count=0,original_state=768,physics_ticks=1096,present_ready=15,render_from_mmc5_state=57928,render_tick=810,reset=57344,reset_request=1107,sim_begin=58970,sim_end=58973,stage=10,state_error=785,updates=2,view=4,fills3=60182,fills2=59965,fills1=59748,fills0=59531,physics_drift=59323,physics_grip=59131,irq=59052,save_render_zp=58922,no_present=58813,fill_command=58607,fills_hi=59527,fills_lo=59523,rows_hi=59519,rows_lo=59515,multiply_loop=58404,position_ready=58229,invalid_position=58239,divide10=58175,negate_num=58241,camera_offset=58340,cameras=59095,convert_direction=58267,invalid_state=58130,convert_position=58137,capture_mmc5_state=57901,wait_present=57882,hud=58675,poll=57855,clear_background=58583,fail=57889,copy_latest=57774,palette=59091,load_rows=58516,texture_chunk=58503,texture_bank=57607,physics_hi=59129,physics_lo=59127,copy_data=58550,init_wram=57465,restart=57414,trampoline=59053,trampoline_end=59091,init_source_bank=28,init_bank=27,copy_sequence=26,backhigh=25,fillcount=24,fillptr=22,left=20,dst=18,src=16} local out="C:/AI/nao-u-lab/GPT/.tmp/nesfx-audio-repo/GPT/projects/nes_superfx/build/racing/v002/audio-test/002-1-50" local frame=0 local count=0 local armed=false
local states=assert(io.open(out..'/physics.txt','w'))
local audio=assert(io.open(out..'/apu.txt','w'))
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
emu.addMemoryCallback(function() emu.write(L.desired_mode,1,emu.memType.nesMemory) end,emu.callbackType.exec,L.restart)
emu.addEventCallback(function()
 local t=word(L.physics_ticks)
 emu.setInput({a=t>=80 and t<620,b=t>=620 and t<850,right=t>=400 and t<620,left=t>=620 and t<850},0)
end,emu.eventType.inputPolled)
emu.addMemoryCallback(function(a,v)
 audio:write(string.format('%d %04x %02x\n',count,a,v))
end,emu.callbackType.write,0x4000,0x4017)
emu.addMemoryCallback(function()
 count=count+1
 for a=0x40,0xe9 do
  if a<0xc2 or a>0xc4 then states:write(string.format('%02x',byte(a))) end
 end
 states:write('\n')
end,emu.callbackType.exec,L.sim_end)
emu.addEventCallback(function()
 frame=frame+1
 if frame>2600 then error('audio test timed out') end
 if count>=1000 then
  local report=assert(io.open(out..'/counters.json','w'))
  report:write(string.format('{"physics_ticks":%d,"audio_ticks":%d,"fault":%d}',word(L.physics_ticks),word(0x454),byte(0x4fe3)))
  report:close();states:close();audio:close()
  local f=assert(io.open(out..'/screen.png','wb'));f:write(emu.takeScreenshot());f:close()
  emu.stop(0)
 end
end,emu.eventType.endFrame)
