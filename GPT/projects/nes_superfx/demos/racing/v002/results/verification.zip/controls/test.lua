local L={audio_begin=59074,audio_end=59077,audio_ticks=1108,desired_ground=1105,desired_mode=1106,desired_view=1104,displayed_ground=8,displayed_tick=786,displayed_view=7,drive_mode=6,external_state=784,frame=57744,front=9,ground=5,gsu_clocks=11,latest_state=896,nmi=58749,nmi_count=0,original_state=768,physics_ticks=1096,present_ready=15,render_from_mmc5_state=57928,render_tick=810,reset=57344,reset_request=1107,sim_begin=58970,sim_end=58973,stage=10,state_error=785,updates=2,view=4,fills3=60182,fills2=59965,fills1=59748,fills0=59531,physics_drift=59323,physics_grip=59131,irq=59052,save_render_zp=58922,no_present=58813,fill_command=58607,fills_hi=59527,fills_lo=59523,rows_hi=59519,rows_lo=59515,multiply_loop=58404,position_ready=58229,invalid_position=58239,divide10=58175,negate_num=58241,camera_offset=58340,cameras=59095,convert_direction=58267,invalid_state=58130,convert_position=58137,capture_mmc5_state=57901,wait_present=57882,hud=58675,poll=57855,clear_background=58583,fail=57889,copy_latest=57774,palette=59091,load_rows=58516,texture_chunk=58503,texture_bank=57607,physics_hi=59129,physics_lo=59127,copy_data=58550,init_wram=57465,restart=57414,trampoline=59053,trampoline_end=59091,init_source_bank=28,init_bank=27,copy_sequence=26,backhigh=25,fillcount=24,fillptr=22,left=20,dst=18,src=16} local out="C:/AI/nao-u-lab/GPT/.tmp/nesfx-audio-repo/GPT/projects/nes_superfx/build/racing/v002/controls" local frame=0 local phase=0 local untilFrame=0 local press={} local mark=0 local lastView=0 local done=false
local function byte(a) return emu.read(a,emu.memType.nesMemory) end
local function word(a) return byte(a)+256*byte(a+1) end
local function tap(k) press=k;untilFrame=frame+8 end
emu.addEventCallback(function() emu.setInput(frame<untilFrame and press or {},0) end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 if done then return end
 frame=frame+1
 local ok,err=pcall(function()
 assert(frame<1800,'controls timeout phase='..phase)
 if frame<untilFrame then return end
 local ticks=word(L.physics_ticks) local updates=word(L.updates)
 if phase==0 and updates>1 then
  assert(byte(L.drive_mode)==0);lastView=byte(L.displayed_view);tap({select=true});phase=1
 elseif phase==1 and byte(L.displayed_view)==(lastView+1)%4 then
  assert(byte(L.desired_view)==(lastView+1)%4,'held SELECT repeated');tap({up=true});phase=2
 elseif phase==2 and byte(L.displayed_ground)==1 then
  assert(byte(L.desired_ground)==1,'held UP repeated');tap({down=true});phase=3
 elseif phase==3 and byte(L.drive_mode)==1 and ticks>20 then
  assert(byte(L.desired_mode)==1,'held DOWN repeated')
  local f=assert(io.open(out..'/drift.png','wb'));f:write(emu.takeScreenshot());f:close()
  mark=ticks;tap({start=true});phase=4
 elseif phase==4 and ticks<mark and ticks>0 then
  assert(byte(L.drive_mode)==1,'START changed mode');phase=5;mark=frame
 elseif phase==5 and frame>mark+30 then
  -- A display-range failure must still allow START to recover; physics keeps running.
  emu.write(0x41,0,emu.memType.nesMemory);emu.write(0x42,0xa4,emu.memType.nesMemory);emu.write(0x43,6,emu.memType.nesMemory);phase=6
 elseif phase==6 and byte(L.stage)==0xe1 then tap({start=true});phase=7
 elseif phase==7 and byte(L.stage)~=0xe1 and ticks>0 then
  assert(byte(0x4fe3)==0,'bitmap fault after restart')
  local f=assert(io.open(out..'/pass.json','w'));f:write('{"status":"pass","held_edges":true,"view_switch":true,"ground_switch":true,"mode_switch":true,"start_reset":true,"range_reset_recovery":true}');f:close();done=true;emu.stop(0)
 end
 end)
 if not ok then local f=assert(io.open(out..'/error.txt','w'));f:write(tostring(err));f:close();emu.stop(1) end
end,emu.eventType.endFrame)
